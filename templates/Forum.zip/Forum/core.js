//向控制台输出信息
//等级0~7分级代表调试、信息(默认)、注意、警告、错误、重要、严重、致命
//如果read参数为true，则朗读要输出的文本
function output(text, level, read) {
    var param = {
        text: text,
        level: typeof(level) == 'number' ? level : 1
    }
    chrome.task.output(param);

    if (read)
    	speak(text);
}

//朗读文本
function speak(text) {
	chrome.tts.speak(text);
}

//////////////////////////////////////////////////////////////////////

var boardsList = [];		//论坛板块的列表

var viewMostTopics = [];		//浏览数最多的帖子
var replyMostTopics = [];		//评论数最多的帖子
var kMaxTopTopics = 100;

var chartColors = ['#a5c2d5', '#cbab4f', '#76a871', '#9f7961', '#a56f8f', '#db9034', '#6f83a5'];

//初始化数据
$(document).ready(function() {
	var chartData = [];
	var mostTopics = 0;
	var index = 0;
	$('#boardsList table tr').each (function (idx, elem){
		if ($('td', elem).length == 0)
			return;

		var board_name = $('td', elem)[0].innerText + ' '  + String(index + 1);
		var board_topics = Number($('td', elem)[1].innerText);
		
		chartData.push({
			name: board_name, 
			value: board_topics, 
			color: chartColors[index++ % chartColors.length]
		});

		if (board_topics > mostTopics)
			mostTopics = board_topics;
	});

	new iChart.Bar2D({
		render : 'boardsList',
		data: chartData,
		title : '论坛板块列表',
		subtitle: '以及各版块的帖子数',
		align: 'right',
		animation: true,
		showpercent:false,
		decimalsnum:0,
		width : 1000,
		height : chartData.length * 50,
		coordinate:{
			scale:[{
				 position:'bottom',	
				 start_scale:0,
				 end_scale: mostTopics * 1.2,
				 scale_space: mostTopics / 5,
				 listeners:{
					parseText:function(t,x,y){
						return {text:t}
					}
				}
			}]
		}
	}).draw();

	var dataTableLocale = {
        "sLengthMenu": "每页显示 _MENU_ 条记录",   
        "sZeroRecords": "没有检索到数据",   
        "sInfo": "当前数据为从第 _START_ 到第 _END_ 条数据；总共有 _TOTAL_ 条记录",   
        "sInfoEmtpy": "没有数据",   
        "sProcessing": "正在加载数据...",   
        "sSearch" : "搜索",
        "oPaginate":  {   
            "sFirst": "首页",   
            "sPrevious": "上一页",   
            "sNext": "下一页",   
            "sLast": "尾页"  
        }
    };

	$('#viewMostTopicsTable').dataTable({
		"bSort": false,
		"bJQueryUI": true,
		 "oLanguage": dataTableLocale
	});

	$('#replyMostTopicsTable').dataTable({
		"bSort": false,
		"bJQueryUI": true,
		 "oLanguage": dataTableLocale
	});
});

function onBoard(board) {
	boardsList.push(board);
}

//根据帖子的浏览次数降序排序
//即数组越靠前的元素浏览数越高
function sortTopicByViews(a, b) {
	return Number(b.views) - Number(a.views);
}

//根据帖子的回复次数降序排序
function sortTopicByReplys(a, b) {
	return Number(b.replys) - Number(a.replys);
}

function onTopic(topic) {
	//output('帖子: ' + topic.name);

	//更新帖子浏览排行
	if (viewMostTopics.length >= kMaxTopTopics) {
		if (Number(topic.views) > Number(viewMostTopics[kMaxTopTopics-1].views)) {
			viewMostTopics.pop();
			viewMostTopics.push(topic);
			viewMostTopics.sort(sortTopicByViews);
		}
	} else {
		viewMostTopics.push(topic);
		viewMostTopics.sort(sortTopicByViews);
	}

	//更新帖子回复排行
	if (replyMostTopics.length >= kMaxTopTopics) {
		if (Number(topic.replys) > Number(replyMostTopics[kMaxTopTopics-1].replys)) {
			replyMostTopics.pop();
			replyMostTopics.push(topic);
			replyMostTopics.sort(sortTopicByReplys);
		}
	} else {
		replyMostTopics.push(topic);
		replyMostTopics.sort(sortTopicByReplys);
	}
}

//获取状态数据
chrome.task.getTemplateData(function(data){
	if (data.length) {
		var templateData = JSON.parse(data);
		//TODO: 初始化数据
		//viewMostTopics = ;
		//replyMostTopics = ;
	}

	//页面消息响应
	chrome.extension.onMessage.addListener(function(request, sender, sendResponse){
	   if (request.type == 'speak') {
	   		speak(JSON.parse(request.detail));
	   } else if (request.type == 'topic') {
	   		onTopic(JSON.parse(request.detail));
	   } else if (request.type == 'board') {
	   		onBoard(JSON.parse(request.detail));
	   }
	});
});

//保存状态数据
chrome.task.onSaveData.addListener(function(){
	//chrome.task.saveTemplateData(JSON.stringify({viewMostTopics: 1, replyMostTopics: 1}));
});

chrome.task.onWriteReport.addListener(function(){
	var text;
	text = '<h2>论坛板块列表</h2>';
	text += '\n<table id="boardsList" border="1">\n';
	text += '<thead>\n<tr><th>板块名称</th><th>主题数</th></tr>\n</thead>';
	text += '<tbody>\n';
	boardsList.forEach (function(board) {
		text += '<tr>' + 
				'<td><a href="' + board.url + '" target="_blank">' + board.name + '</a></td>' + 
				'<td>' + board.topics + '</td>' + 
				'</tr>\n';		
	});
	text += '</tbody>';
	text += '\n</table>\n';

	$('#boardsList')[0].innerHTML = text;

	text = '<h2>浏览次数最多的帖子</h2>';
	text += '\n<table id="viewMostTopicsTable" border="1">\n';
	text += '<thead>\n<tr><th>排行</th><th>浏览数</th><th>帖子名称</th><th>所属板块</th><th>发帖人</th><th>发帖时间</th><th>回复数</th></tr>\n</thead>';
	text += '<tbody>\n';
	var index = 0;
	viewMostTopics.forEach (function(topic) {
		text += '<tr>' + 
				'<td>' + (++index) + '</td>' +
				'<td>' + topic.views + '</td>' + 
				'<td><a href="' + topic.url + '" target="_blank">' + topic.name + '</a></td>' + 
				'<td>' + topic.board + '</td>' + 
				'<td><a href="' + topic.authorHome + '" target="_blank">' + topic.author + '</a></td>' + 
				'<td>' + topic.time + '</td>' + 
				'<td>' + topic.replys + '</td>' + 
				'</tr>\n';
	});
	text += '</tbody>';
	text += '\n</table>\n<br>';

	$('#viewMostTopics')[0].innerHTML = text;

	text = '<h2>回复次数最多的帖子</h2>';
	text += '\n<table id="replyMostTopicsTable" border="1">\n';
	text += '<thead>\n<tr><th>排行</th><th>回复数</th><th>帖子名称</th><th>所属板块</th><th>发帖人</th><th>发帖时间</th><th>浏览数</th></tr>\n</thead>';
	text += '<tbody>\n';
	var index = 0;
	replyMostTopics.forEach (function(topic) {
		text += '<tr>' + 
				'<td>' + (++index) + '</td>' +
				'<td>' + topic.replys + '</td>' + 
				'<td><a href="' + topic.url + '" target="_blank">' + topic.name + '</a></td>' + 
				'<td>' + topic.board + '</td>' + 
				'<td><a href="' + topic.authorHome + '" target="_blank">' + topic.author + '</a></td>' + 
				'<td>' + topic.time + '</td>' + 
				'<td>' + topic.views + '</td>' + 
				'</tr>\n';
	});
	text += '</tbody>';
	text += '\n</table>\n<br>';

	$('#replyMostTopics')[0].innerHTML = text;

	chrome.task.didWriteReport('');
});