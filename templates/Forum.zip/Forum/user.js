//按id下载
function ProcessById(page){
	ProcessByUser(page);
}
//按用户下载
function ProcessByUser(page) {

	var pageData = page.data.length ? JSON.parse(page.data) : {};
    var option = page.option.length ? JSON.parse(page.option) : {};

	var totalTopicCsv = "帖子列表.csv";
	var topicCsvHeader;

    if (page.first) {
		var users = [];
		var userList = decodeURI(decodeURI(option.filter));
		if (page.sitetype.indexOf('Discuz') != -1){
    		users = getDiscuzUsers(page.sitetype, userList, option.mode);
			topicCsvHeader = getDiscuzCsvHeader(page.sitetype);
		}
    	else if (page.sitetype.indexOf('Phpwind') != -1){
    		users = getPhpwindUsers(page.sitetype, userList, option.mode);
			topicCsvHeader = getPhpwindCsvHeader(page.sitetype);
		}
    	if (page.sitetype.indexOf('PhpBB') != -1){
    		users = getPhpBBUsers(page.sitetype, userList, option.mode);
			topicCsvHeader = getPhpBBCsvHeader(page.sitetype);
		}
		
		chrome.task.fopen({path: totalTopicCsv, mode: 'a', header: topicCsvHeader});
		
		for(i in users){
			var user = users[i];
			
			chrome.task.addPage({
				url: user.search,
				savedir: decodeURI(user.name) + '/帖子列表',
				savename: '第1页',
				priority: 'high',
				data: JSON.stringify({type: 'search', pageNum: 2, path: decodeURI(user.name), maxPage: option.max, nowPage: 0})
			});
		}

   	 	chrome.task.finishPage({discard: true});
    } 
	
	if(pageData.type == 'search'){
		var topics = [];
		var topicCsvText;
    	var nextPage;
		
    	if (page.sitetype.indexOf('Discuz') != -1) {
    		topics = getDiscuzTopicsOfUser(page.sitetype);
    		nextPage = getDiscuzNextPageOfUser(page.sitetype);
    	}
		
    	if (page.sitetype.indexOf('Phpwind') != -1) {
    		topics = getPhpwindTopicsOfUser(page.sitetype);
    		nextPage = getPhpwindNextPageOfUser(page.sitetype);
    	}
		
    	if (page.sitetype.indexOf('PhpBB') != -1) {
    		topics = getPhpBBTopicsOfUser(page.sitetype);
    		nextPage = getPhpBBNextPageOfUser(page.sitetype);
    	}
		
		if(nextPage.length){
			var maxPage = Number(pageData.maxPage);
			var nowPage = Number(pageData.nowPage);
			if(nowPage<maxPage || maxPage==0){
				chrome.task.addPage({
					url: nextPage,
					savedir: page.savedir,
					savename: '第' + pageData.pageNum +　'页',
					priority: 'high',
					data: JSON.stringify({type: 'search', pageNum: pageData.pageNum+1, path: pageData.path, maxPage: maxPage, nowPage: nowPage+topics.length})
				});
			}
		}
		
		for(i in topics){
			var maxPage = Number(pageData.maxPage);
			var nowPage = Number(pageData.nowPage) + Number(i);
			if(nowPage<maxPage || maxPage==0){
				var topic = topics[i];
				chrome.task.addPage({
					url: topic.url,
					savedir: pageData.path + '/帖子/' + topic.name,
					savename: '帖子',
					data: JSON.stringify({type: 'topic', topicPage: 1})
				});
				
				if (page.sitetype.indexOf('Discuz') != -1) 
					topicCsvText = getDiscuzCsvText(page.sitetype, topic);
				else if(page.sitetype.indexOf('Phpwind') != -1)
					topicCsvText = getPhpwindCsvText(page.sitetype, topic);
				else if (page.sitetype.indexOf('PhpBB') != -1)
					topicCsvText = getPhpBBCsvText(page.sitetype, topic);
					
				chrome.task.fwrite({path: totalTopicCsv, text: topicCsvText});
			}
		}
		
		chrome.task.finishPage();
	}
	
	if(pageData.type == 'topic'){
		if(option.allRemarks){
			var nextPage;
			if (page.sitetype.indexOf('Discuz') != -1)
    			nextPage = getDiscuzNextPageOfTopic(page.sitetype);
    		else if (page.sitetype.indexOf('Phpwind') != -1)
    			nextPage = getPhpwindNextPageOfTopic(page.sitetype);
    		else if (page.sitetype.indexOf('PhpBB') != -1)
    			nextPage = getPhpBBNextPageOfTopic(page.sitetype);
			
			if(nextPage.length){
				chrome.task.addPage({
					url: nextPage,
					savedir: page.savedir,
					savename: '发现帖子第' + (pageData.topicPage+1) + '页评论页',
					data: JSON.stringify({type: 'topic', topicPage: pageData.topicPage+1})
				});
			}
		}
		chrome.task.finishPage();
	}
}