//获取主页中板块的URL和名称
//返回代表每个板块对象信息的数组
function getDiscuzBoards(sitetype, bSort) {
	var boards = [];
	var count = 0;

	if (sitetype == 'Discuz! X3' ||
		sitetype == 'Discuz! X2.5' ||
		sitetype == 'Discuz! X2' ||
		sitetype == 'Discuz! X1.5' ||
		sitetype == 'Discuz! X1') {
		$('.mn .fl_tb').each(function(index, elem) {					//遍历每个板块

			var column_boards = $('.fl_g', $(elem));
			if (column_boards.length) {
				//一行有多个板块
				column_boards.each(function(index, elem1) {
					var board = newBoardInfo();
					board.name = getElementTextSafe(elem1, 'dt a', 0);		//板块名称
					board.url = getElementHrefSafe(elem1, 'dt a', 0);		//板块地址
					board.topics = getElementTextSafe(elem1, 'dd em', 0);	//总主题数
					board.posts = getElementTextSafe(elem1, 'dd em', 1);	//总跟帖数
					board.lastTime = getElementTextSafe(elem1, 'dd a', 0);	//最后发表时间
					board.lastURL = getElementHrefSafe(elem1, 'dd a', 0);	//最后发表地址
					board.today = getElementTextSafe(elem1, 'dt em', 0);		//今日发表

					if (bSort && board.url.indexOf('fid') != -1) {
						board.url = getDiscuzDynamicURL(sitetype, board.url);
					}
					else if (bSort && board.url.indexOf('html') != -1) {
						board.url = getDiscuzDynamicURL(sitetype, board.url);
					}

					//禁用瀑布流形式查看帖子
					if (board.url.length && board.url.indexOf('forum.php?mod=forumdisplay&fid=') != -1)
						board.url += "&forumdefstyle=yes"
					
					boards[count++] = board;
				});
			} else {
				//一行一个板块
				$('tr', $(elem)).each(function(index, elem1) {
					var board = newBoardInfo();
					board.name = getElementTextSafe(elem1, 'td h2 a', 0);
					board.url = getElementHrefSafe(elem1, 'td h2 a', 0);
					board.topics = getElementTextSafe(elem1, 'td.fl_i span.xi2', 0);
					board.posts = getElementTextSafe(elem1, 'td.fl_i span.xg1', 0);
					board.lastURL = getElementHrefSafe(elem1, 'td.fl_by a.xi2', 0);
					board.lastTime = getElementTextSafe(elem1, 'td.fl_by cite span', 0);
					board.desc = getElementTextSafe(elem1, 'td .xg2', 0);

					//禁用瀑布流形式查看帖子
					if (board.url.length && board.url.indexOf('forum.php?mod=forumdisplay&fid=') != -1)
						board.url += "&forumdefstyle=yes"

					boards[count++] = board;
				});
			}
		});
	}
	else if(sitetype == 'Discuz! 7'
	){
		jQuery('tbody[id^="forum"]').each(function(index, elem){					//遍历每个板块
			var board = newBoardInfo();
			board.name = getElementTextSafe(elem, 'tr th .left a', 0);						//板块名称
			board.url = getElementHrefSafe(elem, 'tr th .left a', 0);						//板块地址
			board.topics = getElementTextSafe(elem, 'td em', 0);					//总主题数
			board.posts = getElementTextSafe(elem, 'td.forumnums', 0);			//总跟帖数
			board.lastTime = getElementTextSafe(elem, 'cite span', 0);				//最后发表事件
			board.lastURL = getElementHrefSafe(elem, 'cite a', 0);					//最后发表地址
			board.today = getElementTextSafe(elem, 'tr th em', 0);						//今日发表

			boards[count++] = board;
		});
	}
	else if (sitetype == 'Discuz! 6'){
		jQuery('tbody[id^="forum"]').each(function(index, elem){					//遍历每个板块
			var board = newBoardInfo();
			board.name = getElementTextSafe(elem, 'tr th h2 a', 0);						//板块名称
			board.url = getElementHrefSafe(elem, 'tr th h2 a', 0);						//板块地址
			board.topics = getElementTextSafe(elem, 'tr td.nums', 0);					//总主题数
			board.posts = getElementTextSafe(elem, 'tr td.nums', 1);			//总跟帖数
			board.lastTime = getElementTextSafe(elem, 'cite span', 0);				//最后发表事件
			board.lastURL = getElementHrefSafe(elem, 'cite a', 0);					//最后发表地址
			board.today = getElementTextSafe(elem, 'tr th em', 0);						//今日发表
			
			boards[count++] = board;
		});
	}
	else if (sitetype == 'Discuz! 5'){
		jQuery('tr.row').each(function(index, elem){					//遍历每个板块
			var board = newBoardInfo();
			board.name = getElementTextSafe(elem, 'td.subject a', 0);						//板块名称
			board.url = getElementHrefSafe(elem, 'td.subject a', 0);						//板块地址
			board.topics = getElementTextSafe(elem, 'td.nums', 0);					//总主题数
			board.posts = getElementTextSafe(elem, 'td.nums', 1);			//总跟帖数
			board.lastTime = getElementTextSafe(elem, 'cite span', 0);				//最后发表事件
			board.lastURL = getElementHrefSafe(elem, 'cite a', 0);					//最后发表地址
			board.today = getElementTextSafe(elem, 'th em', 0);						//今日发表
			
			boards[count++] = board;
		});
	}
	return boards;
}

//获取板块下的帖子
//返回代表每个帖子信息的对象的数组
function getDiscuzTopicsOfBoard(sitetype, period) {
	var topics = [];
	var count = 0;

	if (sitetype == 'Discuz! X3' ||
		sitetype == 'Discuz! X2.5' ||
		sitetype == 'Discuz! X2' ||
		sitetype == 'Discuz! X1.5' ||
		sitetype == 'Discuz! X1') {
		$('#threadlist tbody[id]').each(function(index, elem) {						//遍历每篇帖子
			var topic = newTopicInfo();

			topic.name = getElementTextSafe(elem, 'tr th a.xst', 0);				//帖子名称
			topic.url = getElementHrefSafe(elem, 'tr th a.xst', 0);					//帖子地址
			topic.author = getElementTextSafe(elem, 'tr .by cite a', 0);			//发帖人
			topic.authorHome = getElementHrefSafe(elem, 'tr .by cite a', 0);		//发帖人主页
			topic.time = getElementTextSafe(elem, 'tr .by em', 0);					//发帖时间
			topic.views = getElementTextSafe(elem, 'tr .num em', 0);				//浏览数
			topic.replys = getElementTextSafe(elem, 'tr .num a', 0);				//回复数
			topic.lastReply = getElementTextSafe(elem, 'tr .by cite a', 1);			//最后回复人
			topic.lastReplyHome = getElementHrefSafe(elem, 'tr .by cite a', 1);		//最后回复人的主页
			topic.lastTime = getElementTextSafe(elem, 'tr .by em', 1);				//最后回复时间
			topic.lastURL = getElementHrefSafe(elem, 'tr .by em a', 0);				//最后回复的内容

			if (topic.name.length > 0 && topic.url.length > 0) 
				topics[count++] = topic;
		});
	}
	else if(sitetype == 'Discuz! 7') {
			$('.threadlist tbody[id]').each(function(index, elem) {						//遍历每篇帖子
			var topic = newTopicInfo();

			topic.name = getElementTextSafe(elem, 'tr th a', 0);						//帖子名称
			topic.url = getElementHrefSafe(elem, 'tr th a', 0);							//帖子地址
			topic.author = getElementTextSafe(elem, 'tr td.author cite a', 0);			//发帖人
			topic.authorHome = getElementHrefSafe(elem, 'tr td.author cite a', 0);		//发帖人主页
			topic.time = getElementTextSafe(elem, 'tr td.author em', 0);				//发帖时间
			topic.views = getElementTextSafe(elem, 'tr td.nums em', 0);					//浏览数
			topic.replys = getElementTextSafe(elem, 'tr td.nums strong', 0);				//回复数
			topic.lastReply = getElementTextSafe(elem, 'tr td.lastpost cite a', 0);			//最后回复人
			topic.lastReplyHome = getElementHrefSafe(elem, 'tr td.lastpost cite a', 0);		//最后回复人的主页
			topic.lastTime = getElementTextSafe(elem, 'tr td.lastpost em a', 0);			//最后回复时间
			topic.lastURL = getElementHrefSafe(elem, 'tr td.lastpost em a', 0);				//最后回复的内容
			
			if (topic.name.length > 0 && 
				topic.url.length > 0) {
				topics[count++] = topic;
			}
		});
	}
	else if (sitetype == 'Discuz! 6') {
		jQuery(document.querySelectorAll('tbody[id^="normalthread"]')).each(function(index, elem) {						//遍历每篇帖子
			var topic = newTopicInfo();

			topic.name = getElementTextSafe(elem, 'tr th a', 0);						//帖子名称
			topic.url = getElementHrefSafe(elem, 'tr th a', 0);							//帖子地址
			topic.author = getElementTextSafe(elem, 'tr td.author cite a', 0);			//发帖人
			topic.authorHome = getElementHrefSafe(elem, 'tr td.author cite a', 0);		//发帖人主页
			topic.time = getElementTextSafe(elem, 'tr td.author em', 0);				//发帖时间
			topic.views = getElementTextSafe(elem, 'tr td.nums em', 0);					//浏览数
			topic.replys = getElementTextSafe(elem, 'tr td.nums strong', 0);				//回复数
			topic.lastReply = getElementTextSafe(elem, 'tr td.lastpost cite a', 0);			//最后回复人
			topic.lastReplyHome = getElementHrefSafe(elem, 'tr td.lastpost cite a', 0);		//最后回复人的主页
			topic.lastTime = getElementTextSafe(elem, 'tr td.lastpost em a', 0);			//最后回复时间
			topic.lastURL = getElementHrefSafe(elem, 'tr td.lastpost em a', 0);				//最后回复的内容
			
			if (topic.name.length > 0 && 
				topic.url.length > 0) {
				topics[count++] = topic;
			}
		});
	}
	else if (sitetype == 'Discuz! 5'){
			$('.spaceborder tbody').each(function(index, elem) {						//遍历每篇帖子
			var topic = newTopicInfo();

			topic.name = getElementTextSafe(elem, 'tr td.f_title a', 0);						//帖子名称
			topic.url = getElementHrefSafe(elem, 'tr td.f_title a', 0);							//帖子地址
			topic.author = getElementTextSafe(elem, 'tr td.f_author a', 0);			//发帖人
			topic.authorHome = getElementHrefSafe(elem, 'tr td.author a', 0);		//发帖人主页
			topic.time = getElementTextSafe(elem, 'tr td.author em', 0);				//发帖时间
			topic.views = getElementTextSafe(elem, 'tr td.nums em', 0);					//浏览数
			topic.replys = getElementTextSafe(elem, 'tr td.nums strong', 0);				//回复数
			topic.lastReply = getElementTextSafe(elem, 'tr td.lastpost cite a', 0);			//最后回复人
			topic.lastReplyHome = getElementHrefSafe(elem, 'tr td.lastpost cite a', 0);		//最后回复人的主页
			topic.lastTime = getElementTextSafe(elem, 'tr td.lastpost em a', 0);			//最后回复时间
			topic.lastURL = getElementHrefSafe(elem, 'tr td.lastpost em a', 0);				//最后回复的内容
			
			if (topic.name.length > 0 && 
				topic.url.length > 0) {
				topics[count++] = topic;
			}
		});
	}

	return topics;
}

//获取板块中的子版块
//FIXME：目前仅支持Discuz! X系列论坛
function getDiscuzSubBoardsOfBoard(sitetype) {
	var subBoards = [];
	var count = 0;

	if (/Discuz! X/.test(sitetype)) {
		return getDiscuzBoards(sitetype);
	}

	return subBoards;
}

//获取板块的下一页的链接
//如果是最后一页或者未发现返回空字符串
function getDiscuzNextPageOfBoard(sitetype) {
	if (sitetype == 'Discuz! X3' ||
		sitetype == 'Discuz! X2.5' ||
		sitetype == 'Discuz! X2' ||
		sitetype == 'Discuz! X1.5' ||
		sitetype == 'Discuz! X1') {
		return getElementHrefSafe('', '#ct .pg a:contains("下一页")', 0);
	}
	else if (sitetype == 'Discuz! 7') {
		return getElementHrefSafe('', '.pages_btns a:contains("下一页")', 0);
	}
	else if (sitetype == 'Discuz! 6' || 
			 sitetype == 'Discuz! 5') {
		return getElementHrefSafe('', '.pages_btns a:contains("››")', 0);
	} 
	return '';
}

//获取帖子中的附件
function getDiscuzAttachmentsOfTopic(sitetype) {
	var attachs = [];
	var count = 0;

	if (/Discuz! X/.test(sitetype) || 
		sitetype == 'Discuz! 7' || 
		sitetype == 'Discuz! 6') {	// x3, x2

		$('#ct .pattl').each(function(index, elem) {
			var attach = newAttachment();

			attach.url = getElementHrefSafe(elem, '.attnm a', 0);
			attach.name = getElementTextSafe(elem, '.attnm a', 0);

			attachs[count++] = attach;
		});
		// x2.5, x1.5, x1,
		$('span[id^="att"]').each(function(index, elem) {
			var attach = newAttachment();
		
			attach.url = getElementHrefSafe(elem, 'a', 0);
			attach.name = getElementTextSafe(elem, 'a', 0);

			attachs[count++] = attach;
		});
	}

	return attachs;
}

//获取帖子下一页的链接
//如果当前页面是最后一页或者错误返回空字符串
function getDiscuzNextPageOfTopic(sitetype) {
		return getDiscuzNextPageOfBoard(sitetype);
}

//关闭页面上的广告、悬浮窗口等
function preDiscuzStart(sitetype) {
	if (sitetype == 'Discuz! X3') {
		$('.focus.plugin a:contains("关闭")').each(function(index, elem) {
			elementMouseEvent(elem, 'Click');
		});
	}
}

function getDiscuzUsers(siteType, userList, mode){
	var userInfos = [];
	var users;
	var host = window.location.href;
	var pos = host.lastIndexOf('/');
	if (pos != -1)
		host = host.substring(0, pos+1);
	else
		host = host + '/';
	
	users = userList.split("\n");
	for(i in users){
		var user = newUserInfo();
		
		if(siteType == 'Discuz! 3'){
			user.name = users[i];
			if(mode == 'asUser')
				user.search = host + 'search.php?formhash=2b4fc943&srchtxt=&srchtype=title&searchsubmit=%CB%D1%CB%F7&st=on&srchuname=' + users[i] + '&srchfilter=all&srchfrom=0&before=&orderby=lastpost&ascdesc=desc&srchfid%5B%5D=all';
			else if(mode == 'asId')
				user.search = host + 'search.php?formhash=2b4fc943&srchtxt=&srchtype=title&searchsubmit=%CB%D1%CB%F7&st=on&searchid=' + users[i] + '&srchfilter=all&srchfrom=0&before=&orderby=lastpost&ascdesc=desc&srchfid%5B%5D=all';
		}
		
		if(siteType == 'Discuz! 4' ||
			siteType == 'Discuz! 5' ||
			siteType == 'Discuz! 6' ||
			siteType == 'Discuz! 7'){
			user.name = users[i];
			if(mode == 'asUser')
				user.search =  host + 'search.php?formhash=2b4fc943&srchtxt=&srchuname=' + users[i] + '&srchfid=all&srchtype=title&srchfrom=0&before=&orderby=lastpost&ascdesc=desc&searchsubmit=%E6%8F%90+%C2%A0+%E4%BA%A4';
			else if(mode == 'asId')
				user.search =  host + 'search.php?formhash=2b4fc943&srchtxt=&searchid=' + users[i] + '&srchfid=all&srchtype=title&srchfrom=0&before=&orderby=lastpost&ascdesc=desc&searchsubmit=%E6%8F%90+%C2%A0+%E4%BA%A4';
			}
		
		if(siteType == 'Discuz! X1' ||
			siteType == 'Discuz! X1.5' ||
			siteType == 'Discuz! X2' ||
			siteType == 'Discuz! X2.5' ||
			siteType == 'Discuz! X3'){
			user.name = users[i];
			if(mode == 'asUser')
				user.search = host + "home.php?mod=space&username=" + users[i] + "&do=thread&view=me&from=space";
			else if(mode == 'asId')
				user.search = host + "home.php?mod=space&uid=" + users[i] + "&do=thread&view=me&from=space";
		}
		
		userInfos[i] = user;
	}
	
	return userInfos;
}

function getDiscuzTopicsOfUser(siteType){
	var topices = [];
	if(siteType == 'Discuz! X1' ||
		siteType == 'Discuz! X1.5' ||
		siteType == 'Discuz! X2' ||
		siteType == 'Discuz! X2.5' ||
		siteType == 'Discuz! X3'){
		
		var allTable = $('.tl tr');
		var TableSize = allTable.size()-1;
		var author = getAuthor(siteType);
		var authorHome = getAuthorHome(siteType);
		
		for(i=0; i<TableSize; i++){
			var topice = newTopicInfo();
			topice.board = getElementTextSafe(allTable[i+1], 'td a', 1);			//所属板块
			topice.name = getElementTextSafe(allTable[i+1], 'th a', 0);				//帖子名称
			topice.url = getElementHrefSafe(allTable[i+1], 'th a', 0);				//帖子地址
			topice.views = getElementTextSafe(allTable[i+1], '.num a', 0);			//浏览数
			topice.replys = getElementTextSafe(allTable[i+1], '.num em', 0);		//回复数
			topice.lastReply = getElementTextSafe(allTable[i+1], 'cite a', 0);		//最后发帖人
			topice.lastReplyHome = getElementHrefSafe(allTable[i+1], 'cite a', 0);	//最后发帖人的主页面
			topice.lastTime = getElementTextSafe(allTable[i+1], 'em a', 0);			//最后回复时间
			topice.lastURL = getElementHrefSafe(allTable[i+1], 'em a', 0);			//最后回复地址
			topice.author = author;													//发帖人
			topice.authorHome = authorHome;											//发帖人主页面
			topices[i] = topice;
		}
	}
	
	if(siteType == 'Discuz! 7'){
		
		var allTable = $('.datatable tbody');
		var TableSize = allTable.size();
		
		for(i=0; i<TableSize; i++){
			var topice = newTopicInfo();
			topice.author = getElementTextSafe(allTable[i], '.author cite a', 0);			//发帖人
			topice.authorHome = getElementHrefSafe(allTable[i], '.author cite a', 0);		//发帖人主页面
			topice.board = getElementTextSafe(allTable[i], '.forum a', 0);					//所属板块
			topice.name = getElementTextSafe(allTable[i], '.subject a', 0);					//帖子名称
			topice.url = getElementHrefSafe(allTable[i], '.subject a', 0);					//帖子地址
			topice.time = getElementTextSafe(allTable[i], '.author em', 0);					//发帖时间
			topice.views = getElementTextSafe(allTable[i], '.nums em', 0);					//浏览数
			topice.replys = getElementTextSafe(allTable[i], '.nums strong', 0);				//回复数
			topice.lastReply = getElementTextSafe(allTable[i], '.lastpost cite a', 0);		//最后发帖人
			topice.lastReplyHome = getElementHrefSafe(allTable[i], '.lastpost cite a', 0);	//最后发帖人的主页面
			topice.lastTime = getElementTextSafe(allTable[i], '.lastpost em a', 0);			//最后回复时间
			topice.lastURL = getElementHrefSafe(allTable[i], '.lastpost em a', 0);			//最后回复地址
			topices[i] = topice;
		}
		
	}
	
	if(siteType == 'Discuz! 6'){
		
		var allTable = $('.mainbox.threadlist tbody');
		var TableSize = allTable.size();
		
		for(i=0; i<TableSize; i++){
			var topice = newTopicInfo();
			topice.author = getElementTextSafe(allTable[i], '.author cite a', 0);			//发帖人
			topice.authorHome = getElementHrefSafe(allTable[i], '.author cite a', 0);		//发帖人主页面
			topice.board = getElementTextSafe(allTable[i], '.forum a', 0);					//所属板块
			topice.name = getElementTextSafe(allTable[i], 'th >a', 0);						//帖子名称
			topice.url = getElementHrefSafe(allTable[i], 'th >a', 0);						//帖子地址
			topice.time = getElementTextSafe(allTable[i], '.author em', 0);					//发帖时间
			topice.views = getElementTextSafe(allTable[i], '.nums em', 0);					//浏览数
			topice.replys = getElementTextSafe(allTable[i], '.nums strong', 0);				//回复数
			topice.lastReply = getElementTextSafe(allTable[i], '.lastpost cite a', 0);		//最后发帖人
			topice.lastReplyHome = getElementHrefSafe(allTable[i], '.lastpost cite a', 0);	//最后发帖人的主页面
			topice.lastTime = getElementTextSafe(allTable[i], '.lastpost em a', 0);			//最后回复时间
			topice.lastURL = getElementHrefSafe(allTable[i], '.lastpost em a', 0);			//最后回复地址
			topices[i] = topice;
		}
		
	}
	
	return topices;
}

function getDiscuzNextPageOfUser(siteType){
	return getDiscuzNextPageOfBoard(siteType);
}

function getAuthor(siteType){
	if(siteType == 'Discuz! X3'){
		return getElementTextSafe('', '.sd .xs2 a', 0);
	}else if(siteType == 'Discuz! X2.5'){
		return getElementTextSafe('', '.h.cl .mt', 0);
	}else if(siteType == 'Discuz! X2'){
		return getElementTextSafe('', '.sd .hm h2 a', 0);
	}else if(siteType == 'Discuz! X1.5'){
		return getElementTextSafe('', '.sd .xs2 a', 0);
	}else if(siteType == 'Discuz! X1'){
		return getElementTextSafe('', '.sd .avt.avtm h2', 0);
	}
}

function getAuthorHome(siteType){
	if(siteType == 'Discuz! X3'){
		return getElementHrefSafe('', '.sd .xs2 a', 0);
	}else if(siteType == 'Discuz! X2.5'){
		return getElementHrefSafe('', '.h.cl >p a', 0);
	}else if(siteType == 'Discuz! X2'){
		return getElementHrefSafe('', '.sd .hm h2 a', 0);
	}else if(siteType == 'Discuz! X1.5'){
		return getElementHrefSafe('', '.sd .xs2 a', 0);
	}else if(siteType == 'Discuz! X1'){
		return getElementHrefSafe('', '.sd .avt.avtm a', 0);
	}
}

function getDiscuzCsvHeader(siteType){
	if(siteType == 'Discuz! X1' ||
		siteType == 'Discuz! X1.5' ||
		siteType == 'Discuz! X2' ||
		siteType == 'Discuz! X2.5' ||
		siteType == 'Discuz! X3')
		return '发帖人, 发帖人主页面, 所属板块, 帖子名称, 帖子地址, 浏览数, 回复数, 最后发帖人, 最后发帖人的主页面, 最后回复时间, 最后回复地址\n';
	else
		return '发帖人, 发帖人主页面, 所属板块, 帖子名称, 帖子地址, 发帖时间, 浏览数, 回复数, 最后发帖人, 最后发帖人的主页面, 最后回复时间, 最后回复地址\n';;
}

function getDiscuzCsvText(siteType, topic){
	if(siteType == 'Discuz! X1' ||
		siteType == 'Discuz! X1.5' ||
		siteType == 'Discuz! X2' ||
		siteType == 'Discuz! X2.5' ||
		siteType == 'Discuz! X3')
		return	topic.author + ', ' +
				topic.authorHome + ', ' +
				topic.board + ', ' +
				topic.name + ', ' +
				topic.url + ', ' +
				topic.views + ', ' +
				topic.replys + ', ' +
				topic.lastReply + ', ' +
				topic.lastReplyHome + ', ' +
				topic.lastTime + ', ' +
				topic.lastURL + '\n';
	else
		return	topic.author + ', ' +
				topic.authorHome + ', ' +
				topic.board + ', ' +
				topic.name + ', ' +
				topic.url + ', ' +
				topic.time + ', ' +
				topic.views + ', ' +
				topic.replys + ', ' +
				topic.lastReply + ', ' +
				topic.lastReplyHome + ', ' +
				topic.lastTime + ', ' +
				topic.lastURL + '\n';
}

// Discuz! 4,5,6,7
// http://bbs.cchicc.com/forumdisplay.php?fid=6
// http://www.yinhe1986.cn/discuz/forumdisplay.php?fid=38
// http://www.yinhe1986.cn/discuz/forumdisplay.php?fid=38&filter=0&orderby=dateline&ascdesc=DESC

// Discuz! X1, X2, X2.5, X3
// http://bbs.gfan.com/forum-1272-1.html
// http://taling.hnie.edu.cn/bbs/forum.php?mod=forumdisplay&fid=653

// http://bbs.gfan.com/forum.php?mod=forumdisplay&fid=1272&filter=author&orderby=dateline

// Phpwind 9.0
// http://bbs.typhoon.gov.cn/index.php?c=thread&fid=79
// http://bbs.typhoon.gov.cn/index.php?c=thread&fid=79&orderby=postdate

// Phpwind 9.0
// http://www.phpwind.net/thread/147
// http://www.phpwind.net/thread/147&orderby=postdate

//返回一个动态url
function getDiscuzDynamicURL(sitetype, url) {
	if (sitetype == 'Discuz! X3' ||
		sitetype == 'Discuz! X2.5' ||
		sitetype == 'Discuz! X2' ||
		sitetype == 'Discuz! X1.5' ||
		sitetype == 'Discuz! X1') {

		if (url.indexOf('fid') != -1) {
			return url += "&filter=author&orderby=dateline";
		}
		else if (url.indexOf('html') != -1) {
			var list = url.split('-');
			return list[0] + '.php?mod=forumdisplay&fid=' + list[1] + "&filter=author&orderby=dateline";
		}
	}
	/* else if (sitetype == '') {

	} */

}