//论坛按板块下载的主逻辑
function ProcessByBoard(page) {
    var pageData = page.data.length ? JSON.parse(page.data) : {};
    var option = page.option.length ? JSON.parse(page.option) : {};
	
    if(option.filter) 
    	option.filter = decodeURIComponent(decodeURIComponent(option.filter));

    if (page.sitetype.indexOf('Discuz') != -1)
    	preDiscuzStart(page.sitetype)

	//本页面是论坛首页，解析其下的板块
    if(page.first) {
  		chrome.task.fopen({path : boardCsv, mode : 'a', header: boardCsvHeader});
		chrome.task.fopen({path : totalTopicCsv, mode : 'a', header: topicCsvHeader});

    	output('论坛类型: ' + page.sitetype);
    	output('正在分析主页中的版块...', 1, true);
    	var bSort = option.period != 'all';
    	var boards = [];
    	if (page.sitetype.indexOf('Discuz') != -1)
    		boards = getDiscuzBoards(page.sitetype, bSort);
    	else if (page.sitetype.indexOf('Phpwind') != -1)
			boards = getPhpwindBoards(page.sitetype, bSort);
    	else if (page.sitetype.indexOf('PhpBB') != -1)
    		boards = getPhpBBBoards(page.sitetype, bSort);
		
		var count = 0;
		for (i in boards) {
			var board = boards[i];
			board.name = escapePath(board.name);

			//仅下载指定的板块
			if(option.filter.length &&
          	   option.filter.indexOf(board.name) == -1) {
				continue;
			}
			
			var boardDir = '/' + boardPrefix + board.name + '/';
			chrome.task.addPage({
				url: board.url, 
				savedir: boardDir + '第1页',	 		//该板块的保存目录 
				savename: board.name,
				priority: 'low',						//一个板块下载完成后再下载另一个板块
				output: boardPrefix + (++count) + ': ' + board.name,
				data: JSON.stringify({
					type: 'board', 
					boardName: board.name, 
					boardDir: boardDir,
					boardPage: 1})
			});

			//后台统计数据
			sendMessage('board', board);

			WriteBoardCSV(boardCsv, board);
        }

        //关闭板块列表文件
        chrome.task.fclose({path: boardCsv});

      	//finish first page
    } else if (pageData.type == 'board' ||
    		   pageData.type == 'subboard') {

    	if (pageData.type == 'board') {
   			output('正在分析' + boardPrefix + pageData.boardName + '第' + pageData.boardPage + '页中的帖子...', 1, true);
    	} else {
    		output('正在分析' + boardPrefix + pageData.boardName + subboardPrefix + pageData.subboardName +  '第' + pageData.subboardPage + '页中的帖子...', 1, true);
    	}

   		var nextpage;
    	var topics = [];
    	var subboards = [];

    	if (page.sitetype.indexOf('Discuz') != -1) {
    		topics = getDiscuzTopicsOfBoard(page.sitetype);	
    		if (topics.length != 0) 
    			nextpage = getDiscuzNextPageOfBoard(page.sitetype);
    		if(pageData.type == 'board' && pageData.boardPage == 1)
    				subboards = getDiscuzSubBoardsOfBoard(page.sitetype);
    	}
    	else if (page.sitetype.indexOf('Phpwind') != -1) {
    		topics = getPhpwindTopicsOfBoard(page.sitetype);
    		if (topics.length != 0)
    			nextpage = getPhpwindNextPageOfBoard(page.sitetype);
    		if (pageData.type == 'board' && pageData.boardPage == 1)
    			subboards = getPhpwindSubBoardsOfBoard(page.sitetype);
    	}
    	else if (page.sitetype.indexOf('PhpBB') != -1) {
    		topics = getPhpBBTopicsOfBoard(page.sitetype);
    		if (topics.length != 0)
    			nextpage = getPhpBBNextPageOfBoard(page.sitetype);
    		if (pageData.type == 'board' && pageData.boardPage == 1)
    			subboards = getPhpBBSubBoardsOfBoard(page.sitetype);
    	}
    	
    	//添加子版块
    	var count = 0;
    	if (pageData.type == 'board') {
    		for (i in subboards) {
    			var subboard = subboards[i];
    			subboard.name = escapePath(subboard.name);

    			var subboardDir = pageData.boardDir + subboardPrefix + subboard.name + '/';

    			chrome.task.addPage({
					url: subboard.url, 
					savedir: subboardDir + '第1页',
					savename: subboard.name,
					priority: 'low',		//将子版块放入低优先级队列首部，以实现下载完本大板块的帖子后
					front: true,			//马上下载其包含的子版块
					output: subboardPrefix+ (++count) + ': ' + subboard.name,
					data: JSON.stringify({
						type: 'subboard', 
						boardName: pageData.boardName,
						boardDir: pageData.boardDir,
						subboardName: subboard.name,
						subboardDir: subboardDir, 
						subboardPage: 1})
				});
    		}
    	}
    	
    	var boardTopicCsv = pageData.boardDir + '帖子列表.csv';
    	var subboardTopicCsv = pageData.subboardDir + '帖子列表.csv';

    	//添加该板块页面中的帖子
		count = 0;
		for (i in topics) {
			var topic = topics[i];
			topic.name = escapePath(topic.name);
			var saveDir = page.savedir + topicPrefix + topic.name;

			if (option.period != 'all') {
				if ((option.period == 'day' && !withinDay(topic.time)) ||
					(option.period == 'week' && !withinWeek(topic.time)) ||
					(option.period == 'month' && !withinMonth(topic.time)) ||
					(option.period == 'year' && !withinYear(topic.time)))
					continue;
			}

			chrome.task.addPage({
				url: topic.url, 
				savedir: saveDir, 		//将帖子保存到板块目录下
				savename: '帖子',		//帖子的保存文件名
				priority: 'high',		//优先下载帖子
				force: true,			//置顶帖
				output: topicPrefix + (++count) + ': ' + topic.name,	//输出信息
				data: JSON.stringify({type: 'topic', topicPage: 1})
			});

			//记录帖子列表文件（全局和各个板块的）
			if (pageData.boardPage == 1)
				chrome.task.fopen({path : boardTopicCsv, mode : 'a', header: topicCsvHeader});

			var subboardName;
			if (pageData.type == 'subboard')
				subboardName = pageData.subboardName;
			else 
				subboardName = '';

			topic.board = pageData.boardName;
			topic.subboard = subboardName;

			//统计帖子数据
			sendMessage('topic', topic);

			WriteTopicCSV(boardTopicCsv, topic, pageData.boardName, subboardName, saveDir);
			WriteTopicCSV(totalTopicCsv, topic, pageData.boardName, subboardName, saveDir);

			//记录子版块帖子列表文件
			if (pageData.type == 'subboard') {
				if (pageData.subboardPage == 1)
					chrome.task.fopen({path : subboardTopicCsv, mode : 'a', header: topicCsvHeader});

				WriteTopicCSV(subboardTopicCsv, topic, pageData.boardName, subboardName, saveDir);
			}
		}
		
		var canAddNextPage = true;
		var discardCurrentPage = false;

		//如果当前板块页没有符合指定时间内的帖子
		//直接丢弃当前页面并关闭该板块打开的所有文件
		if (option.period != 'all' && count == 0) {
			canAddNextPage = false;
			discardCurrentPage = true;
		}

		if (option.max != '' && count >= option.max - 1) {
			canAddNextPage = false;
		}

		//if ((pageData.type == 'board' && pageData.boardPage >= 2) ||
		//	(pageData.type == 'subboard' && pageData.subboardPage >= 2)) {
		//	canAddNextPage = false;
		//}

		//添加[子]板块的下一页
		if (nextpage.length && canAddNextPage) {
			var NextPageSaveDir;
			var NextPageData;
			var NextPageOutput;

			if (pageData.type == 'board') {
				NextPageSaveDir = pageData.boardDir + '第' + (pageData.boardPage+1) + '页';
				NextPageData = JSON.stringify({type: 'board', boardName: pageData.boardName, boardDir: pageData.boardDir,
					boardPage: (pageData.boardPage+1)});
				NextPageOutput = boardPrefix + '第' + (pageData.boardPage+1) + '页';
				TopicCsv = boardTopicCsv;
			} else {
				NextPageSaveDir = pageData.subboardDir + '第' + (pageData.subboardPage + 1) + '页';
				NextPageData = JSON.stringify({type: 'subboard', boardName: pageData.boardName, boardDir: pageData.boardDir,
					subboardName: pageData.subboardName,  subboardDir: pageData.subboardDir, subboardPage: (pageData.subboardPage+1)});
				NextPageOutput = subboardPrefix + '第' + (pageData.subboardPage+1) + '页';
				TopicCsv = subboardTopicCsv;
			}

           chrome.task.addPage({
				url: nextpage, 
				savedir: NextPageSaveDir,
				output: NextPageOutput,
				data: NextPageData
			});

		} else {
			//[子]板块已分析完毕，关闭日志文件
			//FIXME: 此举会导致子版块的帖子列表无法写入主版块的帖子列表中
			//因为子版块是在主版块完成之后进行的，而此时主版块帖子列表已经关闭
			if (pageData.type == 'board')
				chrome.task.fclose({path: boardTopicCsv});
			else
				chrome.task.fclose({path: subboardTopicCsv});
		}

		//finish [sub]board process
		chrome.task.finishPage({discard : discardCurrentPage});

    } else if(pageData.type == 'topic') {
    	//帖子附件
    	if ( option.attachment) {
    		var attachs = [];
    		if (page.sitetype.indexOf('Discuz') != -1)
    			attachs = getDiscuzAttachmentsOfTopic(page.sitetype);
    		else if (page.sitetype.indexOf('Phpwind') != -1)
				attachs = getPhpwindAttachmentsOfTopic(page.sitetype);
    		else if (page.sitetype.indexOf('PhpBB') != -1)
    			attachs = getPhpBBAttachmentsOfTopic(page.sitetype);

			var count = 0;
			for (i in attachs) {
				var attach = attachs[i];
				attach.name = escapePath(attach.name);

				output('发现附件' + (++count) + ': ' + attach.name, 2, true);
	
				chrome.task.download({
					url: attach.url,
					savedir: page.savedir,
					savename: attach.name
				});
			}
    	}

    	//帖子评论页
    	if(option.allRemarks) {
    		var nextpage;
    		if (page.sitetype.indexOf('Discuz') != -1)
    			nextpage = getDiscuzNextPageOfTopic(page.sitetype);
    		else if (page.sitetype.indexOf('Phpwind') != -1)
    			nextpage = getPhpwindNextPageOfTopic(page.sitetype);
    		else if (page.sitetype.indexOf('PhpBB') != -1)
    			nextpage = getPhpBBNextPageOfTopic(page.sitetype);

    		if (nextpage.length) {
            	chrome.task.addPage({
					url: nextpage,
					savedir: page.savedir, 
					savename : '第' + (pageData.topicPage+1) + '页',
					priority: 'high',
					output: '发现帖子第' + (pageData.topicPage+1) + '页评论页',
					data: JSON.stringify({type: 'topic', topicPage: pageData.topicPage+1}) 
				});		
    		}
    	}
    	//finish topic process
    }

    chrome.task.finishPage();
}