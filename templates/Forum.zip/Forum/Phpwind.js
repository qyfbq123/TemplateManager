//获取主页中板块的URL和名称
//返回代表每个板块对象信息的数组

function getPhpwindBoards(sitetype, bSort) {
	var boards = [];
	var count = 0;
	if (sitetype == 'Phpwind 9') {
		if ($('table:visible').attr('summary') == "横排版块排序"){
			$('.forum_page .forum_group .ct th').each(function(index, elem){		//遍历每个板块
			var board = newBoardInfo();
			board.name = getElementTextSafe(elem, 'a', 0);							//板块名称
			board.url = getElementHrefSafe(elem, 'a', 0);							//板块地址
			board.topics = elem.textContent.split("\n")[2].split("，")[0];			//总主题数
			board.posts = elem.textContent.split("\n")[2].split("，")[1];			//总跟帖数
			board.lastTime = getElementTextSafe(elem, 'a span', 0);					//最后发表时间
			board.lastURL = getElementHrefSafe(elem, 'a', 1);						//最后发表地址
			board.today = getElementTextSafe(elem, 'span', 0);						//今日发表
			
			if (bSort) {
				board.url = getPhpwindDynamicURL(sitetype, board.url);
			}

			boards[count++] = board;
		});
		}
		else if ($('table:visible').attr('summary') == "竖排版块排序"){
			$('.forum_page .forum_group .ct tr').each(function(index, elem){//遍历每个板块
			var board = newBoardInfo();
			
			board.name = getElementTextSafe(elem, 'th a', 0);				//板块名称
			board.url = getElementHrefSafe(elem, 'th a', 0);				//板块地址
			board.topics = getElementTextSafe(elem, 'td', 0).split("/")[0];			//总主题数
			board.posts = getElementTextSafe(elem, 'td', 0).split("/")[1];				//总跟帖数
			board.lastTime = getElementTextSafe(elem, 'td.last a.last_name', 0);		//最后发表时间
			board.lastURL = getElementHrefSafe(elem, 'td.last a.last_name', 1);		//最后发表地址
			board.today = getElementTextSafe(elem, 'th span', 0);				//今日发表
			
			if (bSort) {
				board.url = getPhpwindDynamicURL(sitetype, board.url);
			}

			boards[count++] = board;
		});
		}
	}
	else if (sitetype == 'Phpwind 8') {
		$('th[id^= "fid"]').each(function(index, elem){					//遍历每个板块
			var board = newBoardInfo();
			
			board.name = getElementTextSafe(elem, '.forumT a', 0);				//板块名称
			board.url = getElementHrefSafe(elem, '.forumT a', 0);				//板块地址
			board.topics = getElementTextSafe(elem, 'p.fNum span', 0);		//总主题数
			board.posts = getElementTextSafe(elem, 'p.fNum', 0);		//总跟帖数
			board.lastTime = getElementTextSafe(elem, 'p.fNum a', 0);		//最后发表时间
			board.lastURL = getElementHrefSafe(elem, 'p.fNum a', 0);		//最后发表地址
			board.today = getElementTextSafe(elem, 'span', 0);		//今日发表
			if (bSort && board.url.indexOf('fid=') != -1) {
				board.url = getPhpwindDynamicURL(sitetype, board.url);
			}
			else if ( bSort && board.url.indexOf('html') != -1) {
				board.url = getPhpwindDynamicURL(sitetype, board.url);
			}

			boards[count++] = board;
		});
		$('tr[id^= "fid"]').each(function(index, elem){					//遍历每个板块
			var board = newBoardInfo();
			
			board.name = getElementTextSafe(elem, '.forumT a', 0);				//板块名称
			board.url = getElementHrefSafe(elem, '.forumT a', 0);				//板块地址
			board.topics = getElementTextSafe(elem, 'num tac em', 0);			//总主题数
			board.posts = getElementTextSafe(elem, 'num tac em', 1);	//总跟帖数
			board.lastTime = getElementTextSafe(elem, 'td.re p.fnum', 0);		//最后发表时间
			board.lastURL = getElementHrefSafe(elem, 'td.re p.fnum a', 0);		//最后发表地址
			board.today = getElementTextSafe(elem, 'span', 0);					//今日发表
			if (bSort && board.url.indexOf('fid=') != -1) {
				board.url = getPhpwindDynamicURL(sitetype, board.url);
			}
			else if ( bSort && board.url.indexOf('html') != -1) {
				board.url = getPhpwindDynamicURL(sitetype, board.url);
			}

			boards[count++] = board;
		});
	}
	else if (sitetype == 'Phpwind 7'){
		$('tr[id^= "fid"]').each(function(index, elem){					//遍历每个板块
			var board = newBoardInfo();
			
			board.name = getElementTextSafe(elem, 'th a[id^= "fn"]', 0);		//板块名称
			board.url = getElementHrefSafe(elem, 'th a[id^= "fn"]', 0);			//板块地址
			board.topics = getElementTextSafe(elem, 'td.f10', 0).split('/')[0];			//总主题数
			board.posts = getElementTextSafe(elem, 'td.f10', 0).split('/')[1].replace('\n', '');		//总跟帖数
			board.lastTime = getElementTextSafe(elem, 'th .gray2 span.f9', 0);		//最后发表时间
			board.lastURL = getElementHrefSafe(elem, 'th .a2', 0);				//最后发表地址
			board.today = getElementTextSafe(elem, 'span', 0);					//今日发表
			
			boards[count++] = board;
		});	
		$('td[id^= "fid"]').each(function(index, elem){					//遍历每个板块
			var board = newBoardInfo();

			board.name = getElementTextSafe(elem, 'td a', 0);				//板块名称
			board.url = getElementHrefSafe(elem, 'td a', 0);				//板块地址
			board.topics = getElementTextSafe(elem, 'num tac em', 0);			//总主题数
			board.posts = getElementTextSafe(elem, 'num tac em', 1);	//总跟帖数
			board.lastTime = getElementTextSafe(elem, 'td span', 2);		//最后发表时间
			board.lastURL = getElementHrefSafe(elem, 'td a', 0);		//最后发表地址
			board.today = getElementTextSafe(elem, 'td span', 0);					//今日发表
			
			boards[count++] = board;
		});	
	}
	else if (sitetype == 'Phpwind 6') {
		$('.tr3.f_one').each(function(index, elem){					//遍历每个板块
			var board = newBoardInfo();

			board.name = getElementTextSafe(elem, 'th a', 0);					//板块名称
			board.url = getElementHrefSafe(elem, 'th a', 0);					//板块地址
			if (!board.name.length) {
				board.name = getElementTextSafe(elem, 'th a', 1);
				board.url = getElementHrefSafe(elem, 'th a', 1);			
			}
			board.topics = getElementTextSafe(elem, 'td span.f10', 0);			//总主题数
			board.posts = getElementTextSafe(elem, 'td span.f10', 1);			//总跟帖数
			board.lastTime = getElementTextSafe(elem, '.f9.gray', 0);			//最后发表时间
			board.lastURL = getElementHrefSafe(elem, 'th a.a2', 0);				//最后发表地址
			board.today = getElementTextSafe(elem, 'th span', 0);				//今日发表
			board.desc = getElementTextSafe(elem, 'th .smalltxt', 0);			//板块描述

			boards[count++] = board;
		});	
	}
	else if (sitetype == 'Phpwind 5') {
		$('.tr3.f_one').each(function(index, elem){					//遍历每个板块
			var board = newBoardInfo();
			
			board.name = getElementTextSafe(elem, 'th a', 1);					//板块名称
			board.url = getElementHrefSafe(elem, 'th a', 1);					//板块地址
			board.topics = getElementTextSafe(elem, 'td span.f10', 0);			//总主题数
			board.posts = getElementTextSafe(elem, 'td span.f10', 1);			//总跟帖数
			board.lastTime = getElementTextSafe(elem, '.f9.gray', 0);			//最后发表时间
			board.lastURL = getElementHrefSafe(elem, 'th a.a2', 0);				//最后发表地址
			board.today = getElementTextSafe(elem, 'th span', 0);				//今日发表
	
			boards[count++] = board;
		});	
	}
	else if (sitetype == 'Phpwind 4') {
		$('tbody[id^=cate] tr').each(function(index, elem){					//遍历每个板块
			var board = newBoardInfo();
			
			board.name = getElementTextSafe(elem, 'td.f_one a', 1);					//板块名称
			board.url = getElementHrefSafe(elem, 'td.f_one a', 1);					//板块地址
			board.topics = getElementTextSafe(elem, 'td.f_two', 1);			//总主题数
			board.posts = getElementTextSafe(elem, 'td.f_two', 2);			//总跟帖数
			board.lastTime = getElementTextSafe(elem, 'td.smalltxt a', 0);			//最后发表时间
			board.lastURL = getElementHrefSafe(elem, 'td.smalltxt a', 0);				//最后发表地址
			board.today = getElementTextSafe(elem, 'td.f_two', 3);				//今日发表
	
			boards[count++] = board;
		});	
	}
	return boards;
}

//获取板块下的帖子
//返回代表每个帖子信息的对象的数组
function getPhpwindTopicsOfBoard(sitetype, period) {
	output(period, 4);
	var topics = [];
	var count = 0;
	if (sitetype == 'Phpwind 9') {
		$('tbody tr').each(function(index, elem) {						//遍历每篇帖子
			var topic = newTopicInfo();
			
			topic.name = getElementTextSafe(elem, 'td .title a.st', 1);				//帖子名称
			topic.url = getElementHrefSafe(elem, 'td .title a.st', 1);				//帖子地址
			topic.author = getElementTextSafe(elem, 'td.subject .info a', 0);			//发帖人
			topic.authorHome = getElementHrefSafe(elem, 'td.subject .info a', 0);		//发帖人主页
			topic.time = getElementTextSafe(elem, 'td.subject .info span', 0);			//发帖时间
			topic.views = getElementTextSafe(elem, 'td.num em', 1);				//浏览数
			topic.replys = getElementTextSafe(elem, 'td.num em', 0);				//回复数
			topic.lastReply = getElementTextSafe(elem, 'td.subject .info a', 1);			//最后回复人
			topic.lastReplyHome = getElementHrefSafe(elem, 'td.subject .info a', 1);		//最后回复人的主页
			topic.lastTime = getElementTextSafe(elem, 'td.subject .info span', 1);				//最后回复时间
			topic.lastURL = getElementHrefSafe(elem, '', 0);				//最后回复的内容
			
			if (topic.name.length > 0 && topic.url.length > 0) 
				topics[count++] = topic;
		});
	}
	else if (sitetype == 'Phpwind 8') {
		$('#threadlist tr').each(function(index, elem) {						//遍历每篇帖子
			var topic = newTopicInfo();

			topic.name = getElementTextSafe(elem, 'td.subject a', 0);				//帖子名称
			topic.url = getElementHrefSafe(elem, 'td.subject a', 0);					//帖子地址
			topic.author = getElementTextSafe(elem, 'td.author a', 0);			//发帖人
			topic.authorHome = getElementHrefSafe(elem, 'td.author a', 0);		//发帖人主页
			topic.time = getElementTextSafe(elem, 'td.author p', 0);			//发帖时间
			topic.views = getElementTextSafe(elem, 'tal y-style f10', 0);				//浏览数
			topic.replys = getElementTextSafe(elem, 'td span.s8', 0);				//回复数
			topic.lastReply = getElementTextSafe(elem, 'td.author a', 1);			//最后回复人
			topic.lastReplyHome = getElementHrefSafe(elem, '', 0);		//最后回复人的主页
			topic.lastTime = getElementTextSafe(elem, 'td.author p', 1);				//最后回复时间
			topic.lastURL = getElementHrefSafe(elem, 'tr .by em a', 0);				//最后回复的内容

			if (period == 'day' && !withinDay(parseDateTime(topic.time))) {
				return true;
			}
			else if (period == 'week' && !withinWeek(parseDateTime(topic.time))) {
				return true;
			}
			else if (period == 'month' && withinMonth(parseDateTime(topic.time))) {
				return true;
			}
			else if (period == 'year' && withinYear(parseDateTime(topic.time))) {
				return true;
			}
			else {
				if (topic.name.length > 0 && topic.url.length > 0) 
					topics[count++] = topic;
			}

		});
	}
	else if (sitetype == 'Phpwind 7' ) {
		$('.tr3.t_one').each(function(index, elem) {						//遍历每篇帖子
			var topic = newTopicInfo();
	
			topic.name = getElementTextSafe(elem, 'td a', 1);				//帖子名称
			topic.url = getElementHrefSafe(elem, 'td a', 1);					//帖子地址
			topic.author = getElementTextSafe(elem, 'td a.bl', 0);			//发帖人
			topic.authorHome = getElementHrefSafe(elem, 'td a.bl', 0);		//发帖人主页
			topic.time = getElementTextSafe(elem, 'td div', 0);			//发帖时间
			topic.views = getElementTextSafe(elem, '.tal.f10', 0).split('/')[0];				//浏览数
			topic.replys = getElementTextSafe(elem, '.tal.f10', 0).split('/')[1];				//回复数
			topic.lastReply = getElementTextSafe(elem, 'td span.gray2', 0);			//最后回复人
			topic.lastReplyHome = getElementHrefSafe(elem, 'td a.f10', 0);		//最后回复人的主页
			topic.lastTime = getElementTextSafe(elem, 'td a.f10', 0);				//最后回复时间
			topic.lastURL = getElementHrefSafe(elem, 'tr .by em a', 0);				//最后回复的内容

			if (topic.name.length > 0 && 
				topic.url.length > 0) {
				topics[count++] = topic;
			}
		});	
	}
	else if (sitetype == 'Phpwind 6' ||
			 sitetype == 'Phpwind 5' ) {
		$('.tr3.t_one, .tr3.t_two').each(function(index, elem) {						//遍历每篇帖子
			var topic = newTopicInfo();
			
			topic.name = getElementTextSafe(elem, 'td a', 1);				//帖子名称
			topic.url = getElementHrefSafe(elem, 'td a', 1);					//帖子地址
			topic.author = getElementTextSafe(elem, 'td a.bl', 0);			//发帖人
			topic.authorHome = getElementHrefSafe(elem, 'td a.bl', 0);		//发帖人主页
			topic.time = getElementTextSafe(elem, 'td div', 0);			//发帖时间
			topic.views = getElementTextSafe(elem, '.tal.f10', 0);				//浏览数
			topic.replys = getElementTextSafe(elem, '.tal.f10', 1);				//回复数
			topic.lastReply = getElementTextSafe(elem, '.tal.y-style', 1);			//最后回复人
			topic.lastReplyHome = getElementHrefSafe(elem, 'td a.f10', 0);		//最后回复人的主页
			topic.lastTime = getElementTextSafe(elem, 'td a.f10', 0);				//最后回复时间
			topic.lastURL = getElementHrefSafe(elem, 'td a.f10', 0);				//最后回复的内容
			
			if (topic.name.length > 0 && 
				topic.url.length > 0) {
				topics[count++] = topic;
			}
		});	
	}
	else if (sitetype == 'Phpwind 4') {
		$('tbody.i_table .t_one, .t_two').each(function(index, elem) {						//遍历每篇帖子
			var topic = newTopicInfo();
			
			topic.name = getElementTextSafe(elem, 'td.t_one a', 0);				//帖子名称
			topic.url = getElementHrefSafe(elem, 'td.t_one a', 0);				//帖子地址
			topic.author = getElementTextSafe(elem, 'td.smalltxt a', 0);			//发帖人
			topic.authorhome = getElementHrefSafe(elem, 'td.smalltxt a', 0);		//发帖人主页
			topic.time = getElementTextSafe(elem, 'td.smalltxt', 0).split('\n')[1];			//发帖时间
			topic.views = getElementTextSafe(elem, 'td.t_one', 2);				//浏览数
			topic.replys = getElementTextSafe(elem, 'td.t_one', 1);				//回复数
			topic.lastReply = getElementTextSafe(elem, 'td.smalltxt', 1).split('\n')[1];			//最后回复人
			topic.lastreplyhome = getElementHrefSafe(elem, '', 0);		//最后回复人的主页
			topic.lastTime = getElementTextSafe(elem, 'td.smalltxt a', 0);				//最后回复时间
			topic.lastURL = getElementHrefSafe(elem, 'td.smalltxt a', 0);				//最后回复的内容
			
			if (topic.name.length > 0 && 
				topic.url.length > 0) {
				topics[count++] = topic;
			}
		});	
	}

	return topics;
}

//获取板块中的子版块
function getPhpwindSubBoardsOfBoard(sitetype) {
	var subBoards = [];
	var count = 0;

	return subBoards;
}

//获取板块的下一页的链接
//如果是最后一页或者未发现返回空字符串
function getPhpwindNextPageOfBoard(sitetype) {
	if (sitetype == 'Phpwind 9') {
		return getElementHrefSafe('', '.pages .pages_next', 0);
	}
	else if (sitetype == 'Phpwind 8' ) {
		return getElementHrefSafe('', '.fl .pages .pages_next', 0);
	}
	else if (sitetype == 'Phpwind 7' ||
			 sitetype == 'Phpwind 6' ||
			 sitetype == 'Phpwind 5') {
		var next = getElementSafe('', '.pages b', 0);
		if(typeof(next) == 'undefined')
			return '';
		else
			return next.nextElementSibling.href;
	}
	else if (sitetype == 'Phpwind 4') {
		var href = $('tbody tr td b').filter(function(index, elem){return !isNaN(elem.innerText);}).first().next();
		return getElementHrefSafe("", href, 0);		
	}
	return '';
}

//获取帖子下一页的链接
//如果当前页面是最后一页或者错误返回空字符串
function getPhpwindNextPageOfTopic(sitetype) {
	if (sitetype == 'Phpwind 9' ||
		sitetype == 'Phpwind 8' ||
		sitetype == 'Phpwind 7' ||
		sitetype == 'Phpwind 5' ||
		sitetype == 'Phpwind 4') {
		return getDiscuzNextPageOfBoard(sitetype);
	}
}



function getPhpwindUsers(siteType, userList, mode){
	var userInfos = [];
	var users;
	var host = window.location.href;
	var pos = host.lastIndexOf('/');
	if (pos != -1)
		host = host.substring(0, pos+1);
	else
		host = host + '/';
	
	users = userList.split("\n");
	for(i in users){
		chrome.task.output({text: 'count: ' + i});
		var user = newUserInfo();
		
		if(siteType == 'Phpwind 9'){
			user.name = users[i];
			if(mode == 'asUser')
				user.search = host + 'index.php?m=space&c=thread&username=' + users[i];
			else if(mode == 'asId')
				user.search = host + 'index.php?m=space&c=thread&uid=' + users[i];
		}else if(siteType == 'Phpwind 8'){
			user.name = users[i];
			if(mode == 'asUser')
				user.search = host + 'apps.php?q=article&username=' + users[i];
			else if(mode == 'asId')
				user.search = host + 'apps.php?q=article&uid=' + users[i];
		}else if(siteType == 'Phpwind 7' ||
					siteType == 'Phpwind 6' ||
					siteType == 'Phpwind 5'){
			user.name = users[i];
			if(mode == 'asUser')
				user.search = host + 'search.php?step=2&keyword&method=&pwuser='+ users[i] + '&sch_area=0&f_fid=all&sch_time=7776000&orderway=lastpost&asc=DESC'
			else if(mode == 'asId')
				user.search = host + 'search.php?step=2&keyword&method=&authorid=' + users[i] + '&sch_area=0&f_fid=all&sch_time=7776000&orderway=lastpost&asc=DESC'
		}
		
		userInfos[i] = user;
	}
	
	return userInfos;
}

function getPhpwindTopicsOfUser(siteType){
	var topices = [];
	
	if(siteType == 'Phpwind 9'){
	
		var allTable = $('.mb10 tbody tr');
		var TableSize = allTable.size();
		var author = getAuthor(siteType);
		var authorHome = getAuthorHome(siteType);
		
		for(i=0; i<TableSize; i++){
			var topice = newTopicInfo();
			topice.author = author;																//发帖人
			topice.authorHome = authorHome;														//发帖人主页面
			topice.name = getElementTextSafe(allTable[i], '.subject a', 0);						//帖子名称
			topice.url = getElementHrefSafe(allTable[i], '.subject a', 0);						//帖子地址
			topice.time = getElementTextSafe(allTable[i], '.time', 0);							//发帖时间
			topice.views = getElementTextSafe(allTable[i], '.num', 0).match(/\d+/g)[1];			//浏览数
			topice.replys = getElementTextSafe(allTable[i], '.num', 0).match(/\d+/g)[0];		//回复数
			topices[i] = topice;
		}
	}
	
	if(siteType == 'Phpwind 8'){
	
		var allTable = $('.mb10 tbody tr.tr3');
		var TableSize = allTable.size();
		var author = getAuthor(siteType);
		var authorHome = getAuthorHome(siteType);
		
		for(i=0; i<TableSize; i++){
			var topice = newTopicInfo();
			topice.author = author;																//发帖人
			topice.authorHome = authorHome;														//发帖人主页面
			topice.board = getElementTextSafe($('td', allTable[i])[2], 'a', 0);					//所属板块
			topice.name = getElementTextSafe($('td', allTable[i])[1], 'a', 0);					//帖子名称
			topice.url = getElementHrefSafe($('td', allTable[i])[1], 'a', 0);					//帖子地址
			topice.time = getElementTextSafe($('td', allTable[i])[1], 'span', 0);				//发帖时间
			topice.views = getElementTextSafe($('td', allTable[i])[3], 'span', 1);				//浏览数
			topice.replys = getElementTextSafe($('td', allTable[i])[3], 'span', 0);				//回复数
			topice.lastReply = getElementTextSafe($('td', allTable[i])[4], 'a', 0);				//最后发帖人
			topice.lastReplyHome = getElementHrefSafe($('td', allTable[i])[4], 'a', 0);			//最后发帖人的主页面
			topice.lastTime = getElementTextSafe($('td', allTable[i])[4], 'p', 0);				//最后回复时间
			topices[i] = topice;
		}
	}
	
	if(siteType == 'Phpwind 7' ||
		siteType == 'Phpwind 6' ||
		siteType == 'Phpwind 5'){
	
		var allTable = $('.t tbody tr.tr3.tac');
		var TableSize = allTable.size();
		var author = getAuthor(siteType);
		var authorHome = getAuthorHome(siteType);
		
		for(i=0; i<TableSize; i++){
			var topice = newTopicInfo();
			topice.author = getElementTextSafe(allTable[i], 'td', 2).split('\n')[0];			//发帖人
			topice.authorHome = getElementHrefSafe(allTable[i], 'td a', 1);						//发帖人主页面
			topice.board = getElementTextSafe(allTable[i], 'td', 1);							//所属板块
			topice.name = getElementTextSafe(allTable[i], 'th a', 0);							//帖子名称
			topice.url = getElementHrefSafe(allTable[i], 'th a', 0);							//帖子地址
			topice.time = getElementTextSafe(allTable[i], 'td', 2).split('\n')[1];				//发帖时间
			topice.views = getElementTextSafe(allTable[i], 'td', 4);							//浏览数
			topice.replys = getElementTextSafe(allTable[i], 'td', 3);							//回复数
			topice.lastReply = getElementTextSafe(allTable[i], 'td', 5).split('\n')[1];			//最后发帖人
			topice.lastTime = getElementTextSafe(allTable[i], 'td a', 2);						//最后回复时间
			topice.lastURL = getElementHrefSafe(allTable[i], 'td a', 2);						//最后回复地址
			topices[i] = topice;
		}
	}
	
	return topices;
}

function getPhpwindNextPageOfUser(siteType){
	return getPhpwindNextPageOfBoard(siteType);
}

function getAuthor(siteType){
	if(siteType == 'Phpwind 9'){
		return getElementTextSafe('', '.space_sidebar .name', 0);
	}else if(siteType == 'Phpwind 8'){
		return getElementTextSafe('', '.sideA strong', 0);
	}
}

function getAuthorHome(siteType){
	if(siteType == 'Phpwind 9'){
		return getElementHrefSafe('', '.space_page .title a', 0);
	}else if(siteType == 'Phpwind 8'){
		return getElementHrefSafe('', '.head .cc .current a', 0);
	}
}

function getPhpwindCsvHeader(siteType){
	if(siteType == 'Phpwind 9')
		return '发帖人,发帖人主页面,帖子名称,帖子地址,发帖时间,浏览数,回复数\n';
	else if(siteType == 'Phpwind 8')
		return '发帖人, 发帖人主页面, 所属板块, 帖子名称, 帖子地址, 发帖时间, 浏览数, 回复数, 最后发帖人, 最后发帖人的主页面, 最后回复时间\n';
	else
		return '发帖人, 发帖人主页面, 所属板块, 帖子名称, 帖子地址, 发帖时间, 浏览数, 回复数, 最后发帖人, 最后回复时间, 最后回复地址\n';
}
	
function getPhpwindCsvText(siteType, topic){
	if(siteType == 'Phpwind 9')
		return 	topic.author + ', ' +
				topic.authorHome + ', ' +
				topic.name + ', ' +
				topic.url + ', ' +
				topic.time + ', ' +
				topic.views + ', ' +
				topic.replys + '\n';
	else if(siteType == 'Phpwind 8')
		return 	topic.author + ', ' +
				topic.authorHome + ', ' +
				topic.board + ', ' +
				topic.name + ', ' +
				topic.url + ', ' +
				topic.time + ', ' +
				topic.views + ', ' +
				topic.replys + ', ' +
				topic.lastReply + ', ' +
				topic.lastReplyHome + ', ' +
				topic.lastTime + '\n';
	else
		return	topic.author + ', ' +
				topic.authorHome + ', ' +
				topic.board + ', ' +
				topic.name + ', ' +
				topic.url + ', ' +
				topic.time + ', ' +
				topic.views + ', ' +
				topic.replys + ', ' +
				topic.lastReply + ', ' +
				topic.lastTime + ', ' +
				topic.lastURL + '\n';
}

//返回一个动态url
function getPhpwindDynamicURL(sitetype, url) {
	if (sitetype == 'Phpwind 9') {

		if (url.indexOf('fid') != -1) {
			return url += "&orderby=postdate";
		}
		else if (url.indexOf('thread') != -1) {
			return url += "&orderby=postdate";
		}
	}
	else if (sitetype == 'Phpwind 8') {
		if (url.indexOf('fid=') != -1) {
			return url += "&search=all&orderway=postdate&asc=DESC&page=1&type=0&special=0#tabA";
		}
		else if (url.indexOf('html') != -1) {
			var list = url.split('.html');
			return list[0] + "-search-all-orderway-postdate-asc-DESC-page-1-type-0-special-0.html#tabA";
		}
	}

}