﻿chrome.task.startPage(function (page){
    var option = page.option.length ? JSON.parse(page.option) : {};
	

	//去除浮动条 discuz x3
	if (page.sitetype == 'Discuz! X3') {
		$("#nv").each( function(index, elem) {
		window.onscroll = function() {
			var str = jQuery(elem).attr('style');
			str = str.replace("position: fixed;", "");
			jQuery(elem).attr('style', str);
			};
		});
		$("#top_nav").each( function(index, elem) {
		window.onscroll = function() {
			jQuery(elem).hide();
			};
		});
	}

	if(option.mode == 'asBoard')
		ProcessByBoard(page);
		
	if(option.mode == 'asUser')
		ProcessByUser(page);
		
	if(option.mode == 'asId')
		ProcessByUser(page);
});
