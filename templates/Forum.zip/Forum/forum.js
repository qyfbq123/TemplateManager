 var boardCsv = "板块列表.csv";
 var totalTopicCsv = "帖子列表.csv";
 var boardCsvHeader = '板块名称,板块地址,主题数,发帖总数,最新发表,最新发表地址,板块描述\n';
 var topicCsvHeader = '板块,子版块,帖子标题,帖子地址,发帖时间,发帖人,发帖人主页,浏览数,回复数,最后跟帖时间,最后跟帖内容,最后跟帖人,最后跟帖人主页,保存位置\n';
 
 var boardPrefix = '【板块】';
 var subboardPrefix = '【子版块】';
 var topicPrefix = '【帖子】';
 var attachPrefix = '【附件】';

//返回一个空的板块信息的对象
//板块信息包括：名称、地址、主题数、帖数、今日发表、最后发表时间/地址、描述等。
function newBoardInfo() {
	var board = {};

	board.name = '';		//板块名称
	board.url = '';			//板块地址
	board.topics = '';		//总主题数
	board.posts = '';		//总跟帖数
	board.today = '';		//今日发表
	board.lastTime = '';	//最后发表事件
	board.lastURL = '';		//最后发表地址
	board.desc = '';		//板块描述

	return board;
}

//返回一个空的帖子信息的对象
//信息包括：名称、作者、发布时间、回复数、浏览数、最后发表、最后发表时间等。
function newTopicInfo() {
	var topic = {};

	topic.board = '';		//所属板块
	topic.subboard = '';	//子版块
	topic.name = '';		//帖子名称
	topic.url = '';			//帖子地址
	topic.author = '';		//发帖人
	topic.authorHome = '';//发帖人主页面
	topic.time = '';		//发帖时间
	topic.views = '';		//浏览数
	topic.replys = '';		//回复数
	topic.lastReply = '';	//最后发帖人
	topic.lastReplyHome = '';//最后发帖人的主页面
	topic.lastTime = '';	//最后回复时间
	topic.lastURL = '';		//最后回复地址

	return topic;
}

//返回一个空的附件信息对象
function newAttachment() {
	var attachment = {};

	attachment.url = '';	//附件的URL
	attachment.name = '';	//附件的地址
	attachment.size = '';	//附件的大小
	attachment.time = '';	//上传时间
	attachment.downloads = '';	//下载次数
	attachment.desc = '';	//其他信息

	return attachment;
}

//返回用户信息
//信息包括：用户名、搜索链接
function newUserInfo(){
	var user = {};
	
	user.name = '';			//用户名
	user.search = '';		//搜索链接
	
	return user;
}

//返回下一页信息
//信息包括：当前页、链接
function newNextPage(){
	var page = {};
	
	page.num = 0;			//当前页
	page.href = '';			//链接
	page.finish = 0;		//末页
	
	return page;
}

//将板块的信息写入文件
function WriteBoardCSV(file, board) {
    chrome.task.fwrite({ 
    	path: file, 
    	text: 
    	escapeCSV(board.name) + ',' + 
    	board.url + ',' +
    	board.topics + ',' +
    	board.posts + ',' +
    	board.lastTime + ',' +
    	board.lastURL + ',' +
    	escapeCSV(board.desc) + '\n'});	
}

//将帖子信息写入文件
function WriteTopicCSV(file, topic, board, subboard, savedir) {
	var topicCsvLine = 	
		escapeCSV(board) + ',' +
		escapeCSV(subboard) + ',' +
		escapeCSV(topic.name) + ',' + 
		topic.url + ',' +
		topic.time + ',' +
		escapeCSV(topic.author) + ',' +
		topic.authorHome + ',' +
		topic.views + ',' +
		topic.replys + ',' +
		topic.lastTime + ',' +
		topic.lastURL + ',' +
		topic.lastReply + ',' +
		topic.lastReplyHome + ',' +
		savedir + '\n';

	chrome.task.fwrite({ path: file, text: topicCsvLine});
}