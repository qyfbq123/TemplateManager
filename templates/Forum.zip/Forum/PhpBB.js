function getPhpBBUsers(siteType, userList){
	var userInfos = [];
	var users;
	var host = window.location.href;
	var pos = host.lastIndexOf('/');
	if (pos != -1)
		host = host.substring(0, pos+1);
	else
		host = host + '/';
	
	users = userList.split("\n");
	for(i in users){
		var user = newUserInfo();
		
		if(siteType == 'PhpBB 2'){
			user.name = users[i];
			user.search = host + 'search.php?search_author=' + users[i];
		}
		
		if(siteType == 'PhpBB 3'){
			user.name = users[i];
			user.search = host + 'search.php?keywords=&terms=all&author=' + users[i] + '&sc=1&sf=all&sk=t&sd=d&sr=posts&st=0&ch=300&t=0&submit=%E6%90%9C%E7%B4%A2';
		}
		
		userInfos[i] = user;
	}
	
	return userInfos;
}

function getPhpBBTopicsOfUser(siteType){
	var topices = [];
	
	if(siteType == 'PhpBB 2'){
		var allTable = $('.forumline tr');
		var TableSize = (allTable.size()-2)/3;
		
		for(i=0; i<TableSize; i++){
			var topice = newTopicInfo();
			topice.board = getElementTextSafe(allTable[i*3+2], 'td:last span.postdetails a', 0);			//所属板块
			topice.name = getElementTextSafe(allTable[i*3+1], 'a', 0);										//帖子名称
			topice.url = getElementHrefSafe(allTable[i*3+1], 'a', 0);										//帖子地址
			topice.author = getElementTextSafe(allTable[i*3+2], 'td:first span.name a', 0);					//发帖人
			topice.authorHome = getElementHrefSafe(allTable[i*3+2], 'td:first span.name a', 0);				//发帖人主页面
			//topice.time = getElementTextSafe(allTable[i*3+1], '.gensmall div:last', 0);					//发帖时间
			topice.views = getElementTextSafe(allTable[i*3+2], 'td:first span.postdetails b:last', 0);		//浏览数
			topice.replys = getElementTextSafe(allTable[i*3+2], 'td:first span.postdetails b:first', 0);	//回复数
			topices[i] = topice;
		}
	}
	
	if(siteType == 'PhpBB 3'){
		var allTable = $('tr[class]', $('table.tablebg')[1]);
		var TableSize = allTable.size()/3;
	
		for(i=0; i<TableSize; i++){
			var topice = newTopicInfo();
			topice.board = getElementTextSafe(allTable[i*3], '.topictitle a', 1);			//所属板块
			topice.name = getElementTextSafe(allTable[i*3], '.topictitle a', 2);			//帖子名称
			topice.url = getElementHrefSafe(allTable[i*3], '.topictitle a', 2);				//帖子地址
			topice.author = getElementTextSafe(allTable[i*3+1], '.postauthor a', 0);		//发帖人
			topice.authorHome = getElementHrefSafe(allTable[i*3+1], '.postauthor a', 0);	//发帖人主页面
			topice.time = getElementTextSafe(allTable[i*3+1], '.gensmall div:last', 0);		//发帖时间
			topice.views = getElementTextSafe(allTable[i*3+2], '.postdetails b', 0);		//浏览数
			topice.replys = getElementTextSafe(allTable[i*3+2], '.postdetails b', 1);		//回复数
			topices[i] = topice;
		}
	}
	
	return topices;
}

function getPhpBBBoards(siteType, bSort) {
	var boards = [];
	var count = 0;
	if (siteType == 'PhpBB 3') {
		$('.tablebg tbody tr').each(function(index, elem){		//遍历每个板块
			var board = newBoardInfo();
			board.name = getElementTextSafe(elem, 'td .forumlink', 0);							//板块名称
			board.url = getElementHrefSafe(elem, 'td .forumlink', 0);							//板块地址
			board.topics = getElementTextSafe(elem, 'td.row2', 0).replace('\n', "");			//总主题数
			board.posts = getElementTextSafe(elem, 'td.row2', 1).replace('\n', "");				//总跟帖数
			board.lastTime = getElementTextSafe(elem, 'td.row2', 2).split('\n')[0];				//最后发表时间
			board.lastURL = getElementHrefSafe(elem, 'td.row2 a', 1);							//最后发表地址
			board.today = getElementTextSafe(elem, '', 0);										//今日发表
			board.desc = getElementTextSafe(elem, 'td p.forumdesc', 0);							//板块描述

			if (bSort) 
				board.url = getPhpBBDynamicURL(sitetype, board.url);

			boards[count++] = board;
		});
		$('.forabg li.row').each(function(index, elem){
			var board = newBoardInfo();
			board.name = getElementTextSafe(elem, 'dt a', 0);							//板块名称
			board.url = getElementHrefSafe(elem, 'dt a', 0);							//板块地址
			board.topics = getElementTextSafe(elem, 'dd.topics', 0);					//总主题数
			board.posts = getElementTextSafe(elem, 'dd.posts', 0);						//总跟帖数
			board.lastTime = getElementTextSafe(elem, 'dd.lastpost', 2);				//最后发表时间
			board.lastURL = getElementHrefSafe(elem, 'dd.lastpost a', 1);				//最后发表地址
			board.today = getElementTextSafe(elem, '', 0);								//今日发表
			board.desc = getElementTextSafe(elem, 'dt a', 1);							//板块描述
			boards[count++] = board;
		});
	}
	else if (siteType == 'PhpBB 2') {
		$('.forumline tbody tr').each(function(index, elem){		//遍历每个板块
			var board = newBoardInfo();
			board.name = getElementTextSafe(elem, 'td .forumlink', 1);							//板块名称
			board.url = getElementHrefSafe(elem, 'td .forumlink', 1);							//板块地址
			board.topics = getElementTextSafe(elem, 'td.row2', 0);								//总主题数
			board.posts = getElementTextSafe(elem, 'td.row2', 1);								//总跟帖数
			board.lastTime = getElementTextSafe(elem, 'td.row2', 2).split('\n')[0];	   			//最后发表时间
			board.lastURL = getElementHrefSafe(elem, 'td.row2 a', 1);							//最后发表地址
			board.today = getElementTextSafe(elem, '', 0);										//今日发表
			board.desc = getElementTextSafe(elem, 'td span.genmed', 0);							//板块描述
			boards[count++] = board;
		});
	}
	return boards;
}

function getPhpBBTopicsOfBoard(siteType) {
	var topics = [];
	var count = 0;
	if (siteType == 'PhpBB 3') {
		$('div#pagecontent table.tablebg tr').each(function(index, elem) {						//遍历每篇帖子
			var topic = newTopicInfo();
			topic.name = getElementTextSafe(elem, 'td.row1 a', 1);								//帖子名称
			topic.url = getElementHrefSafe(elem, 'td.row1 a', 1);								//帖子地址
			topic.author = getElementTextSafe(elem, 'td p.topicauthor', 0);						//发帖人
			topic.authorHome = getElementHrefSafe(elem, 'td p.topicauthor a', 0);				//发帖人主页
			topic.time = getElementTextSafe(elem, 'td.row2 p.topicdetails', 0);					//发帖时间
			topic.views = getElementTextSafe(elem, 'td.row2 p.topicdetails', 1);				//浏览数
			topic.replys = getElementTextSafe(elem, 'td.row1 p.topicdetails', 0);				//回复数
			topic.lastReply = getElementTextSafe(elem, 'td.row1 p.topicdetails', 2);			//最后回复人
			topic.lastReplyHome = getElementHrefSafe(elem, 'td.row1 p.topicdetails a', 0);		//最后回复人的主页
			topic.lastTime = getElementTextSafe(elem, 'td.row1 p.topicdetails', 1);				//最后回复时间
			topic.lastURL = getElementHrefSafe(elem, 'td.row1 p.topicdetails a', 1);			//最后回复的内容
			if (topic.name.length > 0 && 
				topic.url.length > 0) {
				topics[count++] = topic;
			}
		});
		$('.topiclist.topics .row').each(function(index, elem) {
			var topic = newTopicInfo();
			topic.name = getElementTextSafe(elem, 'dt a', 0);								//帖子名称
			topic.url = getElementHrefSafe(elem, 'dt a', 0);								//帖子地址
			topic.author = getElementTextSafe(elem, 'dt a', 1);								//发帖人
			topic.authorHome = getElementHrefSafe(elem, 'dt a', 1);							//发帖人主页
			topic.time = getElementTextSafe(elem, 'dt', 0).split('»')[1].replace(',', ' ');						//发帖时间
			topic.views = getElementTextSafe(elem, 'dd.views', 0);				//浏览数
			topic.replys = getElementTextSafe(elem, 'dd.posts', 0);				//回复数
			topic.lastReply = getElementTextSafe(elem, 'dd.lastpost a', 0);			//最后回复人
			topic.lastReplyHome = getElementHrefSafe(elem, 'dd.lastpost a', 0);		//最后回复人的主页
			topic.lastTime = getElementTextSafe(elem, 'dd span', 0).split('\n')[1].replace(',', ' ');				//最后回复时间
			topic.lastURL = getElementHrefSafe(elem, 'dd.lastpost a', 1);			//最后回复的内容
			if (topic.name.length > 0 && 
				topic.url.length > 0) {
				topics[count++] = topic;
			}
		});
		
	}
	else if ( siteType == 'PhpBB 2') {
		$('table.forumline tbody tr').each(function(index, elem) {						//遍历每篇帖子
			var topic = newTopicInfo();
			topic.name = getElementTextSafe(elem, 'td .topictitle a', 0);						//帖子名称
			topic.url = getElementHrefSafe(elem, 'td .topictitle a', 0);						//帖子地址
			topic.author = getElementTextSafe(elem, 'td .name a', 0);							//发帖人
			topic.authorHome = getElementHrefSafe(elem, 'td .name a', 0);						//发帖人主页
			topic.time = getElementTextSafe(elem, '', 0);										//发帖时间
			topic.views = getElementTextSafe(elem, 'td.row2 .postdetails', 0);					//浏览数
			topic.replys = getElementTextSafe(elem, 'td.row2 p.postdetails', 1);				//回复数
			topic.lastReply = getElementTextSafe(elem, 'td.row3Right .postdetails a', 0);		//最后回复人
			topic.lastReplyHome = getElementHrefSafe(elem, 'td.row3Right .postdetails a', 0);	//最后回复人的主页
			topic.lastTime = getElementTextSafe(elem, 'td.row3Right .postdetails', 0).split('\n')[0];	//最后回复时间
			topic.lastURL = getElementHrefSafe(elem, 'td.row3Right .postdetails a', 1);			//最后回复的内容
			if (topic.name.length > 0 && 
				topic.url.length > 0) {
				topics[count++] = topic;
			}
		});
	}
	output(String(topics.length), 3);
	return topics;
}

//获取板块中的子版块
function getPhpBBSubBoardsOfBoard(sitetype) {
	var subBoards = [];
	var count = 0;

	return subBoards;
}

function getPhpBBNextPageOfUser(siteType){
	if(siteType == 'PhpBB 2'){
		return getElementHrefSafe('', '.nav a:contains("下一个"), a:contains("Next")', 0);
	}
	
	if(siteType == 'PhpBB 3'){
		return getElementHrefSafe('', '.nav a:contains("下一页"), a:contains("Next")', 0);
	}
	
	return '';
}

function getPhpBBNextPageOfBoard(siteType) {
		if(siteType == 'PhpBB 3'){
		return getElementHrefSafe('', 'td.gensmall a:contains("下一页"), a:contains("Next")', 0);
	}
	
	if(siteType == 'PhpBB 2'){
		return getElementHrefSafe('', '.nav a:contains("下一个"), a:contains("Next")', 0);
	}
	
	return "";
}

function getPhpBBNextPageOfTopic(siteType){
	var nextPageInfo = newNextPage();
	if(siteType == 'PhpBB 2'){
		return getElementHrefSafe('', '.nav a:last', 0);
	}
	
	if(siteType == 'PhpBB 3'){
		return getElementHrefSafe('', '.gensmall b a:last', 0);
	}
	
	return nextPageInfo;
}

function getPhpBBCsvHeader(siteType){
	return '发帖人, 发帖人主页面, 所属板块, 帖子名称, 帖子地址, 浏览数, 回复数\n';
}

function getPhpBBCsvText(siteType, topic){
	return	topic.author + ', ' +
			topic.authorHome + ', ' +
			topic.board + ', ' +
			topic.name + ', ' +
			topic.url + ', ' +
			topic.time + ', ' +
			topic.views + ', ' +
			topic.replys + '\n';
}


//获取帖子中的附件
function getPhpBBAttachmentsOfTopic(sitetype) {
	var attachs = [];
	var count = 0;

	if (sitetype == 'PhpBB 3') {
		$('div.inline-attachment').each(function(index, elem) {
			var attach = newAttachment();

			attach.url = getElementHrefSafe(elem, 'dt a', 0);
			attach.name = getElementTextSafe(elem, 'dt a', 0);

			attachs[count++] = attach;
		});
	}
	else if (sitetype == 'PhpBB 2') {
		$('div.inline-attachment').each(function(index, elem) {
			var attach = newAttachment();

			attach.url = getElementHrefSafe(elem, 'dt a', 0);
			attach.name = getElementTextSafe(elem, 'dt a', 0);

			attachs[count++] = attach;
		});	
	}

	return attachs;
}

//返回一个动态url
function getPhpBBDynamicURL(sitetype, url) {
	if (sitetype == 'PhpBB 3') {

		if (url.indexOf('fid') != -1) {
			return url += "";
		}
		else if (url.indexOf('thread') != -1) {
			return url += "";
		}
	}
	else if (sitetype == 'PhpBB 2') {
		if (url.indexOf('fid=') != -1) {
			return url += "";
		}
		else if (url.indexOf('html') != -1) {
			return url += "";
		}
	}

}