﻿//转义字符串中的HTML特殊字符
//http://stackoverflow.com/questions/784586/convert-special-characters-to-html-in-javascript

function HTMLEncode(str) {
    var i = str.length,
        aRet = [];

    while (i--) {
        var iC = str[i].charCodeAt();
        if (iC < 65 || iC > 127 || (iC > 90 && iC < 97)) {
            aRet[i] = '&#' + iC + ';';
        } else {
            aRet[i] = str[i];
        }
    }
    return aRet.join('');
}

//新页面的域名是否符合选项要求
//orig_host:起始页面的主机名
//test_host:待检测的URL的主机名
//mode:域名匹配模式：hostonly/subdomain/any

function IsDomainAllowed(orig_host, test_host, mode) {
    if (mode == "hostonly") {
        if (orig_host == test_host)
            return true;

        return false;
    } else if (mode == "subdomain") {
        if (orig_host == test_host)
            return true;

        //www.baidu.com -> baidu.com
        var main_domain = orig_host;
        if (main_domain.length > 4 && main_domain.substr(0, 4) == "www.")
            main_domain = main_domain.substr(4);

        //news.baidu.com -> baidu.com
        var pos = test_host.indexOf('.');
        while (pos != -1) {
            test_host = test_host.substr(pos + 1);

            if (test_host == main_domain)
                return true;

            pos = test_host.indexOf('.');
        }

        return false;
    }

    //any
    return true;
}

chrome.task.startPage(function(page) {

    chrome.task.output({
        level: 0,
        text: 'innerwidth: ' + window.innerWidth + ' innerheight: ' + window.innerHeight + ' outerwidth: ' + window.outerWidth + ' outerheight: ' + window.outerHeight + ' scrollWidth: ' + document.body.scrollWidth + ' scrollHeight ' + document.body.scrollHeight
    });

    //获取页面数据
    var data = page.data.length ? JSON.parse(page.data) : {};

    //获取模板选项
    var option = page.option.length ? JSON.parse(page.option) : {};

    chrome.runtime.sendMessage({type: 'page', name: document.title});

    var file = '页面列表.csv';
    if (page.first) {
        chrome.task.fopen({
            path: file,
            mode: 'a',
            header: '标题, URL\n'
        });
    }

    chrome.task.fwrite({
        path: file,
        text: document.title.replace(/,/g, '，') + ', ' + window.location.href + '\r'
    });

    //添加新的页面
    var addnum = 0;
    if (page.depth < parseInt(option.depth, 10)) {
        var allAnchor = $("a");
        allAnchor.each(function(k, val) {
            var original_host = page.first ? window.location.host : data.host;
            if (!IsDomainAllowed(original_host, val.host, option.domain))
                return;

            var text;
            if (val.text.length > 2)
                text = HTMLEncode(val.text);
            else
                text = val.href;

            chrome.task.addPage({
                url: val.href,
                title: val.title.length ? val.title : val.text,
                output: '添加新页面: ' + text,
                data: JSON.stringify({
                    host: original_host
                })
            });

            addnum = addnum + 1;
        });
    }

    chrome.task.finishPage();
});