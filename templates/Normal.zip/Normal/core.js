chrome.extension.onMessage.addListener(function(request, sender, sendResponse){
   if (request.type == 'page') {
   		$('#container')[0].innerText += request.name + '\n';
   }
});