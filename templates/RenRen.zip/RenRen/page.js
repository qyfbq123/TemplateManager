﻿
var _$jq = jQuery.noConflict();
jQuery.fn.onlyText = function() {
    return jQuery(this).clone().children().remove().end().text();
};

var saveDirRules = {
    blog: "[日志]",
    status: "[状态]",
    comment: "[留言]",
    album: "[相册]",
    report: "[任务报告]"
};
var addPages = function (urlList, _param, _func){
    //chrome.task.output({text: 'AddPage length: '+urlList.length}); 
    for (var item = urlList.length - 1; item >= 0; item--) {
        if(urlList[item].href){
            var param = _param || {};
            param.url = urlList[item].href;
            param.output = 'url:' + urlList[item].href;
            if(_func)
                param = _func.call(urlList[item], param);
            chrome.task.addPage(param);
        }
    }
    
    chrome.task.output({text: 'AddPage: '+urlList.length});
};


chrome.task.startPage(function (page) {
    //chrome.task.output({text: 'page data: '+data});
    var pageData = page.data.length ? JSON.parse(page.data) : {};
    var option = page.option.length ? JSON.parse(page.option) : {};
    var blogCsv = saveDirRules.report + "/日志.csv";
    var statusCsv = saveDirRules.report + "/状态.csv";
    var commentCsv = saveDirRules.report + "/留言.csv";
    var albumCsv = saveDirRules.report + "/相册.csv";
    var _func = function(){ return true; };

    if(option.mode == 'r_period' && option.period != 'all') {
        var period = option.period;
        _func = window['within' + period.substring(0,1).toUpperCase() + period.substring(1)];
    }
    
    //首页
    if (page.first || pageData.type === undefined) { //首页


        if(location.host == 'www.renren.com') {
            if(option["c_status"]) {
                addPages(
                    jQuery('a:contains("所有状态")'),
                    {
                        savename: '第1页',
                        data: JSON.stringify({type: 'statusList'}),
                        savedir: saveDirRules.status
                    }
                );
            }
            if(option["c_comment"]) {
                addPages(
                    jQuery('a:contains("查看所有留言")'),
                    {
                        savename: '第1页',
                        data: JSON.stringify({type: 'commentList'}),
                        savedir: saveDirRules.comment
                    }
                );
            }
            if( jQuery('#timeline_wrapper').length == 1 ){
                if(option["c_album"]) {
                    addPages(
                        jQuery('#top-attach a:contains("相册")'),
                        {
                            data: JSON.stringify({type: 'albumList'}),
                            savedir: saveDirRules.album
                        }
                    );
                }
                if(option["c_blog"]) {
                    addPages(
                        jQuery('#top-attach a:contains("日志")'),
                        {
                            savename: '第1页',
                            data: JSON.stringify({type:'blogs'}),
                            savedir: saveDirRules.blog
                        }
                    );
                }
                chrome.task.finishPage();
            }else {
                if(option["c_album"]) {
                    addPages(
                        jQuery('a:contains("全部相册")'),
                        {
                            data: JSON.stringify({type: 'albumList'}),
                            savedir: saveDirRules.album
                        }
                    );
                }
                if(option["c_blog"]) {
                    jQuery('#pBlog').click();
                    waitForAjax('.main-blog-column', '', function(){
                        addPages(
                            jQuery('a.see-more-link[stats="blog_all"]'),
                            {
                                savename: '第1页',
                                data: JSON.stringify({type:'blogs'}),
                                savedir: saveDirRules.blog
                            }
                        );
                        chrome.task.finishPage();
                    });
                } else chrome.task.finishPage();
            }
        }
        if(location.host == 'page.renren.com') {
            addPages(
                jQuery('a[biz="note"]'),
                {
                    savename: '第1页',
                    data: JSON.stringify({type:'blogs'}),
                    savedir: saveDirRules.blog
                }
            );
        }
    }
    //日志列表
    if (pageData.type == 'blogs') {
        waitForAjax('.blog-main', '', function(){
            var blogPages = jQuery('.pager-top li.current').siblings(':not(:contains("页"))').find('a');
            var blogs = jQuery('.list-blog strong>a:first-child');
            if(option.mode == 'r_total' && !isNaN(option['total'])) {
                var total = Number(option['total']);
                blogPages = blogPages.filter(function(index, elem) {
                    return total <= 0 || Number( jQuery(elem).text() ) <= total;
                });
            }
            if(option.mode == 'r_period') {
                var prevLen = blogs.length;
                blogs = blogs.filter(function(index, elem) {
                    var _time = jQuery('.timestamp', jQuery(elem).closest('.list-blog')).text();
                    return _func.call('', _time);
                });
                if(prevLen != blogs.length) {
                    var page = Number(pageData.page || 1);
                    blogPages = blogPages.filter(function(index, elem) {
                        return Number(jQuery(elem).text()) < page;
                    });
                }
            }
            addPages(
                blogPages,
                {
                    savedir: saveDirRules.blog
                },
                function(_param) {
                    _param.savename = '第' + jQuery(this).text() + '页';
                    _param.data = JSON.stringify({type:'blogs', page: jQuery(this).text()});
                    return _param;
                }
            );

            if( blogs.length === 0 ) return chrome.task.finishPage({discard: true});
            var savedir = saveDirRules.blog;
            savedir += '/第' + (pageData.page || 1) + '页';
        
            addPages(
                blogs,
                {
                    data: JSON.stringify({type: 'blog'}),
                    savedir: savedir
                }
            );
            chrome.task.finishPage();
        });
    }
    //日志详情
    if (pageData.type == 'blog') {
        chrome.task.fopen({path : blogCsv, mode : 'ab', header: '时间,分类,标题,内容,阅读,评论,分享\n'});
        var timestamp = jQuery('.title-article>.timestamp').text();
        var group = jQuery('.title-article>.group>a').text();
        var title = jQuery('.title-article>strong').text();
        var content = jQuery('#blogContent>p').text();
        var stat = jQuery('span.stat').text();
        var sArr = stat.match(/\d+/g);
        

        chrome.task.fwrite({path: blogCsv, text:timestamp + ',' + group + ',' + title + ',' + content + ',' + sArr[0] + ',' + sArr[1] + ',' + sArr[2] + '\n'});
        chrome.task.finishPage();
    }
    //状态
    if(pageData.type == 'statusList') {
        waitForAjax('.status-main', '', function() {

            var page = 1;
            (function recordStatus(flag) {
                if(flag === false) {
                    output('状态翻页失败！', 4);
                    return chrome.task.finishPage({snapshot: false});
                }
                var _noNext = false;
                if(option.mode == 'r_total' && !isNaN(option['total'])) {
                    var total = Number(option['total']);
                    if(total > 0 && page >= total) _noNext = true;
                } else if(option.mode == 'r_period') {
                    var _time = jQuery('.duration:first', jQuery('#my_panel li:last')).text();
                    if(_time && !_func.call('', _time)) {
                        _noNext = true;
                        _time = jQuery('.duration:first', jQuery('#my_panel li:first')).text();
                        if(!_func.call('', _time)) {
                            return chrome.task.finishPage({discard: true});
                        }
                    }
                }
                chrome.task.fopen({path : statusCsv, mode : 'ab', header: '时间,内容\n'});
                if(jQuery('#pager_buttom #ui_pager_1_nextPage:visible').length === 0) _noNext = true;
                chrome.task.snapshot({savename: '第' + page + '页', savedir: saveDirRules.status}, function() {
                    jQuery('#my_panel li').each(function(index, elem) {
                        var _$self = jQuery(this);
                        var timestamp = jQuery('.duration:first', _$self).text();
                        var content = jQuery('h3:first', _$self).text().replace(/[\r\n]/gi, '');
                        if(_noNext && _func.call('', timestamp))
                            chrome.task.fwrite({path: statusCsv, text:timestamp + ','  + content + '\n'});
                    });
                    var _$nextPage = jQuery('#pager_buttom #ui_pager_1_nextPage:visible');
                    if(_$nextPage.length == 1 && !_noNext) {
                        var originId = jQuery('#my_panel li:first').attr('id');
                        _$nextPage[0].click();
                        page++;
                        waitForChange(originId, '#my_panel li:first', '', 'id', recordStatus);
                    }
                    else
                        chrome.task.finishPage({snapshot: false});
                });
            }());
        });
    }
    //留言
    if(pageData.type == 'commentList') {
        waitForAjax('main-home', '', function() {
            var page = 1;
            (function recordComment(flag) {
                if(flag === false) {
                    output('留言翻页失败！', 4);
                    return chrome.task.finishPage({snapshot: false});
                }
                var _noNext = false;
                if(option.mode == 'r_total' && !isNaN(option['total'])) {
                    var total = Number(option['total']);
                    if( total > 0 && page >= total ) _noNext = true;
                } else if(option.mode == 'r_period') {
                    var _time = jQuery('span.time', jQuery('#talk div.comment:last')).text();
                    if(_time && !_func.call('', _time)) {
                        _noNext = true;
                        _time = jQuery('span.time', jQuery('#talk div.comment:first')).text();
                        if(!_func.call('', _time)) {
                            return chrome.task.finishPage({discard: true});
                        }
                    }
                }
                chrome.task.fopen({path : commentCsv, mode : 'ab', header: '作者,时间,内容\n'});
                if(jQuery('#comment_pager #ui_pager_1_nextPage:visible').length === 0) _noNext = true;
                chrome.task.snapshot({savename: '第' + page + '页', savedir: saveDirRules.comment}, function() {
                    jQuery('#talk div.comment').each(function(index, elem) {
                        var _$self = jQuery(this);
                        var author = jQuery('span.author', _$self).text();
                        var timestamp = jQuery('span.time', _$self).text();
                        var content = jQuery('.text-content', _$self).text().replace(/\s/gi, '');
                        if(_noNext && _func.call('', timestamp))
                            chrome.task.fwrite({path: commentCsv, text: author + ',' + timestamp + ','  + content + '\n'});
                    });
                    var _$nextPage = jQuery('#comment_pager #ui_pager_1_nextPage:visible');
                    if(_$nextPage.length ==1 && !_noNext) {
                        var originId = jQuery('#talk div.comment:first').attr('id');
                        _$nextPage[0].click();
                        page++;
                        waitForChange(originId, '#talk div.comment:first', '', 'id', recordComment);
                    }
                    else
                        chrome.task.finishPage({snapshot: false});
                });
            }());
        });
    }
    //相册
    if(pageData.type == 'albumList') {
        waitForAjax('.photo-main', '', function(){

            addPages(
                jQuery('.album-home ul li a:first-child'),
                null,
                function(_param) {
                    var albumName = jQuery(this).next().text().replace(/\s/gi, '');
                    _param.savedir = saveDirRules.album + '/' + albumName;
                    var data = {type: 'album', albumName: albumName};
                    _param.data = JSON.stringify(data);
                    return _param;
                }
            );
            chrome.task.finishPage();
        });
    }
    if(pageData.type == 'album') {
        var pageIndex = 0;
        if( jQuery('#photoPager a:contains("下一页")').length > 0 ) pageIndex = 1;
        (function recordAlbum(flag) {
            if(flag === false) {
                output('相册：' + pageData.albumName + '翻页失败', 4);
                return chrome.task.finishPage({snapshot: false});
            }
            addPages(
                jQuery('.photo-list ul li>a'),
                {
                    savedir: saveDirRules.album + '/' + pageData.albumName + (pageIndex > 0 ? '/第' + pageIndex + '页' : ''),
                    data: JSON.stringify({type:'photo'})
                }
            );
            chrome.task.fopen({path : albumCsv, mode : 'ab', header: '所属相册,链接,描述\n'});
            jQuery('.photo-list ul li').each(function(index, elem){
                var albumName = pageData.albumName;
                var url = eval( '(' + jQuery('img:first', jQuery(this)).data('photo') + ')' ).large;
                var desc = jQuery('.myphoto-info', jQuery(this)).text().replace(/\s/gi, '');
                chrome.task.fwrite({path: albumCsv,text: albumName + ',' + url + ',' + desc + '\n'});
            });
            var _$nextPage = jQuery('#photoPager a:contains("下一页")');
            if(pageIndex > 0) {
                chrome.task.snapshot({savename: '第' + pageIndex + '页', savedir: saveDirRules.album + '/' + pageData.albumName}, function(){
                    var originId = jQuery('.photo-list ul li>a:first').attr('href');
                    if(_$nextPage.length > 0) {
                        _$nextPage.click();
                        pageIndex++;
                        waitForChange(originId, '.photo-list ul li>a:first', '', 'href', recordAlbum);
                    } else chrome.task.finishPage({snapshot: false});
                });
            } else
                chrome.task.finishPage();
        }());
    }
    if(pageData.type == 'photo') {
        chrome.task.finishPage();
    }
});