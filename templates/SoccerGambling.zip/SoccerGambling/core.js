chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {
        if (request.updateWindow) {
            // chrome.task.output({
            //     text: 'updateWindow msg',
            //     level: 0
            // });
            chrome.windows.getCurrent(function(wind) {
                var updateInfo = {
                    left: 0,
                    top: 0,
                    width: request.width,
                    height: request.height
                };
                chrome.windows.update(wind.id, updateInfo);
                sendResponse({'sucess':true});
            });
        }
    }
);