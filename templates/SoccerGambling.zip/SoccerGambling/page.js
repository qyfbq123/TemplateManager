﻿jQuery('document').ready(function() {
    // var mf = jQuery('frame[name="SI2_mem_index"]')[0].contentDocument;
    // var header = jQuery('frame[name="header"]', mf)[0].contentDocument;
    // var body = jQuery('frame[name="body"]', mf)[0].contentDocument;
    var saveDirRules = {
        his: "帐户历史"
    };
    var historyCsv = saveDirRules.his + "/帐户历史摘要.csv";
    var options = '';
    var pageData = '';
    var mf_str = 'frame[name="SI2_mem_index"]',
        header_str = 'frame[name="header"]',
        body_str = 'frame[name="body"]';
    var table_his = [];
    var detail_nodes = [];
    var detail_csv = '';
    var detail_dir = '';
    var detail_next = 0;

    chrome.task.startPage(function(page) {
        pageData = page.data.length ? JSON.parse(page.data) : {};
        output('page: ' + page.option + '  ' + page.data, 0);
        options = page.option.length ? JSON.parse(page.option) : {};
        chrome.task.fopen({
            path: historyCsv,
            mode: 'ab'
        });
        output('首页...');
        login();
    });

    function login() {
        output('登陆页...');
        waitForAjaxInFrame('input[name="username"]', mf_str, function(success) {
            if (!success) {
                failAndClose('打开首页超时！');
                return;
            }
            var mf = jQuery(mf_str)[0].contentDocument;
            var username_el = jQuery('input[name="username"]', mf),
                password_el = jQuery('input[name="passwd"]', mf);
            username_el[0].value = options.userName;
            password_el[0].value = options.password;
            //登陆
            jQuery('form[name="LoginForm"]', mf).submit();
            //判断登陆是否成功
            waitForAjaxInFrame(header_str, mf_str, function(success) {
                if (!success) {
                    failAndClose('登陆失败！');
                    return;
                }
                output('登陆成功！');
                openHis();
            });
        });
    }

    function openHis() {
        output('帐户首页...');
        waitForAjaxInFrame('.his a:contains("帐户历史")', [mf_str, header_str], function(success) {
            if (!success) {
                failAndClose('打开账户首页超时！');
                return;
            }
            var mf = jQuery(mf_str)[0].contentDocument;
            var header = jQuery(header_str, mf)[0].contentDocument;
            var el = jQuery('.his a:contains("帐户历史")', header);
            el[0].click();
            output('打开帐户历史...');

            waitForAjaxInFrame('table.game td.his_total', [mf_str, body_str], function(success) {
                if (!success) {
                    failAndClose('打开账户历史超时！');
                    return;
                }
                analyseHis();
            });
        });
    }

    function analyseHis() {
        output('分析历史摘要...');
        var mf = jQuery(mf_str)[0].contentDocument;
        var header = jQuery(header_str, mf)[0].contentDocument;
        var body = jQuery(body_str, mf)[0].contentDocument;

        table_his = jQuery('table.game tr', body);
        detail_nodes = jQuery('span[onclick]', table_his);
        if (detail_next === 0) {
            recordHis();
        } else {
            openHisDetail();
        }
    }

    function recordHis() {
        output('记录历史摘要...', 0);
        table_his.each(function(index, el) {
            var td = jQuery('td,th', el);
            var arr = [];
            td.each(function(i, x) {
                arr[i] = x.innerText;
            });
            chrome.task.fwrite({
                path: historyCsv,
                text: arr.join(',') + '\n'
            });
        });
        chrome.task.snapshot({
            savedir: saveDirRules.his,
            savename: '帐户历史摘要'
        }, function(detail) {
            openHisDetail();
        });
    }

    function openHisDetail() {
        if (detail_next >= detail_nodes.length) {
            output('所有历史详情分析完毕！');
            over();
            return;
        }
        var datestr = detail_nodes[detail_next].innerText;
        detail_nodes[detail_next].click();
        output('分析历史详情：' + datestr);

        waitForAjaxInFrame('table#box table.game tr', [mf_str, body_str], function(success) {
            if (!success) {
                failAndClose('打开历史详情页面超时！');
                return;
            }
            detail_dir = saveDirRules.his + '/' + datestr;
            detail_csv = detail_dir + '/历史详情.csv';
            chrome.task.fopen({
                path: detail_csv,
                mode: 'ab'
            });
            analyseDetail();
        });
    }

    function analyseDetail() {
        var mf = jQuery(mf_str)[0].contentDocument;
        var header = jQuery(header_str, mf)[0].contentDocument;
        var body = jQuery(body_str, mf)[0].contentDocument;

        var nodes = jQuery('table.game tr', body);
        output('记录历史详情...');
        nodes.each(function(detail_next, el) {
            var td = jQuery('td,th', el);
            var arr = [];

            td.each(function(i, x) {
                arr[i] = x.innerText.replace(/[,\r\n]/g, ' ');
            });
            if (jQuery(el).hasClass('sum_bar')) {
                arr.splice(0, 0, ' ', ' ', ' ');
            }
            chrome.task.fwrite({
                path: detail_csv,
                text: arr.join(',') + '\n'
            });
        });

        snapshotDetail();
    }

    function snapshotDetail() {
        var mf = jQuery(mf_str)[0].contentDocument;
        var header = jQuery(header_str, mf)[0].contentDocument;
        var body = jQuery(body_str, mf)[0].contentDocument;
        output('body frame height:' + body.height);
        jQuery(body).scrollTop(body.height);
        delayedExecute(800, function() {
            chrome.task.snapshot({
                savedir: detail_dir,
                savename: '历史详情'
            }, function(detail) {
                detail_next += 1;
                backToHis();
            });
        });
    }

    function backToHis() {
        var mf = jQuery(mf_str)[0].contentDocument;
        var header = jQuery(header_str, mf)[0].contentDocument;
        var body = jQuery(body_str, mf)[0].contentDocument;

        output('返回历史摘要页面...', 0);
        var backBtn = jQuery('a.wag_btn_back', body);
        backBtn[0].click();
        waitForAjaxInFrame('table.game td.his_total', [mf_str, body_str], function(success) {
            if (!success) {
                failAndClose('返回历史摘要超时！');
                return;
            }
            analyseHis();
        });
    }

    function over() {
        output('结束...', 0);
        chrome.task.finishPage({
            discard: true
        });
    }

    function delayedOver() {
        delayedExecute(3000, over);
    }
});