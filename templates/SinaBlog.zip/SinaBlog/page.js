﻿chrome.task.startPage(function (page) {
	
	var pageData = page.data.length ? JSON.parse(page.data) : {};
    var option = page.option.length ? JSON.parse(page.option) : {};
	var articleList = "博文列表.csv";
	
	if(page.first){
		chrome.task.fopen({path: articleList, mode: "ab", header: "博文标题, 链接, 保存位置\n"});
	}
	
	//添加博客栏目
	if(page.first){	
		var allTitle = $('.blognav span a');
		allTitle.each(function(index, item){
			if(item.innerText == '首页')
				return;
			
			var dirName = page.savedir + item.text;
			
			if(item.innerText == '博文目录'){
				chrome.task.addPage({
					url: item.href,
					savedir: item.text,
					savename: '第1页',
					priority: 'hight',
					data: JSON.stringify({type: 'article', boardName: 'page'})
				});
			}
			
			if(item.innerText == '图片'){
				chrome.task.addPage({
					url: item.href,
					savedir: item.text,
					savename: item.text,
					priority: 'hight',
					data: JSON.stringify({type: 'picture', boardName: 'page'})
				});
			}
			
			if(item.innerText == '关于我'){
				chrome.task.addPage({
					url: item.href,
					savedir: item.text,
					savename: item.text,
					priority: 'hight',
					data: JSON.stringify({type: 'about', boardName: 'page'})
				});
			}
		});
	}
	
	if(pageData.type == 'article'){
		//保存博文信息
		if(pageData.boardName == 'article'){
			chrome.task.fwrite({path: articleList, text: $('title').text() + ',' + window.location.href + ',' + page.savedir + "\n"});
		}
		
		//分析博文列表，添加到下载队列
		if(pageData.boardName == 'page'){
		
			var allArticle = $('#column_2 .articleList .atc_title a');
			var allLink = $('#column_2 .SG_pages a');
			var pageNum = $('#column_2 .SG_pages li.SG_pgon').text();
			
			//添加下一页博文到下载列表
			allLink.each(function(index, item){
				chrome.task.addPage({
					url: item.href,
					savedir: page.savedir,
					savename: '第' + item.text + '页',
					priority: 'hight',
					data: JSON.stringify({type: 'article', boardName: 'page'})
				});
			});
			
			//添加博文到下载队列
			allArticle.each(function(index, item){
				chrome.task.addPage({
					url: item.href,
					savedir: '博文/第' + pageNum + '页',
					savename: item.txt,
					data: JSON.stringify({type: 'article', boardName: 'article'})
				});
			});
		}
	}

	if(page.first)
		chrome.task.finishPage({savedir: '首页'});
	else
		chrome.task.finishPage();
});