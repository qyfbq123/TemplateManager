function checkForumFt() {
    //Most Discuz and phpwind: #ft, #footer
    //discuz 5.5: .footerline ie: http://forum.51nb.com/index.php
    //some phpwind: .footer ie:http://www.phpwind.net/
    //phpwind 7.0: eg: http://bbs.crsky.com/
    //phpbb .copyright:contains('Powered by')
    //phpbb3: http://forums.wxwidgets.org/viewtopic.php?f=10&t=33822 
    var ft = $("#ft,#footer,.footer,.footertext,.copyright");
    if (ft.length === 0) {
        ft = $(".footerline").nextAll();
    }

    if (ft.length > 0) {
        var str_ft = $(ft).text().toLowerCase(); //$('<div>').append(ft.clone()).html().toLowerCase();
        var mode = str_ft.match(/(discuz!? x?\d+[.]?\d*)|(phpwind v?\d+[.]?\d*)|(phpbb ?\d+)/);
        if (str_ft.indexOf("phpbb") > 0) {
            var phpbb_mode = '';
            $("*").contents().filter(function() {
                return this.nodeType == 8;
            }).each(function(i, e) {
                var value = e.nodeValue.toLowerCase();
                var ret = value.match(/phpbb ?\d+/);
                if (ret) {
                    phpbb_mode = ret[0];
                    return false;
                }
            });
            if(phpbb_mode)
                return phpbb_mode;
        }
        return mode?mode[0]:'';
    }
    return "";
}

function checkForumHd() {
    var meta_node = $("head meta");
    if (meta_node.length > 0) {
        var str_meta = meta_node.text().toLowerCase();
        var mode = str_meta.match(/phpwind v?\d[.]?\d*/);
        return mode?mode[0]:'';
    }
    return "";
}

function matchForum(orgMode) {
    var text = orgMode.toLowerCase();
    if (text.indexOf('discuz') !== -1) {
        var discuzModes = ["Discuz! X3", "Discuz! X2d5", "Discuz! X2", "Discuz! X1d5",
            "Discuz! X1", "Discuz! 7",
            "Discuz! 6", "Discuz! 5", "Discuz! 4", "Discuz! 3"
        ];
        if (text.indexOf('x2.5') !== -1) {
            return discuzModes[1];
        }
        if (text.indexOf('x1.5') !== -1) {
            return discuzModes[3];
        }

        for (var x = 0; x < discuzModes.length; x++) {
            var element = discuzModes[x];
            var tarray = element.split(' ');

            //discuz 5.4 example
            text = text.split('.')[0];
            if (text.indexOf(tarray[1].toLowerCase()) != -1) {
                return element;
            }
        }
    } else if (text.indexOf('phpwind') != -1) {
        var phpwindModes = ["Phpwind 1", "Phpwind 2", "Phpwind 3", "Phpwind 4",
            "Phpwind 5", "Phpwind 6", "Phpwind 7", "Phpwind 8", "Phpwind 9"
        ];
        for (var y = 0; y < phpwindModes.length; y++) {
            var element2 = phpwindModes[y];
            var tarray2 = element2.split(' ');

            //phpwind 8.7 example
            text = text.split('.')[0];
            if (text.indexOf(tarray2[1].toLowerCase()) != -1) {
                return element2;
            }
        }
    } else if (text.indexOf('phpbb') != -1) {
        var phpbbModes = ["PhpBB 2", "PhpBB 3"];
        for (var z = 0; z < phpbbModes.length; z++) {
            var element3 = phpbbModes[z];
            var tarray3 = element3.split(' ');
            if (text.indexOf(tarray3[1].toLowerCase()) != -1) {
                return element3;
            }
        }
    }

    return '';
}

var category = "";
var mode = "";
mode = checkForumFt();
if (!mode) {
    mode = checkForumHd();
}

var siteMode = matchForum(mode);
chrome.task.output({
    text: 'We found ' + mode + '. Maybe it belongs to ' + siteMode + '.',
    level: 0
});
chrome.task.detectResult({
    'type': siteMode
});