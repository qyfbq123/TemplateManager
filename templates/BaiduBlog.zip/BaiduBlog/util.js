//等待页面加载或跳转直到selector指定的页面元素出现或超时
//selector: 待出现元素的jQuery选择器，如果未定义，则仅当定时器超时时执行回调函数。
//timeout: 等待超时时间（毫秒）
//callback: 超时后执行的回调函数，其唯一参数意义如下：
//回调函数返回值：返回true表示元素出现，返回false表示超时调用
function WaitForElementWithTimeout(selector, timeout, callback){
    var interval = 500;
    var timeOut = timeout;

    var Loop = function(){
        timeOut -= interval;

        var elementAppear;
        if (typeof (selector) == 'string') {
            var element = $(selector);
            elementAppear = element.length ? true : false;
        } else
            elementAppear = false;

        if (elementAppear || timeOut <= 0){
            window.clearInterval(id);

			if (elementAppear)
				callback(true);
			else
				callback(false);
        }

		chrome.task.keepAlive();
    };

    var id = window.setInterval(Loop, interval);   
}

//异步延时调用回调函数
//timeout: 延时毫秒数
function DelayedExecute(timeout, callback) {
    WaitForElementWithTimeout(0, timeout, callback);
}

//当前页面是否包含指定的DOM元素
//selector: jQuery选择器字符串
//返回值：当前页面中存在此元素返回true, 否则返回false
function ElementExists(selector) {
    if (typeof(selector) != 'string' ||
        $(selector).length == 0)
        return false;

    return true;
}

function Assert(status) {
    if (!status)
        chrome.task.output({text: 'Assert failed!'});
}

function KeepAlive() {
    chrome.task.keepAlive();
}