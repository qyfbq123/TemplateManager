chrome.extension.onMessage.addListener(function(request, sender, sendResponse){
    var i = 0;
    for (; i<request.length; i++){
        //alert(request[i].href + '\n' + request[i].text + '\n' + request[i].from);
		chrome.task.addPage({url : request[i].href, from : request[i].from, title : request[i].text});
    }
});


