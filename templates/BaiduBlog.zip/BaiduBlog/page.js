﻿function addArticles(articlesFilter, pagesFilter, pageNumberFilter, page){

	var pageData = page.data.length ? JSON.parse(page.data) : {};
	var articles = $(articlesFilter);
	var pages = $(pagesFilter);
	var finish = false;
	
	chrome.task.output({text: 'loading……'});
	DelayedExecute(100, function(){
		chrome.task.output({text: 'url: ' + location.href + 'size: ' + pages.size() + '   article size: ' + articles.size()});
		if(pageData.maxNum!=0 && pageData.nowNum+articles.size() >= pageData.maxNum)
			finish = true;
			
		if(pages.size() == 0 && !finish){
			//滚动一页
			$("html, body").scrollTop($(document).height());
			addArticles(articlesFilter, pagesFilter, pageNumberFilter, page);
			return;
		}
		
		//添加博文到下载列表
		articles.each(function(index, item){
			if(pageData.nowNum < pageData.maxNum || pageData.maxNum==0){
				chrome.task.addPage({
					url: item.href,
					savedir: '博文/第' + pageData.nowPage + '页',
					savename: item.text,
					data: JSON.stringify({type: 'articles', header: item.text, href: item.href})
				});
				pageData.nowNum++;
			}
		});
		
		//添加博文列表到下载列表
		//pages[pages.size()-1].text
		if(!finish){
			pageData.nowPage++;
			chrome.task.addPage({
				url: pages[pages.size()-1].href,
				savedir: '博文目录',
				savename: '第' + pageData.nowPage + '页',
				priority: 'high',
				data: JSON.stringify({type: 'page', maxNum: pageData.maxNum, nowNum: pageData.nowNum, nowPage: pageData.nowPage})
			});
		}
		
		if(page.first)
			chrome.task.finishPage({savedir: '博文目录', savename: '第1页'});
		else
			chrome.task.finishPage();
	});
}

function DetectTemplate(page){
}

chrome.task.startPage(function (page) {
	var pageData = page.data.length ? JSON.parse(page.data) : {};
    var option = page.option.length ? JSON.parse(page.option) : {};
	var articleList = "博文列表.csv";
	var articlesFilter;
	var pagesFilter;
	var pageNumberFilter;
	
	if(page.first){
		chrome.task.fopen({path: articleList, mode: "ab", header: "博文标题, 链接, 保存位置\n"});
	}
	
	if(pageData.type == 'articles'){
		chrome.task.fwrite({path: articleList, text: pageData.header + ', ' + pageData.href + ', ' + page.savedir + "\n"});
		chrome.task.finishPage();
		return;
	}
	
	
	if(option.type == 'list'){
		articlesFilter = 'article >div.mod-realcontent.mod-cs-contentblock >div.item-head >a';
		pagesFilter = '#pagerBar.mod-blog-pagerbar.mod-cs-pagebar a';
		pageNumberFilter = '#pagerBar.mod-blog-pagerbar.mod-cs-pagebar span';
	}
	
	if(option.type == 'stream'){
		articlesFilter = '.mod-blogitem-title a';
		pagesFilter = '.mod-pagerbar a';
		pageNumberFilter = '.mod-pagerbar span';
	}
	
	if(page.first)
		page.data = JSON.stringify({type: 'page', maxNum: option.max, nowNum: 0, nowPage: 1, template: option.type});
	addArticles(articlesFilter, pagesFilter, pageNumberFilter, page);
});