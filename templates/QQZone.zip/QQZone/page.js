chrome.task.startPage(function(page) {

    var pageData = page.data.length ? JSON.parse(page.data) : {};
    var options = page.option.length ? JSON.parse(page.option) : {};
    var curLocation = location.href;
    var max_delay = 4000, //ms
        min_delay = 1000;
    var frameSelector = '.app_canvas_frame';

    output('options: ' + page.option + '; pageData: ' + page.data, 0);

    var saveDirRules = {
        personalInfo: "[个人档]",
        shuoShuo: "[说说]",
        album: "[相册]",
        other: "[其它]",
        report: "[任务报告]"
    };

    var shuoShuoCsv = saveDirRules.report + "/说说列表.csv";
    var articleCsv = saveDirRules.report + "/日志列表.csv";
    var messageCsv = saveDirRules.report + "/留言板.csv";
    var limitedShuoShuoPages = -1, //-1 代表不限制
        limitedArticlePages = -1,
        limitedMessagePages = -1,
        limitedAlbum = -1;

    if (options.shuoshuoLimit === 'limitedPages') {
        limitedShuoShuoPages = getNumber(options.shuoshuoPages);
    }
    if (options.articleLimit === 'limitedPages') {
        limitedArticlePages = getNumber(options.articlePages);
    }
    if (options.messageLimit === 'limitedPages') {
        limitedMessagePages = getNumber(options.messagePages);
    }
    if (options.photoLimit === 'limitedAlbum') {
        limitedAlbum = getNumber(options.photoAlbum);
    }

    if (jQuery('.lay_topfixed_inner').css('position') == 'fixed') {
        jQuery('.lay_topfixed_inner').css('position', 'absolute');
    }
    //QQ空间个人主页的地址形如:http://user.qzone.qq.com/123456
    if (page.first || pageData.type === undefined) {
        output('首页...', 1);

        //url形如：http://user.qzone.qq.com/814523457/
        var mainUrl = document.location.href.match(/http:\/\/[\w.]+\/\d{4,}/);
        //url 形如：http://572193428.qzone.qq.com/
        if (!mainUrl)
            mainUrl = document.location.href.match(/http:\/\/[\w.]+/);
        if (!mainUrl) {
            failAndClose('首页URL形式不支持！');
            return;
        }

        var moodUrl = mainUrl + '/mood', //说说
            blogUrl = mainUrl + '/blog', //日志
            msgboardUrl = mainUrl + '/msgboard', //留言板
            photoAlbumUrl = mainUrl + '/photo'; //相册

        if (limitedShuoShuoPages !== 0) {
            chrome.task.addPage({
                url: moodUrl,
                data: JSON.stringify({
                    type: 'mood'
                })
            });
        }
        if (limitedArticlePages !== 0) {
            chrome.task.addPage({
                url: blogUrl,
                data: JSON.stringify({
                    type: 'blog'
                })
            });
        }
        if (limitedMessagePages !== 0) {
            chrome.task.addPage({
                url: msgboardUrl,
                data: JSON.stringify({
                    type: 'msgboard'
                })
            });
        }
        if (limitedAlbum !== 0) {
            chrome.task.addPage({
                url: photoAlbumUrl,
                data: JSON.stringify({
                    type: 'albumList'
                }),
                savedir: saveDirRules.album,
                savename: '相册列表'
            });
        }

        chrome.task.finishPage({
            savedir: '/',
            savename: '空间主页'
        });

    } else if (pageData.type === 'article' || pageData.type === 'shuoShuo') {
        output(document.title);
        waitForAjaxInFrame('#blogDetailDiv,#msgList', frameSelector, function(success) {
            chrome.task.finishPage();
        });
    } else if (pageData.type === 'msgboard' || pageData.type === 'blog') {
        var pageType = pageData.type === 'msgboard' ? '留言板' : '日志',
            csvPath = pageData.type === 'msgboard' ? messageCsv : articleCsv,
            csvHeader = pageData.type === 'msgboard' ? '作者,发表时间,楼层,内容\n' : '标题,发表时间,链接\n',
            maxPages = pageData.type === 'msgboard' ? limitedMessagePages : limitedArticlePages;

        output(pageType + '...');
        chrome.task.fopen({
            path: csvPath,
            mode: 'ab',
            header: csvHeader
        });

        var contentIndex = 0,
            pageIndex = 0,
            totalPages = 0;

        var processPage = function(compareText) {
            pageIndex += 1;
            output(pageType + '页 第 ' + pageIndex + ' 页...');

            waitForTextChangeInFrame(compareText, '.mod_pagenav_main .current', frameSelector, function(success) {
                var mf = jQuery(frameSelector)[0].contentDocument;
                if (!success) {
                    //处理只有一页的情况
                    if (pageIndex === 1) {
                        var node = jQuery('#ulCommentList,#listArea', mf);
                        var node2 = jQuery('.mod_pagenav_main', mf);
                        if (node.length && !node2.length) {
                            output(pageType + '页仅有一页！');
                            parsePage();
                            finishLastPage();
                            return;
                        }
                    }
                    failAndRetry(curLocation, "打开" + pageType + "第" + pageIndex + "页超时!", pageData);
                    return;
                }

                var curPageNode = jQuery('.mod_pagenav_main .current', mf).last(),
                    nextBtn = jQuery('.mod_pagenav_main .c_tx', mf).last();
                if (!curPageNode.length || !nextBtn.length) {
                    failAndRetry(curLocation, pageType + "第" + pageIndex + "页查找翻页节点失败!", pageData);
                    return;
                }
                if (pageIndex !== getNumber(curPageNode.text())) {
                    failAndRetry(curLocation, "打开" + pageType + "第" + pageIndex + "页时，页码不对!", pageData);
                    return;
                }
                if (pageIndex === 1) {
                    var ln = jQuery('.mod_pagenav_main .mod_pagenav_count .c_tx', mf).last();

                    totalPages = getNumber(ln.text());
                    if (totalPages <= 1) {
                        output(pageType + '页仅有一页！');
                        parsePage();
                        finishLastPage();
                        return;
                    }
                    output('总共发现有 ' + totalPages + ' 页' + pageType);
                }

                parsePage();

                if (pageIndex >= totalPages || (maxPages > 0 && pageIndex >= maxPages)) {
                    if (maxPages > 0)
                        output('已限制为仅获取' + maxPages + '页' + pageType + '，达到了限制');
                    finishLastPage();
                    return;
                }

                chrome.task.snapshot({
                    savedir: '[' + pageType + ']',
                    savename: pageType + '页_第' + pageIndex + '页'
                }, function(detail) {
                    var ctext = curPageNode.text();
                    nextBtn[0].click();
                    var t = Math.floor(Math.random() * max_delay + min_delay);
                    delayedExecute(t, function() {
                        processPage(ctext);
                    });
                });
            });
        };

        var parsePage = function() {
            output('parsePage...', 0);
            var mainFrame = jQuery(frameSelector)[0].contentDocument;
            var contentList = jQuery('#ulCommentList .main, #listArea li[rel="list-row"]', mainFrame);
            if (!contentList.length) {
                output('本页未发现内容!', 3);
                return;
            }
            output('本页内容有 ' + contentList.length + ' 条', 0);
            contentList.each(function(index, el) {
                contentIndex += 1;
                parseDetail(el);
            });
        };

        var parseMsgDetail = function(node) {
            output('parseMsgDetail...', 0);
            var userName = jQuery('.username a', node).first().text().replace(/[,\r\n\/\\]/g, ' '),
                floor = jQuery('.floor', node).first().text(),
                content = jQuery('.cont table', node).text().replace(/[,\r\n\/\\]/g, ' '),
                date = jQuery('.reply_wrap .mode_post', node).first().text().replace(/[,\r\n\/\\]/g, ' ');

            chrome.task.fwrite({
                path: messageCsv,
                text: userName + ',' + date + ',' + floor + ',' + content + '\n'
            });
        };

        var parseArticleDetail = function(node) {
            output('parseArticleDetail...', 0);
            //因为阅读数和评论数是异步加载， 且加载很慢， 难以获取到， 故忽略。
            var title = jQuery('a[title][blogid] span', node).text().replace(/[,\r\n\/\\]/g, ' ');
            var linkNode = jQuery('a[title][blogid]', node);
            var dateNode = jQuery('.list_op span', node).first();
            // var commentNode = dateNode.next();
            if (!dateNode.length || !linkNode.length) {
                output('解析该篇日志信息失败，跳过', 3);
                return;
            }
            var link = linkNode[0].href,
                date = dateNode.attr('title');
            // comments = 0,
            // reads = 0;

            // output('commentNode: ' + commentNode.text(), 0);
            // var nn = getNumbers(commentNode.text(), /\d+/g);
            // if (nn.length != 2) {
            //     output('获取日志阅读数和评论数失败！', 3);
            // } else {
            //     comments = nn[0];
            //     reads = nn[1];
            // }
            chrome.task.fwrite({
                path: articleCsv,
                text: title + ',' + date + ',' + link + '\n'
            });

            chrome.task.addPage({
                url: link,
                data: JSON.stringify({
                    type: 'article'
                }),
                savedir: '[' + pageType + ']' + '/第 ' + pageIndex + ' 页',
                savename: title
            });
        };

        var finishLastPage = function() {
            output(pageType + ' 最后一页分析完');
            chrome.task.snapshot({
                savedir: '[' + pageType + ']',
                savename: pageType + '页_第' + pageIndex + '页'
            }, function(detail) {
                chrome.task.finishPage({
                    discard: true
                });
            });
        };

        var parseDetail = pageData.type === 'msgboard' ? parseMsgDetail : parseArticleDetail;
        processPage('');

    } else if (pageData.type === 'mood') {
        output('TA的说说页...', 1);
        var shuoShuoCount = 0,
            shuoShuoPageCount = 0,
            totalShuoShuoPages = 0;
        chrome.task.fopen({
            path: shuoShuoCsv,
            mode: 'ab',
            header: '时间,内容,赞数,评论数,转发数,链接\n'
        });

        var finishLastShuoPage = function() {
            output('说说页最后一页分析完');
            chrome.task.snapshot({
                savedir: saveDirRules.shuoShuo,
                savename: '说说页_第' + shuoShuoPageCount + '页'
            }, function(detail) {
                chrome.task.finishPage({
                    discard: true
                });
            });
        };

        var parseShuoShuo = function(node) {
            output('parseShuoShuo...', 0);

            var contentNode = jQuery('.content', node).first(),
                dateNode = jQuery('.ft:last a.goDetail', node),
                zanNode = jQuery('.ft:last a.qz_like_btn:visible', node),
                commentNode = jQuery('.ft:last a.comment_btn', node),
                forwardNode = jQuery('.ft:last a.forward_btn', node);
            if (!contentNode.length || !dateNode.length || !zanNode.length || !commentNode.length || !forwardNode.length) {
                output('解析该条说说信息失败， 跳过！', 3);
                return;
            }

            var content = contentNode.text().replace(/[,\r\n\/\\]/g, ' '),
                date = dateNode.attr('title'), //!!! what if no Date?
                zan = getNumber(zanNode.text()),
                comment = getNumber(commentNode.text()),
                forward = getNumber(forwardNode.text()),
                link = dateNode[0].href;

            chrome.task.fwrite({
                path: shuoShuoCsv,
                text: date + ',' + content + ',' + zan + ',' + comment + ',' + forward + ',' + link + '\n'
            });

            if (options.dShuoShuo) {
                chrome.task.addPage({
                    url: link,
                    data: JSON.stringify({
                        type: 'shuoShuo'
                    }),
                    savedir: saveDirRules.shuoShuo + '/第' + shuoShuoPageCount + '页',
                    savename: '说说_第' + shuoShuoCount + '条'
                });
            }
        };

        var parseShuoShuoPage = function() {
            output('parseShuoShuoPage...', 0);
            var mainFrame = jQuery(frameSelector)[0].contentDocument;
            var shuoShuoList = jQuery("#msgList .feed", mainFrame);
            if (!shuoShuoList.length) {
                output('本页未发现说说内容', 3);
                return;
            }
            output('本页有说说 ' + shuoShuoList.length + ' 条', 0);
            jQuery.each(shuoShuoList, function(index, val) {
                shuoShuoCount += 1;
                parseShuoShuo(val);
            });
        };
        //递归调用，模拟点击翻页
        (function processShuoShuo(compareText) {
            jQuery("html, body").scrollTop(jQuery(document).height());
            shuoShuoPageCount += 1;
            output('说说页 第 ' + shuoShuoPageCount + ' 页...');

            autoScroll(jQuery('.mod_pagenav_main', jQuery(frameSelector)[0].contentDocument), '', function(success) {
                waitForTextChangeInFrame(compareText, '.mod_pagenav_main .current', frameSelector, function(success) {
                    //snapshot
                    //chrome.task.snapshot();
                    var mf = jQuery(frameSelector)[0].contentDocument;
                    if (!success) {
                        //处理只有一页的情况
                        if (shuoShuoPageCount === 1) {
                            var node = jQuery('#msgList', mf);
                            var node2 = jQuery('.mod_pagenav_main', mf);
                            if (node.length && !node2.length) {
                                output('说说页仅有一页！');
                                parseShuoShuoPage();
                                finishLastShuoPage();
                                return;
                            }
                        }
                        failAndRetry(curLocation, "打开说说第" + shuoShuoPageCount + "页超时!", pageData);
                        return;
                    }

                    var curPageNode = jQuery('.mod_pagenav_main .current', mf).last(),
                        nextBtn = jQuery('.mod_pagenav_main .c_tx', mf).last();
                    if (!curPageNode.length || !nextBtn.length) {
                        failAndRetry(curLocation, "说说页第" + shuoShuoPageCount + "页查找翻页节点失败!", pageData);
                        return;
                    }
                    if (shuoShuoPageCount !== getNumber(curPageNode.text())) {
                        failAndRetry(curLocation, "打开说说页第" + shuoShuoPageCount + "页时，页码不对!", pageData);
                        return;
                    }
                    if (shuoShuoPageCount === 1) {
                        var nl = jQuery('.mod_pagenav_main .c_tx[id*="last"]', mf);
                        totalShuoShuoPages = getNumber(nl.text());

                        output('总共发现有 ' + totalShuoShuoPages + ' 页说说');
                    }
                    parseShuoShuoPage();

                    if (shuoShuoPageCount >= totalShuoShuoPages || (limitedShuoShuoPages > 0 && shuoShuoPageCount >= limitedShuoShuoPages)) {
                        if (limitedShuoShuoPages > 0)
                            output('已限制为仅获取' + limitedShuoShuoPages + '页说说，达到了限制');

                        finishLastShuoPage();
                        return;
                    }

                    chrome.task.snapshot({
                        savedir: saveDirRules.shuoShuo,
                        savename: '说说页_第' + shuoShuoPageCount + '页'
                    }, function(detail) {
                        var ctext = curPageNode.text();
                        nextBtn[0].click();
                        var t = Math.floor(Math.random() * max_delay + min_delay);
                        delayedExecute(t, function() {
                            processShuoShuo(ctext);
                        });
                    });

                });
            });
        }());
    } else if (pageData.type === 'albumList') {
        output('进入相册列表...');
        waitForAjaxInFrame('#album_list_div .photo_albumlist_wrap', frameSelector, function(success) {
            if (!success) {
                failAndRetry(curLocation, '等待相册列表超时！', pageData);
                return;
            }
            var mf = jQuery(frameSelector)[0].contentDocument;
            var albumList = jQuery('#album_list_div .photo_albumlist_wrap', mf);
            output('共发现 ' + albumList.length + ' 个相册');

            var albumIndex = 0;
            albumList.each(function(index, el) {
                albumIndex += 1;
                var nameNode = jQuery('.photo_albumlist_name a', el),
                    infoNode = jQuery('.photo_albumlist_photocount', el);
                if (!nameNode.length || !infoNode.length) {
                    output('获取第' + albumIndex + '个相册信息失败， 跳过！', 3);
                    return;
                }
                var name = nameNode.attr('title').replace(/[,\r\n\/\\]/g, ' '),
                    photosNumber = getNumber(infoNode.text()),
                    link = nameNode[0].href;
                output('相册: ' + name + ' 照片数量: ' + photosNumber);

                chrome.task.addPage({
                    url: link,
                    data: JSON.stringify({
                        type: 'album',
                        name: name,
                        number: photosNumber
                    })
                });

                if (limitedAlbum > 0 && albumIndex >= limitedAlbum) {
                    output('已限制为仅获取' + limitedAlbum + '个相册，达到了限制');
                    return false;
                }
            });

            chrome.task.finishPage();
        });
    } else if (pageData.type === 'album') {
        output('进入相册: ' + pageData.name + '...');

        var parseImages = function() {
            var mf = jQuery(frameSelector)[0].contentDocument;
            var photoList = jQuery('.photo_thumbnailist_detail li[photo_list_item]', mf);
            output('photoList: ' + photoList.length, 0);

            photoList.each(function(index, el) {
                var node = jQuery('img[pre_url][origin_url]', el);
                if (!node.length) {
                    output('获取大图链接失败，跳过此图片', 3);
                    return;
                }
                var origin_url = node.attr('origin_url'),
                    pre_url = node.attr('pre_url');

                var link = /^http/.test(origin_url) ? origin_url : pre_url;
                if (/^http/.test(link)) {
                    chrome.task.download({
                        url: link,
                        savedir: saveDirRules.album + '/' + pageData.name,
                        savename: pageData.name + '_' + (index + 1) + '.jpg'
                    });
                }
            });
        };

        var parseBigPhotoPage = function() {
            output('展开相册， 获取大图...', 0);
            waitForAjaxInFrame('.photo_thumbnailist_detail li[photo_list_item]', frameSelector, function(success) {
                if (!success) {
                    failAndClose('等待相册大图' + pageData.name + '超时！');
                    return;
                }

                (function fn() {
                    parseImages();
                    //翻一页
                    var mf = jQuery(frameSelector)[0].contentDocument;
                    var nextBtn = jQuery('#photo_list_next:visible', mf);
                    if (!nextBtn.length) {
                        output('相册 ' + pageData.name + ' 已全部下载');
                        chrome.task.finishPage({
                            discard: true
                        });
                        return;
                    } else {
                        nextBtn[0].click();
                        delayedExecute(1000, fn);
                    }

                }());
            });
        };

        waitForAjaxInFrame('#js-photolist-wrap .photo_photolist_img a', frameSelector, function(success) {
            if (!success) {
                failAndRetry(curLocation, '等待相册' + pageData.name + '超时！', pageData);
                return;
            }
            var mf = jQuery(frameSelector)[0].contentDocument;
            var node = jQuery('#js-photolist-wrap .photo_photolist_img a', mf).first();
            if (!node.length) {
                failAndClose('获取照片链接失败！');
                return;
            }

            node[0].click();
            parseBigPhotoPage();
        });
    }
});