﻿jQuery(document).ready(function() {
    chrome.task.startPage(function(page) {
        var pageData = page.data.length ? JSON.parse(page.data) : {};
        var options = page.option.length ? JSON.parse(page.option) : {};
        var curLocation = location.href;
        output('pageOptions: ' + page.option + '; pageData: ' + page.data, 0);

        var saveDirRules = {
            allGoods: "[所有宝贝]",
            report: "[任务报告]"
        };
        var _$listNode = '.shop-hesper dl.item, .shop-list div.item';
        var goodsCsv = saveDirRules.report + "/店铺宝贝.csv";

        if (page.first || !pageData.type) { //首页
            output('goodsCsv: ' + goodsCsv, 0);
            chrome.task.fopen({
                path: goodsCsv,
                mode: 'ab',
                header: '物品名称,价格,促销价格,30天内已售出,评论数,物品链接\n'
            });

            output('首页...');
            waitForAjax('a:contains("所有宝贝")', '', function(success) {
                if (!success) {
                    failAndClose('查找“所有宝贝”页面超时！');
                    return;
                }
                var goodsNode = jQuery('a:contains("所有宝贝")').first();
                chrome.task.addPage({
                    url: goodsNode[0].href,
                    data: JSON.stringify({
                        type: "allGoods"
                    })
                });

                chrome.task.finishPage({
                    savename: '店铺首页',
                    savedir: '/'
                });
            });

        } else if (pageData.type === 'allGoods') {
            output('所有宝贝页... ');
            waitForAjax('span.page-info', '', function(success) {
                //有两种展示方式： 
                //1. http://pusaidz.taobao.com/search.htm?spm=a1z10.1.0.0.fS7HL4&search=y
                //2. http://qianzhiduxiufloriculture.taobao.com/?spm=a1z10.1.0.0.ciIIwl&search=y
                var listNode = jQuery(_$listNode),
                    pagesNode = jQuery('span.page-info').first(),
                    totalNode = jQuery('div.search-result').first();

                if (!listNode.length || !pagesNode.length || !totalNode.length) {
                    failAndClose('查找物品列表的相关节点失败！');
                    return;
                }
                var totalPages = getNumbers(pagesNode.text(), /\d+/g)[1],
                    totalGoods = getNumber(totalNode.text());

                output('共有物品 ' + totalGoods + ' 件！');
                output('共有 ' + totalPages + ' 页！');

                for (var i = 1; i <= totalPages; i++) {
                    var link = curLocation + '&pageNum=' + i;
                    chrome.task.addPage({
                        url: link,
                        savedir: saveDirRules.allGoods,
                        savename: '所有宝贝页_第' + i + '页',
                        data: JSON.stringify({
                            type: "goodsList",
                            pageIndex: i
                        })
                    });
                }
                chrome.task.finishPage({
                    discard: true
                });
            });
        } else if (pageData.type === 'goodsList') {
            output('物品列表 第 ' + pageData.pageIndex + ' 页...');
            waitForAjax('span.page-info', '', function(success) {
                if (!success) {
                    failAndRetry(curLocation, '打开物品列表第 ' + pageData.pageIndex + ' 页超时！', pageData);
                    return;
                }
                var listNode = jQuery(_$listNode);
                output('第 ' + pageData.pageIndex + ' 页有' + listNode.length + '件物品！');

                listNode.each(function(index, el) {
                    var linkNode = jQuery('a.item-name, .desc a', el).first();
                    if (!linkNode.length) {
                        output('查找该物品链接失败， 忽略此物品!', 4);
                        return;
                    }
                    var sd = saveDirRules.allGoods + '/第' + pageData.pageIndex + '页',
                        sn = linkNode.text().replace(/[,\r\n\/\\]/g, ' ') + '_宝贝详情页';
                    chrome.task.addPage({
                        url: linkNode[0].href,
                        savedir: sd,
                        savename: sn,
                        data: JSON.stringify({
                            type: "goods",
                            name: sn
                        })
                    });
                });

                chrome.task.finishPage();
            });
        } else if (pageData.type === 'goods') {
            output(pageData.name + '...');
            waitForAjax('div.content', '', function(success) {
                if (!success) {
                    failAndRetry(curLocation, "打开" + pageData.name + '超时！', pageData);
                    return;
                }

                changePosition('#J_GoTop, #tstart, #J_TabBarWrap');
                var headNode = jQuery('.tb-detail-hd h3'),
                    priceNode = jQuery('.tb-meta #J_StrPrice'),
                    promoPriceNode1 = jQuery('.tb-meta #Li_promo .tb-lowest:visible'),
                    promoPriceNode2 = jQuery('.tb-meta #J_PromoPrice .tb-rmb-num:visible'),
                    soldNode = jQuery('.tb-meta .tb-sold-out .J_TDealCount'),
                    reviewNode = jQuery('.tb-meta .tb-evaluate .J_ReviewCount'); //如没有评价就找不到

                if (!headNode.length || !priceNode.length || !soldNode.length) {
                    failAndClose('解析' + pageData.name + '失败！');
                    return;
                }

                var headStr = headNode.text().replace(/[,\r\n\/\\]/g, ' '),
                    priceStr = priceNode.text(),
                    promoPriceStr = promoPriceNode1.text() + promoPriceNode2.text(),
                    soldCount = getNumber(soldNode.text()),
                    reviewCount = getNumber(reviewNode.text());

                chrome.task.fwrite({
                    path: goodsCsv,
                    text: headStr + ',' + priceStr + ',' + promoPriceStr + ',' + soldCount +',' + reviewCount + ',' + curLocation + '\n'
                });

                chrome.task.finishPage();
            });
        }
    });
});