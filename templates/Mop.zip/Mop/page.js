﻿chrome.task.startPage(function (page) {
	var option = page.option.length ? JSON.parse(page.option) : {};
	
	if(option.mode == 'asBoard')
		ProcessByBoard(page);
		
	if(option.mode == 'asUser')
		ProcessByUser(page);
});