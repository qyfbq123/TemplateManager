function newUserInfo() {
	var user = {};

	user.name = '';				//板块名称
	user.serach = '';			//板块地址

	return board;
}

function newTopicInfo() {
	var topic = {};

	topic.name = '';				//帖子名称
	topic.author = '';				//帖子作者
	topic.url = '';				//帖子地址
	topic.board = '';			//所属板块
	topic.time = '';				//发帖时间
	topic.view = '';				//总查看数
	topic.review = '';			//总跟帖数
	topic.desc = '';				//概述

	return topic;
}