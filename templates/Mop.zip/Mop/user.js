function ProcessByUser(page) {
	var pageData = page.data.length ? JSON.parse(page.data) : {};
	var option = page.option.length ? JSON.parse(page.option) : {};
	var totalTopicCsv = "帖子列表.csv";
	var topicCsvHeader = "帖子名称, 帖子作者, 帖子地址, 所属板块, 发帖时间, 总查看数, 总跟帖数, 概述\n";

	if (page.first) {
		var userList = decodeURI(decodeURI(option.filter));

		//用于构造用户输入的用户列表中百度搜索的主页
		var users = GetUsers(page, userList, option.mode);

		for (var i in users) {
			chrome.task.fopen({
				path: users[i] + "的个人文集/" + totalTopicCsv,
				mode: 'a',
				header: topicCsvHeader
			});
		}

		chrome.task.finishPage({
			discard: false
		});
	}

	//如果是百度的搜索结果
	if (pageData.type == "serach") {
		jQuery('.result .c-default').each(function(index, elem) {
			var url = getElementHrefSafe(elem, 'a', 0);
			var title = getElementTextSafe(elem, 'a', 0);
			if (title.indexOf(pageData.user) != -1) {
				jQuery(elem).attr('target', '_self');
				chrome.task.addPage({
					url: url,
					savedir: pageData.user + "/帖子列表",
					savename: '第1页',
					priority: 'high',
					data: JSON.stringify({
						type: 'userPageList',
						path: pageData.user,
						currpage: 1
					})
				});
				return false;
			}
		});
		output("发现【" + pageData.user + "】第1页");
		chrome.task.finishPage();
	}
	//如果是用户主页就开始固定网页
	if (pageData.type === "userPageList") {
		var topics = GetUserTopics(page);
		var nextPage = GetNextPage(page);

		if (nextPage) {
			chrome.task.addPage({
				url: nextPage,
				savedir: page.savedir,
				savename: "第" + String(pageData.currpage + 1) + "页",
				data: JSON.stringify({
					type: 'userPageList',
					currpage: ++pageData.currpage,
					path: pageData.path
				})
			});

			output("发现【" + pageData.path + "】第" + String(pageData.currpage) + "页");
		}

		for (var j in topics) {
			var topic = topics[j];
			chrome.task.addPage({
				url: topic.url,
				savedir: pageData.path + "/第" + pageData.currpage + "页",
				data: JSON.stringify({
					type: 'topic'
				})
			});

			var topicCsvText = GetCsvText(topic);
			chrome.task.fwrite({
				path: pageData.path + "/" + totalTopicCsv,
				text: topicCsvText
			});
			output("正在固定 第【" + String(pageData.currpage) + "】页的帖子：" + topic.name);
			chrome.task.finishPage();
		}

		chrome.task.finishPage();
	}
	
	if(pageData.type === "topic") {
	chrome.task.finishPage();
	}
}


//搜索到用户帖子列表，开始固定帖子

function GetUserTopics(page) {
	var count = 0;
	var topics = [];

	jQuery('.wenji_content').each(function(index, elem) {
		var topic = newTopicInfo();
		topic.name = getElementTextSafe(elem, '.wenji_title a', 0); //帖子名称
		topic.url = getElementHrefSafe(elem, '.wenji_title a', 0); //帖子地址

		//作者：抽象熊猫　　 发布时间：2013-10-21 22:54:13　　 来自： 猫扑贴贴论坛 > 龙门茶社 > 闲聊茶馆
		var str = getElementTextSafe(elem, '.cgery.padtb5', 0);
		var indexAuthor = str.indexOf('作者');
		var indexTime = str.indexOf('发布时间');
		var indexFrom = str.indexOf('来自');
		topic.author = str.substring(indexAuthor, indexTime);
		topic.board = str.substring(indexFrom);
		topic.time = str.substring(indexTime, indexFrom); //发帖时间

		var viewStr = getElementTextSafe(elem, '.right.cgery', 0);
		viewStr = viewStr.split('|');
		topic.view = viewStr[0]; //总查看数
		topic.review = viewStr[1]; //总跟帖数
		topic.desc = getElementTextSafe(elem, '.cont', 0); //概述

		if (topic.name !== "" && topic.url !== "")
			topics[count++] = topic;
	});

	return topics;
}

function GetNextPage(page) {
	return getElementHrefSafe('', '.tiezi_page_fy a:contains("下一页")', 0);
}

//用于构造用户输入的用户列表中百度搜索的主页

function GetUsers(page, userList, mode) {
	var users = userList.split("\n");

	for (var i in users) {
		var user = users[i];
		var serachUrl = "http://www.baidu.com/s?wd=site%3Amop.com+" + user + "的个人文集";
		chrome.task.addPage({
			url: serachUrl,
			savedir: "/百度搜索结果",
			savename: user,
			priority: 'high',
			data: JSON.stringify({
				type: 'serach',
				user: user + "的个人文集"
			})
		});

		output("将要固定该用户【【" + user + "】】");
	}
	return users;
}


//获得内容csv样式

function GetCsvText(topic) {
	return topic.name + "," +
		topic.author + "," +
		topic.url + "," +
		topic.board + "," +
		topic.time + "," +
		topic.view + "," +
		topic.review + "," +
		topic.desc + "\n";
}