﻿chrome.task.startPage(function (page) {
	
	var data = page.data.length ? JSON.parse(page.data) : {};
	var option = page.option.length ? JSON.parse(page.option) : {};

	if (page.first) {
		//url 输入框读取
		var file = option.UrlText;
		
		var url = unescape(file);
		var urlList = url.split('\r\n');
		
		for (var i = 0; i < urlList.length; ++i){
			var item = urlList[i];
			if (/(http|ftp)s?:\/\/.*/.test(item)){
				item = 'http://'+item;
			}
			chrome.task.addPage({
			url : urlList[i]
			});
		}
		chrome.task.finishPage();
	} else {
		chrome.task.finishPage();
	}
});

function output(message, level) {
    var param = {
        text: message,
        level: typeof(level) == 'number' ? level : 1
    }
    chrome.task.output(param);
}