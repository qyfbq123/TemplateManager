var _$jq = jQuery.noConflict();
function autoScroll(selector, iframeContext, process) {
    //说说 page autoscroll!
    var interval = 1000, //ms
        timeOut = 10000, //ms
        id = 0,
        el = [];

    var doScroll = function () {
        chrome.task.output({
            text: 'autoScroll...'
        });

        timeOut -= interval;
        if (iframeContext === undefined || iframeContext === '')
            el = jQuery(selector);
        else
            el = jQuery(selector, jQuery(iframeContext)[0].contentDocument);

        if (el.length !== 0 || timeOut <= 0) {
            //scroll to the end!
            jQuery("html, body").scrollTop(0);
            window.clearInterval(id);
            process();
            return;
        }
        chrome.task.keepAlive();
        jQuery("html, body").scrollTop(jQuery(document).height());
    };
    chrome.task.keepAlive();
    id = window.setInterval(doScroll, interval);
}

function waitForAjax(selector, iframeContext, process) {
    //因为某些页面需要加载ajax, 所以用此方法来判断ajax是否已经加载完， 
    //然后才处理页面。
    //因为考虑到ifame的选择器很复杂， selectorCode 不仅是一个选择器， 还是一段可执行的 js 代码。
    //chrome.task.output({text: 'Wait for Ajax: ' + selectorCode});
    var interval = 1000; //ms
    var timeOut = 10000; //ms
    var id = 0,
        el = [];
    var doPage = function () {
        chrome.task.output({
            text: 'waitForAjax...'
        });
        timeOut -= interval;
        if (iframeContext === undefined || iframeContext === '')
            el = jQuery(selector);
        else
            el = jQuery(selector, jQuery(iframeContext)[0].contentDocument);

        if (el.length >= 1 || timeOut <= 0) {
            window.clearInterval(id);
            process();
        }

        chrome.task.keepAlive();
    };

    id = window.setInterval(doPage, interval);
}

function waitForChange(origin, selector, iframeContext, attrName, process) {
    var interval = 1000, //ms
        timeOut = 10000, //ms
        el = [];

    //if origin is empty, then it means NOT wait for change...
    if ( !origin ) {
        process( true );
        return;
    }

    var doCompare = function () {
        chrome.task.output({
            text: 'waitForChange...'
        });

        timeOut -= interval;
        if (iframeContext === undefined || iframeContext === '')
            el = jQuery(selector);
        else
            el = jQuery(selector, jQuery(iframeContext)[0].contentDocument);

        var present = el.attr(attrName);
        if ((el.length > 0 && origin != present) || timeOut <= 0) {
            window.clearInterval(id);
            process(timeOut <= 0);
        }
        chrome.task.keepAlive();
    };

    var id = window.setInterval(doCompare, interval);
}