﻿var addPages = function (urlList, _param, _func){
    chrome.task.output({text: 'AddPage length: '+urlList.length});
    for (var item = urlList.length - 1; item >= 0; item--) {
        if(urlList[item].href){
            var param = _param || {};
            param.url = urlList[item].href;
            param.output = 'url:' + urlList[item].href;
            if(_func)
                param = _func.call(urlList[item], param);
            chrome.task.addPage(param);
        }
    }
    
    chrome.task.output({text: 'AddPage: '+urlList.length});
};

var saveDirRules = {
    timeline: "[时间线]",
    album: "[相册]",
    report: "[任务报告]"
};
jQuery('document').ready(function(){
    chrome.task.startPage(function (page) {
    
        //模板脚本的实现
        var pageData = page.data.length ? JSON.parse(page.data) : {};
        var option = page.option.length ? JSON.parse(page.option) : {};
        if (page.first || pageData.type === undefined) { //首页
            var endFlag = function(){ return false; };
            var filter = 'a';
            var mainSel = '#timeline_tab_content ';
            if( jQuery(document.body).hasClass('_4lh') ) {
                mainSel += '._4_7u ';
            }
            if(option.mode == 'r_total') {
                var total;
                if( !isNaN(option.total) && (total = Number(option.total)) > 0 ) {
                    endFlag = function() {
                        return jQuery( mainSel + 'li[id^="tl_unit"]' ).length >= total;
                    };
                    filter = ':lt(' + total + ')';
                }
            } else if( option.mode == 'r_endDate' ) {
                if( /^\d{4}\-\d{1,2}\-\d{1,2}$/.test(option.endDate) ) {
                    var edf = option.endDate.split('-');//end date fragments
                    var endDate = new Date( Number(edf[0]), Number(edf[1]) - 1, Number(edf[2]) ).getTime();
                    endFlag = function() {
                        var preEnd = jQuery(mainSel + 'li[id^="tl_unit"]:last .timelineUnitContainer').data('time');
                        return endDate/1000 >= Number(preEnd);
                    };
                    filter = function(index, elem) {
                        return endDate/1000 <= Number(elem.childNodes[0].dataset.utime);
                    };
                }
            }

            if( option.photos ) {
                addPages(
                    jQuery('a:contains("Photos"):first'),
                    {
                        savedir: saveDirRules.album,
                        data: JSON.stringify({type: 'albumList'})
                    }
                );
            }

            (function checkTimeline(flag) {
                if(flag || endFlag()) {
                    chrome.task.output({text: mainSel + 'li[id^="tl_unit"]'});
                    addPages(
                        jQuery(mainSel + 'li[id^="tl_unit"]').find('a.uiLinkSubtle:first').filter(filter),
                        {
                            data: JSON.stringify({type: 'timeline'}),
                            savedir: saveDirRules.timeline
                        }
                    );
                    jQuery('.fixed_always,.fixed_elem').removeClass('fixed_always fixed_elem');
                    chrome.task.finishPage();
                    return;
                }
                var originId = jQuery(mainSel + 'li[id^="tl_unit"]:last').attr('id');
                var _$aScroll = jQuery('.fbTimelineSectionExpandPager.fbTimelineShowOlderSections a.uiMorePagerPrimary');
                if(_$aScroll.length > 0) {
                    _$aScroll[0].click();
                }
                jQuery("html, body").scrollTop(jQuery(document).height());
                
                waitForChange( originId, mainSel + 'li[id^="tl_unit"]:last', '', 'id', checkTimeline );
            }());
        } else if( pageData.type == 'timeline' ) {
            chrome.task.finishPage();
        } else if( pageData.type == 'albumList' ) {
            var _$a = jQuery('a:contains("Albums"):first');
            addPages(
                _$a,
                {
                    data: JSON.stringify({type: 'albumList_2'}),
                    savedir: saveDirRules.album,
                    savename: '相册'
                }
            );
            chrome.task.finishPage();
        } else if( pageData.type == 'albumList_2' ) {
            addPages(
                jQuery( 'a.photoTextTitle', jQuery('table.uiGrid._51mz.fbPhotosGrid') ),
                undefined,
                function(_param) {
                    _param.savedir = saveDirRules.album + '/' + jQuery(this).text();
                    var data = {type: 'album'};
                    data.albumName = jQuery(this).text();
                    _param.data = JSON.stringify(data);
                    return _param;
                }
            );
            chrome.task.finishPage();

        } else if( pageData.type == 'album' ) {
            (function _autoScroll(flag) {
                if(flag) {
                    addPages(
                        jQuery('._53s.fbPhotoCurationControlWrapper.fbPhotoStarGridElement.fbPhotoStarGridNonStarred._53s.fbPhotoCurationControlWrapper>a'),
                        {
                            savedir: saveDirRules.album + '/' + pageData.albumName,
                            data: JSON.stringify({type: 'photo'})
                        }
                    );
                    chrome.task.finishPage();
                    return;
                }

                var originId = jQuery('._53s.fbPhotoCurationControlWrapper.fbPhotoStarGridElement.fbPhotoStarGridNonStarred._53s.fbPhotoCurationControlWrapper:last').data('data-fbid');
                jQuery("html, body").scrollTop(jQuery(document).height());
                waitForChange( originId, '._53s.fbPhotoCurationControlWrapper.fbPhotoStarGridElement.fbPhotoStarGridNonStarred._53s.fbPhotoCurationControlWrapper:last', '', 'data-fbid', _autoScroll );
            }());
        } else if( pageData.type == 'photo' ) {
            chrome.task.finishPage();
        }
    });
});
