﻿jQuery('document').ready(function() {
    chrome.task.startPage(function(page) {
        //chrome.task.output({text: 'page data: '+data});
        var pageData = page.data.length ? JSON.parse(page.data) : {};

        //Weibo Template options:
        Output('page: ' + page.option + '  ' + page.data);

        var options = page.option.length ? JSON.parse(page.option) : {};
        var limitedCounts = -1, //-1 代表不限制
            limitedDate = 0,
            dFollower = true,
            dWatcher = true;

        //Parse options
        if (options.postLimit === 'limitedCounts') {
            limitedCounts = options.limitedCounts;
        } else if (options.postLimit === 'limitedDate') {
            if (!(/^\d{4}-\d{1,2}-\d{1,2}$/.test(options.limitedDate))) {
                Output('模板选项-日期限制输入有误！任务退出！', 4);
                chrome.task.finishPage({
                    discard: true
                });
                return;
            }
            var edf = options.limitedDate.split('-'); //end date fragments
            Output(edf.toString());
            limitedDate = new Date(Number(edf[0]), Number(edf[1]) - 1, Number(edf[2])).getTime();
        }

        dFollower = options.dFollower === 'yes';
        dWatcher = options.dWatcher === 'yes';

        var saveDirRules = {
            tweets: "[推文]",
            watcher: "[关注]",
            follower: "[粉丝]",
            other: "[其它]",
            report: "[任务报告]"
        };

        var tweetsCsv = saveDirRules.report + "/推文列表.csv",
            watcherCsv = saveDirRules.report + "/关注列表.csv",
            followerCsv = saveDirRules.report + "/粉丝列表.csv";

        if (page.first || pageData.type === undefined) { //首页
            chrome.task.fopen({
                path: tweetsCsv,
                mode: 'ab',
                header: '用户名,Profile Name, UserID,发表时间,内容,链接\n'
            });
            Output('首页...');
            var tweetIndex = 0,
                curTweetNode = 0;
            //目标用户的UserID
            var curUserID = jQuery('.profile-header .profile-card-inner').attr('data-user-id');

            var processTweet = function(lastTweetNode) {
                if (!lastTweetNode || lastTweetNode.length === 0) {
                    curTweetNode = jQuery('.stream-container .js-stream-item').first();
                } else {
                    curTweetNode = jQuery(lastTweetNode).next();
                }
                if (curTweetNode.length !== 0) {
                    tweetIndex += 1;

                    var content = jQuery('.content .tweet-text', curTweetNode).first().text(),
                        userName = jQuery('.content .fullname', curTweetNode).first().text(),
                        profileName = jQuery('.content .username', curTweetNode).first().text(),
                        userID = jQuery('.content .account-group', curTweetNode).first().attr('data-user-id'),
                        date = jQuery('.content .time a', curTweetNode).first().attr('title'),
                        jsDate = Number(jQuery('.content .time ._timestamp', curTweetNode).first().attr('data-time') + '000'),
                        link = jQuery('.content .time a', curTweetNode)[0].href;

                    content = content ? content.replace(/,/g, '.') : '';
                    date = date ? date.replace(/,/g, '.') : '';

                    if (limitedCounts >= 0 && tweetIndex > limitedCounts) {
                        Output('达到 tweet 限制数: ' + limitedCounts);
                        curTweetNode = lastTweetNode;
                        return false;
                    }

                    //因为有些转发的tweet时间很老， 但是也会出现在最新的tweet中， 所以要比较 userid。。。
                    if (jsDate < limitedDate && userID === curUserID) {
                        Output('达到限制日期: ' + options.limitedDate + ':' + new Date(jsDate));
                        curTweetNode = lastTweetNode;
                        return false;
                    }

                    //Output(tweetIndex + "st tweet!!!");

                    chrome.task.addPage({
                        url: link,
                        savedir: saveDirRules.tweets,
                        savename: 'Tweet_' + tweetIndex,
                        data: JSON.stringify({
                            type: 'tweet'
                        })
                    });

                    chrome.task.fwrite({
                        path: tweetsCsv,
                        text: userName + ',' + profileName + ',' + userID + ',' + date + ',' + content + ',' + link + '\n'
                    });

                    return processTweet(curTweetNode);
                } else {
                    curTweetNode = lastTweetNode;
                    return true;
                }

            };

            //添加粉丝和关注页面。
            var indexPage = document.location.href;
            var followingUrl = indexPage.match(/.*?:\/\/twitter.com\/[^\/]+/) + '/following',
                followersUrl = indexPage.match(/.*?:\/\/twitter.com\/[^\/]+/) + '/followers';

            if (dWatcher) {
                chrome.task.addPage({
                    url: followingUrl,
                    savedir: saveDirRules.watcher,
                    savename: 'following',
                    data: JSON.stringify({
                        type: 'watcher'
                    })
                });
            }
            if (dFollower) {
                chrome.task.addPage({
                    url: followersUrl,
                    savedir: saveDirRules.follower,
                    savename: 'followers',
                    data: JSON.stringify({
                        type: 'follower'
                    })
                });
            }

            waitForAjax('.stream-footer .has-more-items', '', function() {
                scrollDown(
                    function(count) {
                        Output('首页， 第' + count + '屏...');
                        return processTweet(curTweetNode);
                    },
                    function() {
                        Output('首页处理完毕');
                        chrome.task.finishPage({
                            discard: true
                        });
                    });
            });

        } else if (pageData.type === 'tweet') {
            chrome.task.output({
                text: 'Tweet页...' /*+ document.title + ' 页面大小：' + document.body.scrollWidth + ' x ' + document.body.scrollHeight*/
            });

            chrome.task.finishPage();
        } else if (pageData.type === 'watcher') {
            chrome.task.fopen({
                path: watcherCsv,
                mode: 'ab',
                header: '用户名,Profile Name, UserID,链接\n'
            });
            Output('关注页...');
            var watcherIndex = 0,
                curWatcherNode = 0;

            var processWatcher = function(lastWatcherNode) {
                if (!lastWatcherNode || lastWatcherNode.length === 0) {
                    curWatcherNode = jQuery('.stream-container .js-stream-item').first();
                } else {
                    curWatcherNode = jQuery(lastWatcherNode).next();
                }
                if (curWatcherNode.length !== 0) {
                    watcherIndex += 1;

                    var userName = jQuery('.content .fullname', curWatcherNode).first().text(),
                        profileName = jQuery('.content .username', curWatcherNode).first().text(),
                        userID = jQuery('.content img.avatar', curWatcherNode).first().attr('data-user-id'),
                        link = jQuery('.content a.account-group', curWatcherNode)[0].href;

                    chrome.task.fwrite({
                        path: watcherCsv,
                        text: userName + ',' + profileName + ',' + userID + ',' + link + '\n'
                    });

                    return processWatcher(curWatcherNode);
                } else {
                    curWatcherNode = lastWatcherNode;
                    return true;
                }
            };

            waitForAjax('.stream-footer .has-more-items', '', function() {
                scrollDown(
                    function(count) {
                        Output('关注页， 第' + count + '屏...');
                        return processWatcher(curWatcherNode);
                    },
                    function() {
                        Output('关注页处理完毕');
                        chrome.task.finishPage();
                    });
            });


        } else if (pageData.type === 'follower') {
            chrome.task.fopen({
                path: followerCsv,
                mode: 'ab',
                header: '用户名,Profile Name, UserID,链接\n'
            });
            Output('粉丝页...');
            var followerIndex = 0,
                curFollowerNode = 0;

            var processFollower = function(lastFollowerNode) {
                if (!lastFollowerNode || lastFollowerNode.length === 0) {
                    curFollowerNode = jQuery('.stream-container .js-stream-item').first();
                } else {
                    curFollowerNode = jQuery(lastFollowerNode).next();
                }
                if (curFollowerNode.length !== 0) {
                    followerIndex += 1;

                    var userName = jQuery('.content .fullname', curFollowerNode).first().text(),
                        profileName = jQuery('.content .username', curFollowerNode).first().text(),
                        userID = jQuery('.content img.avatar', curFollowerNode).first().attr('data-user-id'),
                        link = jQuery('.content a.account-group', curFollowerNode)[0].href;

                    chrome.task.fwrite({
                        path: followerCsv,
                        text: userName + ',' + profileName + ',' + userID + ',' + link + '\n'
                    });

                    return processFollower(curFollowerNode);
                } else {
                    curFollowerNode = lastFollowerNode;
                    return true;
                }
            };

            waitForAjax('.stream-footer .has-more-items', '', function() {
                scrollDown(
                    function(count) {
                        Output('粉丝页， 第' + count + '屏...');
                        return processFollower(curFollowerNode);
                    },
                    function() {
                        Output('粉丝页处理完毕');
                        chrome.task.finishPage();
                    });
            });
        } else {
            chrome.task.output({
                text: '其它页: ' + document.title + ' 页面大小：' + document.body.scrollWidth + ' x ' + document.body.scrollHeight
            });
            chrome.task.output({
                text: 'Page finished!'
            });
            chrome.task.finishPage();
        }
    });
});