var _$jq = jQuery.noConflict();

//向控制台输出信息
//等级0~7分级代表调试、信息、注意、警告、错误、重要、严重、致命
//如果不指定消息等级，默认等级为“信息”

function Output(message, level) {
    var param = {
        text: message,
        level: typeof(level) == 'number' ? level : 1
    };
    chrome.task.output(param);
}

//模拟鼠标事件
//selector是指带操作元素的选择器
//action指定要模拟的事件，可以为"Click","RightClick",
// "LeftDown","LeftUp","RightDown","RightUp"

function ElementMouseEvent(selector, action) {
    var elems = jQuery(selector);
    if (elems.length === 0)
        return;

    var rc = elems[0].getBoundingClientRect();

    var scroll_pos = rc.bottom - rc.height;
    if (scroll_pos > jQuery(document).height())
        scroll_pos = jQuery(document).height();

    Output('Scroll to ' + scroll_pos, 0);
    jQuery("html, body").scrollTop(scroll_pos);

    rc = elems[0].getBoundingClientRect();
    var X = rc.left + rc.width / 2;
    var Y = rc.bottom - rc.height / 2;

    Output(action + ' at ' + X + ' x ' + Y, 0);
    chrome.task.mouseEvent({
        action: action,
        x: parseInt(X, 10),
        y: parseInt(Y, 10)
    });
}

function autoScroll(selector, context, process) {
    //说说 page autoscroll!
    var interval = 1000, //ms
        timeOut = 10000, //ms
        id = 0,
        el = [];

    var doScroll = function() {
        Output('autoscroll...', 0);

        timeOut -= interval;
        el = jQuery(selector, context);
        if (el.length !== 0 || timeOut <= 0) {
            //scroll to the end!
            jQuery("html, body").scrollTop(0);
            window.clearInterval(id);
            process();
            return;
        }
        chrome.task.keepAlive();
        jQuery("html, body").scrollTop(jQuery(document).height());
    };
    chrome.task.keepAlive();
    id = window.setInterval(doScroll, interval);
}

//往下滚动一屏， 然后回调处理， 直至末尾。
//process： 回调函数， 每滚动一屏时调用。 如果返回false, 则不再往下滚动。
//processFinish: 回调函数， 当页面不再往下滚动时调用。 

function scrollDown(process, processFinish) {
    var interval = 1000,
        timeout = 10000, //ms
        waitTime = 0,
        lastHeight = 0,
        curHeight = 0,
        id = 0,
        scrollCount = 0;

    lastHeight = jQuery(document).height();
    var check = function() {
        //下面这段代码是防止网页不继续往下加载。。。
        if (timeout < 5000) {
            jQuery("html, body").scrollTop(0);
            jQuery("html, body").scrollTop(jQuery(document).height());
        }

        curHeight = jQuery(document).height();
        timeout -= interval;
        waitTime += interval;
        Output('wait for scrollDown...' + waitTime / 1000 + '(s)', 0);

        chrome.task.keepAlive();

        if (timeout <= 0) { //到了末尾
            // Output('scrollDown 等待超时...');
            Output('最后一屏...', 0);
            window.clearInterval(id);
            process(scrollCount);
            processFinish();
        } else if (curHeight > lastHeight) {
            window.clearInterval(id);
            if (false === process(scrollCount)) {
                processFinish();
            } else {
                doScroll();
            }
        }
    };

    var doScroll = function() {
        scrollCount += 1;
        timeout = 10000; //ms
        waitTime = 0;
        lastHeight = jQuery(document).height();
        jQuery("html, body").scrollTop(jQuery(document).height());

        id = window.setInterval(check, interval);
    };

    doScroll();
}

function waitForAjax(selector, context, process) {
    //因为某些页面需要加载ajax, 所以用此方法来判断ajax是否已经加载完， 
    //然后才处理页面。
    //因为考虑到ifame的选择器很复杂， selectorCode 不仅是一个选择器， 还是一段可执行的 js 代码。
    //chrome.task.output({text: 'Wait for Ajax: ' + selectorCode});
    var interval = 1000; //ms
    var timeOut = 10000; //ms
    var id = 0,
        el = [];
    var doPage = function() {
        Output('waitForAjax...', 0);
        timeOut -= interval;

        el = jQuery(selector, context);
        if (el.length >= 1 || timeOut <= 0) {
            window.clearInterval(id);
            process();
        }

        chrome.task.keepAlive();
    };

    id = window.setInterval(doPage, interval);
}

function waitForChange(origin, selector, context, attrName, process) {
    var interval = 1000, //ms
        timeOut = 10000, //ms
        el = [];

    //if origin is empty, then it means NOT wait for change...
    if (origin === '' || origin === undefined) {
        process();
        return;
    }

    var doCompare = function() {
        Output('waitForChange...', 0);

        timeOut -= interval;
        el = jQuery(selector, context);
        var present = el.attr(attrName);
        if ((el.length > 0 && origin != present) || timeOut <= 0) {
            window.clearInterval(id);
            process();
        }
        chrome.task.keepAlive();
    };

    var id = window.setInterval(doCompare, interval);
}