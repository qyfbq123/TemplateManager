chrome.extension.onMessage.addListener(function(request, sender, sendResponse){
   
    //chrome.tabs.create({url:'http://www.douban.com'});
});


