﻿chrome.task.startPage(function(page) {
    //chrome.task.output({text: 'page data: '+data});
    var pageData = page.data.length ? JSON.parse(page.data) : {};

    //Weibo Template options:
    // chrome.task.output({
    //     text: 'page: ' + page.option + '  ' + page.data
    // });
    var options = page.option.length ? JSON.parse(page.option) : {};
    var limitedWeiboPages = -1, //-1 代表不限制
        dFollower = true,
        dWatcher = true,
        dUserInfo = true;

    //Parse options
    if (options.postLimit === 'limitedPages') {
        limitedWeiboPages = options.limitedPages;
    }

    dFollower = options.dFollower === 'yes';
    dWatcher = options.dWatcher === 'yes';
    dUserInfo = options.dUserInfo === 'yes';

    var saveDirRules = {
        weibo: "[微博]",
        personalInfo: "[个人资料]",
        watcher: "[收听]",
        follower: "[听众]",
        other: "[其它]",
        report: "[任务报告]"
    };

    var weiboCsv = saveDirRules.report + "/微博列表.csv";

    if (page.first || pageData.type === undefined || pageData.type === 'weibo') { //首页
        chrome.task.fopen({
            path: weiboCsv,
            mode: 'ab',
            header: '作者,发表时间,内容,阅读数,单独链接\n'
        });

        //如果首页是滚动方式， 是没有#pageNav节点的。
        waitForAjax('#pageNav, #pageSetLink:contains("翻页")', '', function() {
            var pageNode = jQuery('#pageNav a');
            var curPageNum = parseInt(jQuery('#pageNav strong').text(), 10);
            if (page.first) {
                if (dUserInfo) {
                    chrome.task.addPage({
                        url: jQuery('#userAppTab a[boss="btn_guest_UserInfo"]').attr('href'),
                        savedir: saveDirRules.personalInfo,
                        savename: '用户信息页',
                        data: JSON.stringify({
                            type: 'personalInfo'
                        })
                    });
                }

                //收听页一定要添加， 否则获取不了听众页面。。。
                chrome.task.addPage({
                    url: jQuery('#userAppTab a[boss="btn_guest_Follow"]').attr('href'),
                    savedir: saveDirRules.watcher,
                    savename: '收听_第1页',
                    data: JSON.stringify({
                        type: 'watcher'
                    })
                });
            }

            //页面数限制
            if (limitedWeiboPages >= 0 && curPageNum > limitedWeiboPages) {
                Output('微博页面处理完毕！', 1);
                chrome.task.finishPage({
                    discard: true
                });
                return;
            }

            //主页可能是滚动方式， 需要设置为翻页方式。
            if (jQuery('#pageSetLink').text().indexOf('翻页') !== -1) {
                Output('切换为翻页方式！', 1);
                chrome.task.addPage({
                    url: jQuery('#pageSetLink')[0].href,
                    savedir: saveDirRules.weibo,
                    savename: '腾讯微博_第1页'
                });

                chrome.task.finishPage({
                    discard: true
                });

                return;
            }

            Output('微博第' + curPageNum + '页...', 1);
            pageNode.each(function(index, val) {
                //必须将字符串的数字转换为整数， 否则比较会有误。。。
                var pageNumber = parseInt(val.innerText.match(/\d+/), 10);
                if (pageNumber && (limitedWeiboPages < 0 || pageNumber <= limitedWeiboPages) && pageNumber > curPageNum) {
                    chrome.task.addPage({
                        url: val.href + '&pagesetMyhome=1',
                        savedir: saveDirRules.weibo,
                        savename: '腾讯微博_第' + pageNumber + '页'
                    });
                }
            });
            var weiboNode = jQuery('#listWrapper li[from]');
            weiboNode.each(function(index, el) {
                var userName = jQuery('.userName a', el).text(),
                    date = jQuery('.left .time', el).last().attr('title'),
                    reads = jQuery('.left .cNote', el).last().attr('title'),
                    links = jQuery('.left .time', el).last().attr('href'),
                    content = jQuery('.msgCnt', el).first().text();

                reads = reads ? reads.match(/\d+/) : 0;
                content = content ? content.replace(/,/g, '.') : '';

                chrome.task.fwrite({
                    path: weiboCsv,
                    text: userName + ',' + date + ',' + content + ',' + reads + ',' + links + '\n'
                });
            });

            chrome.task.finishPage({
                savename: '腾讯微博_第' + curPageNum + '页',
                savedir: saveDirRules.weibo
            });
        });
    } else if (pageData.type == 'watcher') {
        //听众和收听页面下的导航其实都是ajax翻页的。。。
        var curWatchPage = 0;
        var watcherCsv = saveDirRules.report + "/收听列表.csv";
        if (dWatcher) {
            chrome.task.fopen({
                path: watcherCsv,
                mode: 'ab',
                header: 'UID,用户名,主页链接\n'
            });
        }

        (function processWatcher(compareText) {
            waitForChange(compareText, '.msgBox .userName a', '', 'href', function() {
                waitForAjax('.pageNav', '', function() {
                    curWatchPage += 1;

                    //添加粉丝页面
                    if (dFollower && curWatchPage == '1') {
                        chrome.task.addPage({
                            url: jQuery('.subTab1 a.tab:contains("的听众")').attr('href'),
                            savedir: saveDirRules.follower,
                            savename: '听众_第1页',
                            data: JSON.stringify({
                                type: 'follower'
                            })
                        });
                    }

                    Output('他的收听页， 第' + curWatchPage + '页...', 1);

                    if (dWatcher) {
                        var userNode = jQuery('.msgBox');
                        userNode.each(function(index, el) {
                            var userName = jQuery('.userName a', el)[0].innerText,
                                uid = el.getAttribute('uid'),
                                links = jQuery('.userName a', el)[0].href;

                            chrome.task.fwrite({
                                path: watcherCsv,
                                text: uid + ',' + userName + ',' + links + '\n'
                            });
                        });

                        chrome.task.snapshot({
                            savedir: saveDirRules.watcher,
                            savename: '收听_第' + curWatchPage + '页'
                        }, function(detail) {
                            var cpText = jQuery('.msgBox .userName a').attr('href');

                            var next = jQuery('.pageNav .pageBtn:contains("下一页")');
                            if (next.length > 0) {
                                //跳转到下一页
                                next[0].click();
                                processWatcher(cpText);
                            } else {
                                Output('收听页下载完毕！', 1);
                                chrome.task.finishPage({
                                    discard: true
                                });
                            }
                        });


                    } else {
                        chrome.task.finishPage({
                            discard: true
                        });
                    }

                });
            });
        }());
    } else if (pageData.type === 'follower') {
        var curFollowerPage = 0;
        var followerCsv = saveDirRules.report + "/听众列表.csv";
        if (dFollower) {
            chrome.task.fopen({
                path: followerCsv,
                mode: 'ab',
                header: 'UID,用户名,主页链接\n'
            });
        }

        (function processFollower(compareText) {
            waitForChange(compareText, '.msgBox .userName a', '', 'href', function() {
                waitForAjax('.pageNav', '', function() {
                    curFollowerPage += 1;
                    Output('他的听众页， 第' + curFollowerPage + '页...');

                    if (dFollower) {
                        var userNode = jQuery('.msgBox');
                        userNode.each(function(index, el) {
                            var userName = jQuery('.userName a', el)[0].innerText,
                                uid = el.getAttribute('uid'),
                                links = jQuery('.userName a', el)[0].href;

                            chrome.task.fwrite({
                                path: followerCsv,
                                text: uid + ',' + userName + ',' + links + '\n'
                            });
                        });

                        chrome.task.snapshot({
                            savedir: saveDirRules.follower,
                            savename: '听众_第' + curFollowerPage + '页'
                        }, function(detail) {
                            var cpText = jQuery('.msgBox .userName a').attr('href');

                            var next = jQuery('.pageNav .pageBtn:contains("下一页")');
                            if (next.length > 0) {
                                //跳转到下一页
                                next[0].click();
                                processFollower(cpText);
                            } else {
                                Output('听众页下载完毕！', 1);
                                chrome.task.finishPage({
                                    discard: true
                                });
                            }
                        });


                    } else {
                        chrome.task.finishPage({
                            discard: true
                        });
                    }

                });
            });
        }());


    } else if (pageData.type === 'personalInfo') {
        Output('用户信息页: ' + document.title, 1);

        waitForAjax('.u_info_hd', '', function() {
            chrome.task.finishPage();
        });
    } else {
        Output('其它页: ' + document.title, 1);
        Output('Page finished!', 1);
        chrome.task.finishPage();
    }
});