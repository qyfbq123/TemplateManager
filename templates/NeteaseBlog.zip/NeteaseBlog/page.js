﻿function addArticles(articlesFilter, pagesFilter, pageNumberFilter, page){
	var pageData = page.data.length ? JSON.parse(page.data) : {};
	
	//加载超时
	page.loadTimes++;
	if(page.loadTimes > 10){
		chrome.task.output({text: 'load timeout'});
		chrome.task.finishPage();
		return;
	}
	
	DelayedExecute(1000, function(){
		var articles = $(articlesFilter);
		var pages = $(pagesFilter);
		var pageNum = $(pageNumberFilter);
		var finish = false;
		
		chrome.task.output({text: 'loading……'});
		if(pages.size()>0 && articles.size()>0){
			page.loadTimes = 0;
			if(pageData.type == 'normal'){
				//添加博文
				articles.each(function(index, item){
					if(pageData.nowNum < pageData.maxNum || pageData.maxNum == 0){
						chrome.task.addPage({
							url: item.href,
							savedir: pageData.savedir + '/第' + pageData.nowPage + '页',
							savename: item.text,
							data: JSON.stringify({type: 'articles', title: item.text, href: item.href})
						});
						pageData.nowNum++;
					}
				});
				
				//最后一页
				if(pages[pages.size()-1].className.indexOf('js-znpg-097', 1)!=-1)
					finish = true;
					
				//下载数达到最大
				if(pageData.maxNum!=0 && pageData.nowNum>=pageData.maxNum)
					finish = true;
					
				//截图
				chrome.task.snapshot({
					savedir: page.savedir,
					savename: '第' + pageData.nowPage + '页'
					},
					function(result){
						if(!finish){
							pages[pages.size()-1].click();
							pageData.nowPage++;
							page.data = JSON.stringify({type: 'normal', maxNum: pageData.maxNum, nowNum: pageData.nowNum, nowPage: pageData.nowPage, savedir: '博文'});
							addArticles(articlesFilter, pagesFilter, pageNumberFilter, page);
						}else{
							chrome.task.finishPage({snapshot: false});
						}
					}
				);
			}
			
			if(pageData.type == 'classify'){
				articles.each(function(index, item){
					chrome.task.addPage({
						url: item.href,
						savedir: pageData.savedir + '/第' + pageData.nowPage + '页',
						savename: item.text,
						force: true,
						data: JSON.stringify({type: 'articles', title: item.text, href: item.href})
					});
				});
				
				if(pages[pages.size()-1].className.indexOf('js-znpg-097', 1)!=-1)
					finish = true;
				
				chrome.task.snapshot({
					savedir: pageData.savedir,
					savename: '第' + pageData.nowPage + '页'
					},
					function(result){
						if(result.success&&!finish){
							pages[pages.size()-1].click();
							pageData.nowPage++;
							page.data = JSON.stringify({type: 'classify', nowPage: pageData.nowPage, savedir: pageData.savedir, title: pageData.title});
							addArticles(articlesFilter, pagesFilter, pageNumberFilter, page);
						}
						
						if(result.success&&finish){
							chrome.task.finishPage();
						}
					}
				);
			}
		}
		else
			addArticles(articlesFilter, pagesFilter, pageNumberFilter, page);
	});
}

chrome.task.startPage(function (page) {
	
	var pageData = page.data.length ? JSON.parse(page.data) : {};
    var option = page.option.length ? JSON.parse(page.option) : {};
	var articleList = "博文列表.csv";
	var articlesFilter = '.bcase.ztag .nbw-bitm.clearfix.bdwb.bds2.bdc0 .btag.title.thide a.fc03.m2a';
	var pagesFilter = '.clearfix.ztag span.pgi.pgb.iblock.fc03.bgc9.bdc0';
	var pageNumberFilter = '.clearfix.ztag span.pgi.zpg1.iblock.fc03.bgc9.bdc0.js-zslt-987.fc05';
	
	if(page.first){
		chrome.task.fopen({path: articleList, mode: "ab", header: "博文标题, 链接, 保存位置\n"});
	}
	
	//添加博客栏目
	if(page.first){
		var allTitle = $('.nb-are.nb-nav .noul.clearfix a');
		allTitle.each(function(index, item){
			chrome.task.addPage({
				url: item.href,
				savedir: page.savedir + item.text,
				savename: item.text,
				priority: 'high',
				data: JSON.stringify({type: 'title', site: item.text})
			});
		});
		
		chrome.task.finishPage({savedir: '首页'});
		return;
	}
	
	if(pageData.type == 'title'){
		//只处理日志目录
		if(pageData.site == '日志'){
			if(option.way == 'normal'){
				page.data = JSON.stringify({type: 'normal', maxNum: option.max, nowNum: 0, nowPage: 1, savedir: '博文'});
				page.loadTimes = 0;
				addArticles(articlesFilter, pagesFilter, pageNumberFilter, page);
			}
			
			if(option.way == 'classify'){
				var pageList = $('.itm2.fc04 a', $('.left.bdwr.bds0.bdc0.noul ul')[0]);
				var pageNum = 1;
				var filter = decodeURI(option.classify);
				pageList.each(function(index, item){
					if(pageNum == 1){
						pageNum++;
						return;
					}
					if(filter.indexOf(item.title, 0)!=-1){
						chrome.task.addPage({
							url: item.href,
							savedir: '博文/' + item.text,
							savename: item.text,
							force: true,
							data: JSON.stringify({type: 'articleList', title: item.text})
						});
					}
				});
				
				chrome.task.finishPage();
			}
			
			if(option.way == 'label'){
				var pageList = $('.itm2.fc04 a', $('.left.bdwr.bds0.bdc0.noul ul')[1]);
				var filter = decodeURI(option.lable);
				pageList.each(function(index, item){
					if(filter.indexOf(item.title, 0)!=-1){
						chrome.task.addPage({
							url: item.href,
							savedir: '博文/' + item.text,
							savename: item.text,
							force: true,
							data: JSON.stringify({type: 'articleList', title: item.text})
						});
					}
				});
				
				chrome.task.finishPage();
			}
			
			if(option.way == 'date'){
				var yearList = $('>li', $('.left.bdwr.bds0.bdc0.noul ul')[2]);
				var date = option.end;
				var year_end = parseInt(date.split('-')[0]);
				var month_end = parseInt(date.split('-')[1]);
				var finish = false;
				
				yearList.each(function(index, item){
					var year = $('.pleft', $(item))[0].innerText;
					var monthList = $('.itm2 a', $(item));
					monthList.each(function(index, item){
						var month = item.innerText;
						finish = false;
						if(parseInt(year.slice(1, -1))<year_end)
							finish = true;
						if(parseInt(year.slice(1, -1))==year_end && parseInt(month)<month_end)
							finish = true;
						if(!finish){
							chrome.task.addPage({
								url: item.href,
								savedir: '博文/' + year + '/' + month,
								savename: item.text,
								force: true,
								data: JSON.stringify({type: 'articleList', title: item.text})
							});
						}
					})
				});
				
				chrome.task.finishPage();
			}
		}
		else
			chrome.task.finishPage();
	}
	
	if(pageData.type == 'articleList'){
		page.data = JSON.stringify({type: 'classify', nowPage: 1, savedir: page.savedir, title: pageData.title});
		page.loadTimes = 0;
		addArticles(articlesFilter, pagesFilter, pageNumberFilter, page);
	}
	
	if(pageData.type == 'articles'){
		chrome.task.fwrite({path: articleList, text: pageData.title.replace(',', '，') + ', ' + pageData.href + ', ' + page.savedir + '\n'});
		chrome.task.finishPage();
	}
});