﻿jQuery('document').ready(function() {
    waitForAjax('#menu-账户话单查询, #startTime', '', function(good) {
        if (!good) {
            failAndClose('打开首页超时！');
            return;
        }
        chrome.task.startPage(function(page) {
            //chrome.task.output({text: 'page data: '+data});
            var pageData = page.data.length ? JSON.parse(page.data) : {};

            //Weibo Template options:
            output('page: ' + page.option + '  ' + page.data, 0);

            var options = page.option.length ? JSON.parse(page.option) : {};
            var saveDirRules = {
                pictures: "[截图]"
            };
            var recordCsv = "话单记录.csv";
            var pageLimited = options.postLimit ? parseInt(options.limitedPages, 10) : -1;
            if (pageLimited === 0) {
                output('页面限制数为0，任务结束！');
                chrome.task.finishPage({
                    discard: true
                });
            }

            if (page.first || pageData.type === undefined) { //首页
                output('首页...');

                var el = jQuery('#menu-账户话单查询');
                if (!el.length) {
                    failAndClose('找不到话单查询节点！');
                    return;
                }

                chrome.task.addPage({
                    url: el[0].href,
                    data: JSON.stringify({
                        type: 'query-cus-cdr'
                    })
                });
                chrome.task.finishPage({
                    discard: true
                });
            } else if (pageData.type === 'query-cus-cdr') {
                //过滤条件
                var dateEl = jQuery('input#startTime');
                var callerEl = jQuery('input#callerE164');
                var calleeEl = jQuery('input#calleeE164');
                var filterBtn = jQuery('button#ext-gen81');
                if (!dateEl.length || !callerEl.length || !calleeEl.length || !filterBtn.length) {
                    failAndClose('找不到过滤输入表单！');
                    return;
                }

                dateEl[0].value = decodeURIComponent(options.date);
                callerEl[0].value = options.caller;
                calleeEl[0].value = options.callee;

                var recordsCount = 0,
                    pageCount = 0,
                    totalPages = 0,
                    totalRecords = 0;

                var writtenHeader = false;

                //点击过滤
                filterBtn.click();
                //递归调用，模拟点击翻页
                (function processRecordsPage(compareText) {
                    waitForTextChange(compareText, '.x-grid3-row-first', '', function(good) {
                        //snapshot
                        //chrome.task.snapshot();
                        if (!good) {
                            failAndClose('查询话单时超时！');
                            return;
                        }
                        var records = jQuery('.x-grid3-row');
                        recordsCount += records.length;
                        pageCount += 1;
                        if (!totalRecords || !totalPages) {
                            var a = getNumbers(jQuery('#ext-comp-1016')),
                                b = getNumbers(jQuery('#ext-comp-1020'), /共\s*(\d+)/);
                            totalPages = a.length ? a[0] : 0;
                            totalRecords = b.length > 1 ? b[1] : 0;



                            if (!totalRecords || !totalPages) {
                                failAndClose('话单记录总数为0！');
                                return;
                            }
                            output('话单记录， 共 ' + totalPages + ' 页，共 ' + totalRecords + ' 条记录');
                        }
                        output('话单记录第 ' + pageCount + ' 页...');
                        output('本页记录数：' + records.length);

                        if (!writtenHeader) {
                            //还没有打开csv记录通话单的文件

                            var headers = jQuery('td', 'tr.x-grid3-hd-row');
                            var headerStr = '';
                            if (!headers.length) {
                                failAndClose('获取话单记录的表头错误！');
                                return false;
                            }
                            headers.each(function(index, el) {
                                headerStr += el.innerText + ',';
                            });
                            headerStr = headerStr.replace(/,?$/, '\n');

                            chrome.task.fopen({
                                path: recordCsv,
                                mode: 'ab',
                                header: headerStr
                            });
                            writtenHeader = true;
                        }

                        records.each(function(index, el) {
                            var collumns = jQuery('table td', el);
                            var recordStr = '';
                            if (!collumns.length) {
                                failAndClose('获取话单记录的各列出错！');
                                return false;
                            }
                            collumns.each(function(index2, el2) {
                                recordStr += el2.innerText.trim() + ',';
                            });
                            recordStr = recordStr.replace(/,?$/, '\n');
                            // output('recordStr:' + recordStr, 0);
                            chrome.task.fwrite({
                                path: recordCsv,
                                text: recordStr
                            });
                        });

                        var ct = jQuery('.x-grid3-row-first').text();
                        // output('first row: '+ct, 0);

                        chrome.task.snapshot({
                            savedir: saveDirRules.pictures,
                            savename: '话单_第' + pageCount + '页'
                        }, function(detail) {
                            if (pageCount < totalPages) {
                                if (pageLimited >= 0 && pageCount >= pageLimited) {
                                    output('达到页面限制！');
                                    chrome.task.finishPage({
                                        discard: true
                                    });
                                    return;
                                }
                                var nextBtn = jQuery('button.x-tbar-page-next');
                                if (!nextBtn.length) {
                                    failAndClose('翻页按钮没找到！');
                                    return false;
                                }
                                nextBtn.click();
                                processRecordsPage(ct);
                            } else {
                                output('通话单处理完毕！');
                                chrome.task.finishPage({
                                    discard: true
                                });
                            }
                        });
                    });
                }(''));
            }
        });
    });
});