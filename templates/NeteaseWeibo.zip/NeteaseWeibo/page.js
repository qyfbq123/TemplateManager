﻿jQuery(document).ready(function() {
    chrome.task.startPage(function(page) {
        var pageData = page.data.length ? JSON.parse(page.data) : {};
        var options = page.option.length ? JSON.parse(page.option) : {};
        var curLocation = location.href;
        output('pageOptions: ' + page.option + '; pageData: ' + page.data, 0);
        var limitedPages = -1, //-1 代表不限制
            limitedNumber = -1,
            filterDate = '';

        if (options.postLimit === 'limitedPages') {
            limitedPages = options.limitedPages;
        } else if (options.postLimit === 'limitedNumber') {
            limitedNumber = options.limitedNumber;
        } else if (options.postLimit === 'limitedDate') {
            filterDate = 'within' + options.limitedDate;
        }

        var saveDirRules = {
            weibo: "[微博]",
            report: "[任务报告]"
        };

        //disable fixed header bar
        jQuery('#headNav').css('position', 'absolute');

        var weiboCsv = saveDirRules.report + "/微博列表.csv";
        var watcherType = '关注',
            followerType = '粉丝';
        var watcherCsv = saveDirRules.report + '/关注列表.csv',
            followerCsv = saveDirRules.report + '/粉丝列表.csv';

        //翻页时延时
        var min_delay = 1000,
            max_delay = 3000;

        if (page.first || !pageData.type) { //首页
            output('weiboCsv: ' + weiboCsv, 0);
            chrome.task.fopen({
                path: weiboCsv,
                mode: 'ab',
                header: '发表时间,内容,转发数,评论数,单独链接\n'
            });

            var pageIndex = 0,
                weiboIndex = 0,
                totalPageNumber = 0;

            var finishLastPage = function() {
                output('微博页最后一页处理完毕!');
                chrome.task.snapshot({
                    savedir: saveDirRules.weibo,
                    savename: '微博_第' + pageIndex + '页'
                }, function(detail) {
                    chrome.task.finishPage({
                        discard: true
                    });
                });
            };
            var parseWeiboDetail = function(node) {
                var contentNode = jQuery('p.tweet-message', node).first(),
                    forwardNode = jQuery('a.retweet-trigger', node).last(),
                    replyNode = jQuery('a.reply-trigger', node).last(),
                    linkNode = jQuery('a.tweet-time', node).first(),
                    timeNode = jQuery('a.tweet-time .tweet-info-time', node).first();

                if (!contentNode.length || !forwardNode.length || !replyNode.length || !linkNode.length || !timeNode.length) {
                    output('解析第' + pageIndex + '页第' + weiboIndex + '条微博时出错！', 4);
                    return true;
                }
                var content = contentNode.text().replace(/[,\r\n\/\\]/g, ' '),
                    forwardNumber = getNumber(forwardNode.text()),
                    replyNumber = getNumber(replyNode.text()),
                    link = linkNode[0].href,
                    time = parseDateTime(timeNode.text());

                if (filterDate) {
                    if (!window[filterDate](timeNode.text())) {
                        output('已达到日期限制！');
                        return false;
                    }
                }
                output('微博: ' + time + ' 转发数:' + forwardNumber + ' 回复数:' + replyNumber, 0);
                chrome.task.fwrite({
                    path: weiboCsv,
                    text: time + ',' + content + ',' + forwardNumber + ',' + replyNumber + ',' + link + '\n'
                });
                if (options.dWeibo) {
                    chrome.task.addPage({
                        url: link,
                        savedir: saveDirRules.weibo + '/第' + pageIndex + '页',
                        savename: '微博_第' + weiboIndex + '条',
                        data: JSON.stringify({
                            type: 'weibo',
                            text: time.toString()
                        })
                    });
                }
                return true;
            };
            var parseWeiboOnPage = function(onFinish) {
                output('parseWeiboOnPage...', 0);
                var nodeList = jQuery('#tweetList div.tweet');
                if (!nodeList.length) {
                    output('未发现微博！', 3);
                    onFinish(false);
                    return;
                }
                output('本页发现有 ' + nodeList.length + ' 条微博！');
                var bContinue = true;
                nodeList.each(function(index, el) {
                    weiboIndex += 1;
                    bContinue = parseWeiboDetail(el);
                    if (limitedNumber > 0 && weiboIndex >= limitedNumber) {
                        output('限制为仅固定 ' + limitedNumber + ' 条微博，已达到限制条件！');
                        bContinue = false;
                    }
                    if (!bContinue)
                        return false;
                });

                onFinish(bContinue);
            };
            var processPage = function(compareText) {
                //如果首页是滚动方式， 是没有#pageNav节点的。
                pageIndex += 1;
                output('微博页第 ' + pageIndex + ' 页...');
                waitForTextChange(compareText, '.mainBox-ft a.more', '', function(success) {
                    //查找粉丝页和关注页
                    if (pageIndex === 1) {
                        if (options.dWatcher) {
                            var wnode = jQuery('a#followingCount');
                            if (!wnode.length) {
                                output('获取关注页面链接错误', 4);
                            }
                            output('获取到关注页面链接', 0);
                            chrome.task.addPage({
                                url: wnode[0].href,
                                data: JSON.stringify({
                                    type: 'watcher'
                                })
                            });
                        }
                        if (options.dFollower) {
                            var fnode = jQuery('a#followerCount');
                            if (!fnode.length) {
                                output('获取粉丝页面链接错误', 4);
                            }
                            output('获取到粉丝页面链接', 0);
                            chrome.task.addPage({
                                url: fnode[0].href,
                                data: JSON.stringify({
                                    type: 'follower'
                                })
                            });
                        }
                    }

                    if (!success) {
                        //处理只有一页的情况
                        if (pageIndex === 1) {
                            var node = jQuery('.mainBox-ft');
                            var node2 = jQuery('.mainBox-ft a.more');
                            if (node.length && !node2.length) {
                                totalPageNumber = 1;
                                output('微博页仅有一页！');
                                parseWeiboOnPage(finishLastPage);
                                return;
                            }
                        }
                        failAndRetry(curLocation, "打开微博第" + pageIndex + "页超时!", pageData);
                        return;
                    }
                    var curPageNode = jQuery('.mainBox-ft a.more').first();
                    var nextBtn = jQuery('.mainBox-ft a.next').first();
                    if (!curPageNode.length || !nextBtn.length) {
                        failAndRetry(curLocation, "微博第" + pageIndex + "页查找翻页节点失败!", pageData);
                        return;
                    }
                    if (pageIndex !== getNumber(curPageNode.text())) {
                        failAndRetry(curLocation, "打开微博第" + pageIndex + "页时，页码不对!", pageData);
                        return;
                    }
                    if (pageIndex === 1) {
                        var pageList = jQuery('.mainBox-ft ul.js-pageBtnList li');
                        totalPageNumber = pageList.length;
                        output('总共发现有 ' + totalPageNumber + ' 页微博！');
                    }

                    parseWeiboOnPage(function(bContinue) {
                        if (limitedPages > 0 && pageIndex >= limitedPages) {
                            output('限制为仅固定' + limitedPages + '页微博， 已达到限制条件！');
                            bContinue = false;
                        }
                        if (!nextBtn.is(':visible') || !bContinue) {
                            finishLastPage();
                            return;
                        }

                        chrome.task.snapshot({
                            savedir: saveDirRules.weibo,
                            savename: '微博_第' + pageIndex + '页'
                        }, function(detail) {
                            var ctext = curPageNode.text();
                            nextBtn[0].click();
                            var t = Math.floor(Math.random() * max_delay + min_delay);
                            delayedExecute(t, function() {
                                processPage(ctext);
                            });
                        });
                    });
                });
            };

            processPage('');
        } else if (pageData.type === 'weibo') {
            output('微博详情页: ' + pageData.text);
            chrome.task.finishPage();
        } else if (pageData.type === 'watcher' || pageData.type === 'follower') {
            var csvPath = watcherCsv,
                pageType = '关注';
            if (pageData.type === 'follower') {
                csvPath = followerCsv;
                pageType = '粉丝';
            }
            var WFPageIndex = 0;

            var finishLastWFPage = function() {
                output(pageType + '页最后一页处理完毕!');
                chrome.task.snapshot({
                    savedir: '[' + pageType + ']',
                    savename: pageType + '页_第' + WFPageIndex + '页'
                }, function(detail) {
                    chrome.task.finishPage({
                        discard: true
                    });
                });
            };
            var parseWFDetail = function(node) {
                var infoNode = jQuery('.user-name a.link-la', node).first(),
                    tagNode = jQuery('.user-name a.iTag', node).first();

                if (!infoNode.length) {
                    output('获取用户信息时出错', 4);
                }
                var name = infoNode.text().replace(/[,\r\n\/\\]/g, ' '),
                    link = infoNode[0].href,
                    tag = tagNode.length ? tagNode.attr('data-tags').replace(/[,\r\n\/\\]/g, ' ') : '';

                var infoText = '用户名: ' + name + '；用户标签: ' + tag;
                output(infoText, 0);

                chrome.task.fwrite({
                    path: csvPath,
                    text: name + ',' + tag + ',' + link + '\n'
                });
            };
            var parseWFOnPage = function() {
                var nodeList = jQuery('#userList div.user');
                if (!nodeList.length) {
                    output('未发现用户！', 3);
                    return;
                }
                output('本页发现有 ' + nodeList.length + ' 个用户！');
                nodeList.each(function(index, el) {
                    parseWFDetail(el);
                });
            };
            var processWFPage = function(compareText) {
                WFPageIndex += 1;
                output(pageType + '页第 ' + WFPageIndex + ' 页...');
                waitForTextChange(compareText, '.mainBox-ft .js-btn.current', '', function(success) {
                    if (WFPageIndex === 1) {
                        output('csvPath: ' + csvPath, 0);
                        chrome.task.fopen({
                            path: csvPath,
                            mode: 'ab',
                            header: '用户名,用户标签,链接\n'
                        });
                    }
                    if (!success) {
                        //处理只有一页的情况
                        if (WFPageIndex === 1) {
                            var node = jQuery('.mainBox-ft');
                            var node2 = jQuery('.mainBox-ft .js-btn');
                            if (node.length && !node2.length) {
                                output(pageType + '页仅有一页！');
                                parseWFOnPage();
                                finishLastWFPage();
                                return;
                            }
                        }
                        failAndRetry(curLocation, "打开" + pageType + "第" + WFPageIndex + "页超时!", pageData);
                        return;
                    }
                    var curPageNode = jQuery('.mainBox-ft .js-btn.current').first();
                    var nextBtn = jQuery('.mainBox-ft .js-next a').first();
                    if (!curPageNode.length || !nextBtn.length) {
                        failAndRetry(curLocation, pageType + "第" + WFPageIndex + "页查找翻页节点失败!", pageData);
                        return;
                    }
                    if (WFPageIndex !== getNumber(curPageNode.text())) {
                        failAndRetry(curLocation, "打开" + pageType + "第" + WFPageIndex + "页时，页码不对!", pageData);
                        return;
                    }
                    if (WFPageIndex === 1) {
                        var pageList = jQuery('.mainBox-ft li.js-btn');
                        var totalPageNumber = pageList.length - 1;
                        output('总共发现有 ' + totalPageNumber + ' 页' + pageType);
                    }

                    parseWFOnPage();

                    if (!nextBtn.is(':visible')) {
                        finishLastWFPage();
                        return;
                    }
                    chrome.task.snapshot({
                        savedir: '[' + pageType + ']',
                        savename: pageType + '页_第' + WFPageIndex + '页'
                    }, function(detail) {
                        var ctext = curPageNode.text();
                        nextBtn[0].click();
                        var t = Math.floor(Math.random() * max_delay + min_delay);
                        delayedExecute(t, function() {
                            processWFPage(ctext);
                        });
                    });

                });
            };

            processWFPage('');
        }
    });
});