﻿var downup = function(el) {
    var event0 = document.createEvent('MouseEvents'), event1 = document.createEvent('MouseEvents');
    event0.initMouseEvent('mousedown', true, true);
    event1.initMouseEvent('mouseup', true, true);
    el.dispatchEvent(event0);
    el.dispatchEvent(event1);
};
var downBlock = function(option, blockName, cb) {
    var pageIndex = 1;
    var nextPage = function(callback) {

        elementMouseEvent(jQuery('.T-I.J-J5-Ji.lS.T-I-ax7.ar7:visible')[0], 'Click');
        waitForAjax( '.T-I.J-J5-Ji.amD.T-I-awG.T-I-ax7.T-I-Js-Gs.L3:visible', '', function(flag){

            if(flag === false) {
                output(blockName + ' 第' + pageIndex + '页翻页时找不到翻页按钮！', 4);
                return callback(false);
            }

            var _$nextPage = jQuery('.T-I.J-J5-Ji.amD.T-I-awG.T-I-ax7.T-I-Js-Gs.L3:visible');
            if( _$nextPage.parent().attr('aria-disabled') != 'true' ) {

                pageIndex ++;
                if( option.mode == 'r_total' ) {
                    var total = option.total;
                    if( !isNaN(total) ) {
                        if(Number(total) < pageIndex) return callback(false);
                    }
                }
                var originId = jQuery('.Cp .zA:last').attr('id');
                elementMouseEvent(_$nextPage[0], 'Click');
                waitForChange(originId, '.Cp .zA:last', '', 'id', function(flag0){
                    if(flag0 === 'false') output(blockName + ' 第' + pageIndex + '页翻页错误！', 4);
                    callback(flag0);
                });
            }
        } );
    };
    ( function _recordBlock(flag) {
        if(flag === false) {
            return cb();
        }
        var savedirRoot = '[' + blockName + ']', pagename = '第' + pageIndex + '页';
        chrome.task.snapshot({savename: pagename, savedir: savedirRoot}, function(){
            var endElem = null;
            if(option.mode == 'r_period' && option.period != 'all') {
                var period = option.period;
                var _func = window['within' + period.substring(0,1).toUpperCase() + period.substring(1)];
                endElem = function(elem) {
                    return _func.call('', jQuery('td:last span', elem).attr('title'));
                };
            }

            var _$emails = jQuery('.Cp .zA:visible');
            var emailsLen = _$emails.length;
            var recordIndex = 0;
            (function _recordEmail(){
                var elem = _$emails[recordIndex++];
                if(!elem) {
                    return nextPage(_recordBlock);
                }
                if(endElem && !endElem(elem)) {
                    return cb();
                }
                var originId1 = jQuery('.G3.G2>div>div').attr('id') || '';
                jQuery(elem).click();
                waitForChange(originId1, '.G3.G2>div>div', '', 'id', function(flag){
                    if(flag) {
                        chrome.task.snapshot({savedir: savedirRoot + '/' + pagename}, _recordEmail);
                        chrome.task.fwrite({
                            path: '[任务报告]/邮件列表.csv',
                            text: blockName + ',' + jQuery('span.hP').text() + ',' + jQuery('span.gD').text() + ',' + jQuery('span.gD').attr('email') + ',' + jQuery('span.g2').text() + ',' + jQuery('span.g2').attr('email') + ',' + jQuery('span.g3').attr('title') + '\n' //'版块' + ',' + '邮件标题' + ',' + '发送人' + ',' + '发送人邮件地址' + ',' + '收件人' + ',' + '收件人邮件地址' + ',' + '日期'
                        });
                    }
                    else {
                        output(blockName + ' 第' + recordIndex + '封邮件出错！', 4);
                        _recordEmail();
                    }
                });

            }());
        });
        
    })();
};

jQuery('document').ready(function(){
    chrome.task.startPage(function (page) {
        var pageData = page.data.length ? JSON.parse(page.data) : {};
        var option = page.option.length ? JSON.parse(page.option) : {};

        chrome.task.fopen({
            path: '[任务报告]/邮件列表.csv',
            mode: 'ab',
            header: '版块' + ',' + '邮件标题' + ',' + '发送人' + ',' + '发送人邮件地址' + ',' + '收件人' + ',' + '收件人邮件地址' + ',' + '日期' + '\n'
        });

        if (page.first || pageData.type === undefined) { //首页
            jQuery('.TH.aii.J-J5-Ji').click();
            setTimeout(function(){
                var allBlocks = jQuery('span.nU>a');
                if(option.filter) {
                    var reg = new RegExp( decodeURIComponent(option.filter).split(/\r?\n/).join('|') );
                    allBlocks = allBlocks.filter(function(index, elem) {
                        return reg.test( jQuery(elem).text() );
                    });
                }

                var blocksLen = allBlocks.length;
                var blockIndex = 0;
                (function downAllBlocks(flag){
                    var block = allBlocks[blockIndex];
                    if( flag === false ) {
                        output( jQuery(block).text() + ' 版块切换错误！', 4);
                    }
                    if( block && !jQuery(block).closest('.aim').hasClass('ain') ) {
                        var originId = jQuery('.Cp .zA:visible:first').attr('id') || '';

                        block.click();

                        waitForChange(originId, '.Cp .zA:visible:first', '', 'id', downAllBlocks);
                        return;
                    }
                    blockIndex++;
                    if( blockIndex > blocksLen ) {
                        chrome.task.fclose({path: '[任务报告]/邮件列表.csv'});
                        chrome.task.finishPage({discard: true});
                        return;
                    }
                    var blockName = jQuery(block).text().replace(/\s*\(.*\)/, '');
                    downBlock(option, blockName, downAllBlocks);
                }());
            }, 1000);
        }
    });
});