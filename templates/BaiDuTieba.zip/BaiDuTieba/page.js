﻿chrome.task.startPage(function (page) {
	
	var option = page.option.length ? JSON.parse(page.option) : {};
	var filter_type = option.filter_type;
	
	//去除过长页面帖子滚动时浮动的横幅
	window.onscroll = function() {
		$('.core_title_wrap').removeClass('tbui_follow_fixed core_title_absolute');
	};
	//去除帖子列表中浮动的搜索横幅
	window.onscroll = function() {
		$('.search_main.clearfix').removeClass('search_main_fixed');
	};

	//按用户下载
	if (filter_type == 'user') {
		ProgressByUser(page);
	}
	//按贴吧下载
	else if (filter_type == 'tieba') {
		ProgressByBoard(page);
	}

});