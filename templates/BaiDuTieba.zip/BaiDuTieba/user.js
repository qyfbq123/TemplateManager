
function ProgressByUser(page) {
	var pageData = page.data.length ? JSON.parse(page.data) : {};
    var option = page.option.length ? JSON.parse(page.option) : {};
   
	var totalTopicCsv = "帖子列表.csv";
	var topicCsvHeader = "所属贴吧，帖子名称，帖子地址，发帖人，发帖人主页，发帖时间\n";

	//如果百度出现警告窗口点击一下跳转
	if (pageData.type == 'page' && $('#warning').length) {
		$('#warning_url')[0].click();
	}

    if (page.first) {
		var filter_type = option.filter_type;
		var	userList = decodeURI(decodeURI(option.filter_content)).split('\n');
		
		for (i in userList) {
			//按用户下载
			var start_url = 'http://tieba.baidu.com/f/search/ures?ie=utf-8&un=' + userList[i];

			chrome.task.fopen({path: totalTopicCsv, mode: 'a', header: topicCsvHeader});

			chrome.task.addPage({
				url : start_url,
				priority : 'high',
				savename : '第1页',
				savedir:userList[i].replace(/(^\s*)|(\s*$)/g, "") + '/帖子列表',
				data: JSON.stringify({type: 'list', num: 1, path : userList[i].replace(/(^\s*)|(\s*$)/g, ""), maxPage : option.max, nowPage : 0})
			}); 			
		}

		chrome.task.finishPage();
	} 
	else {
		//贴吧列表
		var topics = [];
		var nextpage;
	
		topics = getTopicsByUser();
		nextpage = getNextPageOfUser();

		if (nextpage.length) {
			var maxPage = Number(pageData.maxPage);
			var nowPage = Number(pageData.nowPage);
	
			if(nowPage < maxPage || maxPage == 0) {
				//帖子列表页
           		chrome.task.addPage({
					url : nextpage, 
					savedir : page.savedir,
					savename : '第' + (Number(pageData.num) + 1) + '页',
					output : '第' + pageData.num + '页',
					priority : 'high',
					data : JSON.stringify({type: 'list', num : pageData.num + 1, path : pageData.path, maxPage : option.max, nowPage : nowPage + 1})
				});
       		}
		}

		//遍历添加每个帖子
		for (i in topics) {
			var topic = topics[i];

           	chrome.task.addPage({
				url: topic.url, 
				savedir: pageData.path + '/第' + pageData.num + '页',
				output: '第' + (Number(i) + 1) + '篇:' + topic.name,
				data : JSON.stringify({type: 'page'})
			});

      		var contet = getUserCsvText(topic);
			chrome.task.fwrite({path: totalTopicCsv, text: contet});
		}

		chrome.task.finishPage();
	}
}

//按用户下载
function getTopicsByUser() {
	var topics = [];
	var count = 0;

	$('.s_post_list .s_post').each(function(index, elem){						//遍历每个板块
			var topic = newTiebaInfo();
			topic.board = getElementTextSafe(elem, 'a', 1);							//所属贴吧
			topic.name = getElementTextSafe(elem, 'span.p_title a', 0);				//帖子名称
			topic.url = getElementHrefSafe(elem, 'span.p_title a', 0);				//帖子地址
			topic.author = getElementTextSafe(elem, 'a', 2);						//帖子作者
			topic.authorHome = getElementHrefSafe(elem, 'a', 2);					//作者主页
			topic.time = getElementTextSafe(elem, '.p_green', 0);					//发帖时间

			topics[count++] = topic;
		});

	return topics;
}

//下一页
function getNextPageOfUser() {
	return getElementHrefSafe('', '.next', 0);
}

//返回用户csv格式text
function getUserCsvText(topic) {
	return 	topic.board + ',' +
			topic.name + ',' +
			topic.url + ',' +
			topic.author + ',' +
			topic.authorHome + ',' +
			topic.time + '\n';
}