function newTiebaInfo() {
	var topic = {};

	topic.board = '';		//所属贴吧
	topic.name = '';		//帖子名称
	topic.url = '';			//帖子地址
	topic.author = '';		//发帖人
	topic.authorHome = '';//发帖人主页面
	topic.time = '';		//发帖时间

	return topic;
}