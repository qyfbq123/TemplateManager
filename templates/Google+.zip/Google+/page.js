﻿jQuery('document').ready(function() {
    chrome.task.startPage(function(page) {
        //chrome.task.output({text: 'page data: '+data});
        var pageData = page.data.length ? JSON.parse(page.data) : {};

        //Weibo Template options:
        //Output('page: ' + page.option + '  ' + page.data);

        var options = page.option.length ? JSON.parse(page.option) : {};
        var limitedCounts = -1, //-1 代表不限制
            limitedDate = 0,
            dAbout = true;

        //Parse options
        if (options.postLimit === 'limitedCounts') {
            limitedCounts = options.limitedCounts;
        } else if (options.postLimit === 'limitedDate') {
            if (!(/^\d{4}-\d{1,2}-\d{1,2}$/.test(options.limitedDate))) {
                Output('模板选项-日期限制输入有误！任务退出！', 4);
                chrome.task.finishPage({
                    discard: true
                });
                return;
            }
            var edf = options.limitedDate.split('-'); //end date fragments
            Output(edf.toString());
            limitedDate = new Date(Number(edf[0]), Number(edf[1]) - 1, Number(edf[2])).getTime();
        }

        dAbout = options.dAbout === 'yes';

        var saveDirRules = {
            articles: "[文章]",
            watcher: "[关注]",
            follower: "[粉丝]",
            about: "[个人信息]",
            other: "[其它]",
            report: "[任务报告]"
        };
        var articlesCsv = saveDirRules.report + "/文章列表.csv";

        if (page.first || pageData.type === undefined) { //首页
            chrome.task.fopen({
                path: articlesCsv,
                mode: 'ab',
                header: '用户名,发表时间,+1,转发数,评论数,链接\n'
            });
            Output('首页...');
            var articleIndex = 0,
                curArticleNode = 0;

            var processArticle = function(lastArticleNode) {
                if (!lastArticleNode || lastArticleNode.length === 0) {
                    curArticleNode = jQuery('div[id^="update-"]:visible').first();
                } else {
                    curArticleNode = jQuery(lastArticleNode).next();
                }
                if (curArticleNode.length !== 0) {
                    articleIndex += 1;

                    var userName = jQuery('a.Hf', curArticleNode).first().text(),
                        date = jQuery('a.Rg', curArticleNode).first().attr('title'),
                        link = jQuery('a.Rg', curArticleNode)[0].href,
                        zan = jQuery('span.H3', curArticleNode).first().text(),
                        forward = jQuery('span.jI', curArticleNode).first().text(),
                        comment = jQuery('span.Rs', curArticleNode).first().text();

                    date = date ? date.replace(/[,\r\n]/g, '') : '';
                    //var jsDate = Date.parse(date);

                    if (limitedCounts >= 0 && articleIndex > limitedCounts) {
                        Output('达到文章限制数: ' + limitedCounts);
                        curArticleNode = lastArticleNode;
                        return false;
                    }

                    //不能分析日期， 因为google+获得日期可能是中文表示的。
                    // if (jsDate < limitedDate) {
                    //     Output('达到限制日期: ' + options.limitedDate + ':' + new Date(jsDate));
                    //     curArticleNode = lastArticleNode;
                    //     return false;
                    // }

                    //Output(articleIndex + "st tweet!!!");

                    chrome.task.addPage({
                        url: link,
                        savedir: saveDirRules.articles,
                        savename: 'Article_' + articleIndex,
                        data: JSON.stringify({
                            type: 'article'
                        })
                    });

                    chrome.task.fwrite({
                        path: articlesCsv,
                        text: userName + ',' + date + ',' + zan + ',' + forward + ',' + comment + ',' + link + '\n'
                    });

                    return processArticle(curArticleNode);
                } else {
                    curArticleNode = lastArticleNode;
                    return true;
                }

            };

            //添加about页面。
            var indexPage = document.location.href;
            var regExp = /(.*plus.google.com.*?)\/posts/;
            var match = regExp.exec(indexPage);
            if (!match || match.length < 2) {
                Output('首页地址可能错误，获取about页面失败!', 4);
                chrome.task.finishPage({
                    discard: true
                });
                return;
            }
            var aboutUrl = match[1] + '/about';
            if (dAbout) {
                chrome.task.addPage({
                    url: aboutUrl,
                    savedir: saveDirRules.about,
                    savename: 'about',
                    data: JSON.stringify({
                        type: 'about'
                    })
                });
            }

            waitForAjax('div[id^="update-"].Tg', '', function() {
                scrollDown(
                    function(count) {
                        Output('首页， 第' + count + '屏...');
                        return processArticle(curArticleNode);
                    },
                    function() {
                        Output('首页处理完毕');
                        chrome.task.finishPage({
                            discard: true
                        });
                    });
            });

        } else if (pageData.type === 'article') {
            waitForAjax('a.g-M-n', '', function() {
                chrome.task.output({
                    text: '文章页: ' + document.title
                });
                chrome.task.output({
                    text: 'Page finished!'
                });
                //
                // var w = document.width;
                // var h = document.height;
                // chrome.task.output({
                //     text: '调整页面高度: ' + w + ' x ' + h
                // });
                // chrome.task.setPageSize({
                //     width: w,
                //     height: h
                // });

                chrome.task.finishPage();
            });
        } else if (pageData.type === 'about') {
            chrome.task.output({
                text: '关于页: ' + document.title
            });
            chrome.task.output({
                text: 'Page finished!'
            });
            chrome.task.finishPage();
        } else {
            chrome.task.output({
                text: '其它页: ' + document.title
            });
            chrome.task.output({
                text: 'Page finished!'
            });
            chrome.task.finishPage();
        }
    });
});