function QQMail(options, pageData) {
    var self = this;
    //保存当前页面的url
    self._curUrl = location.href;

    self._saveDirRules = {
        mails: '[邮件]',
        report: '[任务报告]'
    };
    self._options = options;
    self._pageData = pageData;
    //qq邮箱不能请求频率太快
    self._min_delay = 1000;
    self._max_delay = 4000;

    //邮件统计csv
    self._csv_path = self._saveDirRules.mails + '/' + '汇总普通邮件列表.csv';
    self._csv_group_path = self._saveDirRules.mails + '/' + '汇总群邮件列表.csv';

    self._mails_in_dir = 0;
    self._pages_in_dir = 0;
    self._mailList = [];

    //当前打开的邮件 detail page
    self._detail_index = 0;

    //当前邮件的主题
    self._subject = '';

    self._mainFrame = [];
    self._$mainFrame = '#mainFrame';
    self._$mailList = '.i.F, .i.M';

    //TODO: 下载附件应该过滤超大附件
    self.downloadAttachment = function() {
        output('[temp]downloadAttachment...', 0);
        var that = self;
        var itemNode = jQuery('div.attachitem', self._mainFrame);
        if (itemNode.length) {
            output('发现 ' + itemNode.length + ' 个附件');
            itemNode.each(function(index, el) {
                //检查是否是超大附件
                var ico_a = jQuery('.ico_big a', el);
                if (ico_a.length && ico_a.attr('bigattach') === '1') {
                    output('发现是超大附件， 将不下载！');
                    return false;
                }

                var name = jQuery('span[player], .name_big span', el).first().text();
                var n = jQuery('.down_big a', el).first();
                output(name);
                if (!name || !n.length) {
                    output('获取附件信息失败！', 4);
                    return;
                }
                chrome.task.download({
                    url: n[0].href,
                    savedir: self._pageData.saveMailDir + '/附件_' + self._subject,
                    savename: name
                });
            });
        }
    };

    self.dowloadEml = function() {
        //本来使用的 action=downloademl 表示导出 eml 格式文件， 结果测试发现很多邮件下不下来
        //故改为使用 action=readmailmime， 获取邮件原文，跟 eml 文件一样。
        // var url = 'http://mail.qq.com/cgi-bin/readmail?sid=' + self._pageData.sid + '&mailid=' + self._pageData.mailid + '&action=downloademl';
        var url = 'http://mail.qq.com/cgi-bin/readmail?sid=' + self._pageData.sid + '&mailid=' + self._pageData.mailid + '&action=readmailmime';
        output('dowloadEml... url: ' + url, 0);
        chrome.task.download({
            url: url,
            savedir: self._pageData.saveMailDir,
            savename: self._subject + '.eml'
        });
    };

    self.parseGroupMail = function() {
        output('[temp]analyseGroupMail...', 0);
        self._mainFrame = jQuery(self._$mainFrame)[0].contentDocument;
        detailNode = jQuery('.readmailinfo', self._mainFrame);
        if (!detailNode.length) {
            failAndClose('解析邮件时， 获取邮件头信息失败！');
            return;
        }
        var groupNode = jQuery('.grn', detailNode);
        var subjectNode = jQuery('#subject', detailNode);
        var dateNode = jQuery('td[width="99%"] b.tcolor', detailNode);
        if (!groupNode.length || !subjectNode.length || !dateNode.length) {
            failAndClose('获取群邮件头信息失败');
            return;
        }
        var subject = subjectNode.text().replace(/[,\r\n\/\\]/g, ' ');
        self._subject = subject;
        var groupName = groupNode.text();
        var group = groupNode.attr('title').replace(/[,\r\n\/\\]/g, ' ');
        var date = dateNode.text().replace(/[,\r\n]/g, ' ');
        return self._pageData.mailDir + ',' + subject + ',' + groupName + ',' + group + ',' + date + '\n';
    };

    self.parseNormalMail = function() {
        output('[temp]analyseNormalMail...', 0);
        self._mainFrame = jQuery(self._$mainFrame)[0].contentDocument;

        var detailNode = jQuery('#detail0, .readmailinfo', self._mainFrame);
        if (!detailNode.length) {
            failAndClose('解析邮件时， 获取邮件头信息失败！');
            return;
        }
        var toAndFrom = jQuery('span[u][e][t]', detailNode);
        if (!toAndFrom.length) {
            failAndClose('解析邮件时， 获取发件人和发送人失败！');
            return;
        }
        var from = toAndFrom.first().attr('e'),
            fromName = toAndFrom.first().attr('n');

        var subject = jQuery('.black, #subject', detailNode).first().text().replace(/[,\r\n\/\\]/g, ' ');
        self._subject = subject;
        var date = jQuery('.unselect .right.graytext', self._mainFrame);
        if (!date.length) {
            //还有一种情况：
            date = jQuery('td[width="99%"] b.tcolor', detailNode);
            if (!date.length) {
                failAndClose('解析邮件时，获取日期失败！');
                return;
            }
        }
        date = date.text().replace(/[,\r\n]/g, ' ');

        //下载 eml 文件， 只有普通邮件能下载， 群邮件不能下载...
        if (self._options.dEml) {
            self.dowloadEml();
        }
        return self._pageData.mailDir + ',' + subject + ',' + fromName + ',' + from + ',' + date + '\n';
    };

    self.startMail = function() {
        output('[temp]startMail...', 0);
        var info = '';
        if (self._pageData.groupMail) {
            info = self.parseGroupMail();
            chrome.task.fwrite({
                path: self._csv_group_path,
                text: info
            });
        } else {
            info = self.parseNormalMail();
            chrome.task.fwrite({
                path: self._csv_path,
                text: info
            });
        }
        chrome.task.fwrite({
            path: self._pageData.csvInDir,
            text: info
        });

        output('邮件：' + self._subject);
        //下载附件
        if (self._options.dAttachment) {
            self.downloadAttachment();
        }
        //截图
        chrome.task.finishPage({
            savedir: self._pageData.saveMailDir,
            savename: self._subject
        });
    };

    self.backToPage = function() {
        var that = self;
        output('backToPage...', 0);
        var backBtn = jQuery('.btn_back[ck]', self._mainFrame);
        if (!backBtn.length) {
            failAndClose('查找返回按钮失败！');
            return;
        }
        //为了避免访问频率过快而延迟
        var t = Math.floor(Math.random() * self._max_delay + self._min_delay);
        delayedExecute(t, function() {
            backBtn[0].click();
            waitForAjaxInFrame(that._$mailList, that._$mainFrame, function(success) {
                if (!success) {
                    failAndRetry(self._curUrl, '返回' + self._pageData.mailDir + '第 ' + self._pageData.mailPage + ' 页超时', self._pageData);
                    return;
                }
                that._detail_index += 1;
                that.parsePage();
            });
        });
    };

    self.openMails = function(mailIDs) {
        var newPageData = jQuery.extend(true, {}, self._pageData);

        mailIDs.each(function(index, id) {
            var t = self._pageData.groupMail ? 'readmail_group' : 'readmail';
            var mailLink = location.host + '/cgi-bin/frame_html?t=newwin_frame&sid=' + self._pageData.sid + '&url=/cgi-bin/readmail?mailid=' + id + '%26t=' + t;
            newPageData = jQuery.extend(true, newPageData, {
                type: 'mail',
                mailid: id
            });
            output('add mail: ' + mailLink + '   mailid: ' + id, 0);
            chrome.task.addPage({
                url: mailLink,
                data: JSON.stringify(newPageData)
            });
        });
    };

    self.parseDetail = function() {
        output('[temp]parseDetail...', 0);

        self._mainFrame = jQuery(self._$mainFrame)[0].contentDocument;

        var onerror = function(text) {
            output(text, 4);
            self.backToPage();
        };

        var conv = jQuery('div[context][mor="setCurrent"]', self._mainFrame);
        if(!conv.length){
            output('不是对话模式邮件', 0);
            conv =  jQuery('body[context]', self._mainFrame);
        }
        
        if (!conv.length) {
            onerror('解析邮件列表时出错！');
            return;
        }
        
        var mailIDs = conv.map(function(index, elem) {
            return jQuery(elem).attr('context');
        });
        output('发现 ' + mailIDs.length + ' 封邮件！', 0);
        self.openMails(mailIDs);
        self.backToPage();
    };

    self.enterDetail = function() {
        output('[temp]enterDetail..., _detail_index:' + self._detail_index, 0);
        var that = self;
        if (self._detail_index >= self._mailList.length) {
            failAndClose('进入邮件详情时， 邮件序号错误！');
            return;
        }

        var m = self._mailList[self._detail_index];
        var c = jQuery('td.l', m);
        //这里竟然不能直接用c.click(), 怪哉！
        c[0].click();
        //contentDiv节点貌似有2种形式， 和邮件头的显示形式相对应。
        waitForAjaxInFrame('#contentDiv0, #contentDiv', that._$mainFrame, function(success) {
            if (!success) {
                failAndRetry(self._curUrl, '进入邮件详情超时', self._pageData);
                return;
            }
            that.parseDetail();
        });
    };

    self.parsePage = function() {
        self.analysePageInfo();
        var that = self;

        //最后一封邮件分析完毕后，翻页或截图
        if (self._detail_index >= self._mailList.length) {
            output(self._pageData.mailDir + '第 ' + self._pageData.mailPage + ' 页分析完毕！');
            //截图
            chrome.task.finishPage({
                savedir: self._pageData.saveMailDir,
                savename: '第 ' + self._pageData.mailPage + ' 页'
            });
        } else {
            //打开邮件
            //为了避免访问频率过快而延迟
            var t = Math.floor(Math.random() * self._max_delay + self._min_delay);
            delayedExecute(t, self.enterDetail);
        }
    };

    self.startPage = function() {
        output('分析' + self._pageData.mailDir + '第 ' + self._pageData.mailPage + ' 页...');
        self._pageData.saveMailDir = self._saveDirRules.mails + '/' + self._pageData.mailDir + '/第' + self._pageData.mailPage + '页';
        self.parsePage();
    };

    self.analysePageInfo = function() {
        self._mainFrame = jQuery(self._$mainFrame)[0].contentDocument;
        self._pageData.sid = location.href.match(/[?&]sid=([^&]*)/)[1];
        //span.f_size 是群邮件中的选择器
        self._mails_in_dir = getNumber(jQuery('#_ut_c,span.f_size', self._mainFrame));
        var temps = getNumbers(jQuery('.right', self._mainFrame)[0], /\d+\s*[页|N]/);
        self._pages_in_dir = temps.length ? temps[0] : 0;
        //.i.F 表示未读邮件， .i.M 表示已读邮件
        self._mailList = jQuery(self._$mailList, self._mainFrame);
        output('本页发现邮件 ' + self._mailList.length + ' 封', 0);
    };

    self.openNextPages = function() {
        output('[temp]openNextPages...', 0);
        var node = jQuery('#nextpage', self._mainFrame);
        if (!node.length) {
            //没有翻页
            failAndClose('翻页失败！');
            return;
        }
        var nextLink = node[0].href;
        var pageLinks = [];
        var that = self;

        var i = self._pageData.mailPage; //因为 pageNumber 是从 0 开始的。
        while (i < self._pageData.mailPage + self._pageData.maxPages) {
            if (i >= self._pages_in_dir)
                break;
            pageLinks[i - self._pageData.mailPage] = nextLink.replace(/page=\d+/, 'page=' + i);
            i = i + 1;
        }
        output('将固定 ' + pageLinks.length + ' 页！');

        var newPageData = jQuery.extend(true, {}, self._pageData);

        jQuery.each(pageLinks, function(index, link) {
            newPageData = jQuery.extend(true, newPageData, {
                type: 'page',
                mailPage: index + 1 + self._pageData.mailPage
            });
            chrome.task.addPage({
                url: link,
                data: JSON.stringify(newPageData)
            });
        });
    };

    self.startDir = function() {
        // var totalMailCount = getNumber(jQuery(node).next());
        // output(dir + ': 共 ' + totalMailCount + ' 封邮件！');
        var that = self;
        output('开始分析' + self._pageData.mailDir + '...');
        //进入文件夹时， 把首页当第0页， openNextPages后它会重新加载的
        self._pageData.mailPage = 0;
        self.analysePageInfo();

        self._pageData.csvInDir = self._saveDirRules.mails + '/' + self._pageData.mailDir + '/' + self._pageData.mailDir + '邮件列表.csv';
        var headerStr = '文件夹' + ',' + '邮件标题' + ',' + '发送人' + ',' + '发送人邮件地址' + ',' + '日期' + '\n';
        if (self._pageData.groupMail) {
            headerStr = '文件夹' + ',' + '邮件标题' + ',' + 'QQ群' + ',' + '群号' + ',' + '日期' + '\n';
        }
        output('_csv_in_dir: ' + self._pageData.csvInDir, 0);
        chrome.task.fopen({
            path: self._pageData.csvInDir,
            mode: 'ab',
            header: headerStr
        });

        var mails_unread_in_dir = getNumber(jQuery('#_ur_c', self._mainFrame));

        output('共有 ' + self._mails_in_dir + ' 封邮件， 未读邮件 ' + mails_unread_in_dir + ' 封。');
        output('共有 ' + self._pages_in_dir + ' 页。');

        self._pageData.maxPages = self._pages_in_dir;

        if (that._options.postLimit === 'limitedPages' && self._options.limitedPages >= 0) {
            self._pageData.maxPages = Math.min(self._options.limitedPages, self._pages_in_dir);
        } else if (that._options.postLimit === 'limitedDate') {
            self._pageData.maxPages = 1;
        }

        if (self._pages_in_dir <= 1) {
            //只有一页
            self._pageData.mailPage = 1;
            self.startPage();
        } else {
            self.openNextPages();
            chrome.task.finishPage({
                discard: true
            });
        }
    };

    self.openDirInNewPage = function(node, dir) {
        var el = jQuery('a', node);
        if (!el.length) {
            failAndClose('新窗口打开文件夹失败！');
            return;
        }
        var link = el[0].href;
        var group = node.getAttribute('dr');

        chrome.task.addPage({
            url: link,
            data: JSON.stringify({
                type: 'dir',
                mailDir: dir,
                groupMail: group === '8'
            })
        });
    };

    self.parseDirs = function(onFinish) {
        //展开‘其他文件夹’
        var dirs = jQuery('#SysFolderList li[id*="folder_"],  #personalfolders li[id*="folder_"]');
        var interest_dirs = [];
        //用幻数而不是汉字过滤文件夹，是为了兼容英文版的qq邮箱。
        var no_interest_dirs = ['4']; //4 is 草稿箱
        var that = self;
        var a = self._options.dInbox ? interest_dirs.splice(0, 0, '1') : no_interest_dirs.splice(0, 0, '1');
        a = self._options.dFlag ? interest_dirs.splice(0, 0, 'starred') : no_interest_dirs.splice(0, 0, 'starred');
        a = self._options.dGroup ? interest_dirs.splice(0, 0, '8') : no_interest_dirs.splice(0, 0, '8');
        a = self._options.dSent ? interest_dirs.splice(0, 0, '3') : no_interest_dirs.splice(0, 0, '3');
        a = self._options.dRemoved ? interest_dirs.splice(0, 0, '5') : no_interest_dirs.splice(0, 0, '5');
        a = self._options.dTrash ? interest_dirs.splice(0, 0, '6') : no_interest_dirs.splice(0, 0, '6');

        dirs = dirs.filter(function(index, el) {
            var attr = el.getAttribute('dr');
            if (no_interest_dirs.indexOf(attr) !== -1)
                return false;
            else if (interest_dirs.indexOf(attr) !== -1)
                return true;
            else {
                //其他文件夹下的邮件
                return that._options.dOthers;
            }
        });
        var dirNames = dirs.map(function(index, elem) {
            return elem.innerText;
        });
        output('即将固定的邮箱文件夹：' + dirNames.toArray());
        onFinish(dirs);
    };

    self.parseFirstPage = function() {
        output('进入邮箱首页...');
        var that = self;
        self.parseDirs(function(dirs) {
            if (!dirs.length) {
                failAndClose('查找邮箱文件夹时出错！');
                return;
            }
            output('csv: ' + that._csv_path, 0);
            output('csv: ' + that._csv_group_path, 0);
            var headerStr = '文件夹' + ',' + '邮件标题' + ',' + '发送人' + ',' + '发送人邮件地址' + ',' + '日期' + '\n';
            var headerStrGroup = '文件夹' + ',' + '邮件标题' + ',' + 'QQ群' + ',' + '群号' + ',' + '日期' + '\n';

            chrome.task.fopen({
                path: that._csv_path,
                mode: 'ab',
                header: headerStr
            });
            chrome.task.fopen({
                path: that._csv_group_path,
                mode: 'ab',
                header: headerStrGroup
            });

            dirs.each(function(index, el) {
                var dir = el.innerText.replace(/\r|\n/, '');
                that.openDirInNewPage(el, dir);
            });
            chrome.task.finishPage({
                discard: true
            });

        });
    };



    self.start = function() {
        var that = self;
        if (self._pageData.type === 'dir') {
            waitForAjaxInFrame('.right', that._$mainFrame, function(success) {
                if (!success) {
                    failAndRetry(self._curUrl, '打开' + self._pageData.mailDir + '失败', self._pageData);
                    return;
                }
                that.startDir();
            }, 20000);

        } else if (self._pageData.type === 'page') {
            waitForAjaxInFrame(that._$mailList, that._$mainFrame, function(success) {
                if (!success) {
                    failAndRetry(self._curUrl, '打开' + self._pageData.mailDir + '第 ' + self._pageData.mailPage + ' 页失败', self._pageData);
                    return;
                }
                that.startPage();
            }, 20000);
        } else if (self._pageData.type === 'mail') {
            waitForAjaxInFrame('#detail0, .readmailinfo', that._$mainFrame, function(success) {
                if (!success) {
                    failAndRetry(self._curUrl, '打开' + self._pageData.mailDir + '第 ' + self._pageData.mailPage + ' 页的一封邮件超时', self._pageData);
                    return;
                }
                that.startMail();
            }, 20000);
        } else {
            self.parseFirstPage();
        }
    };
}