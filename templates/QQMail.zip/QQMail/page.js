﻿jQuery('document').ready(function() {
    chrome.task.startPage(function(page) {
        var pageData = page.data.length ? JSON.parse(page.data) : {};
        var options = page.option.length ? JSON.parse(page.option) : {};
        output('page: ' + page.option + '  ' + page.data, 0);

        waitForAjax('#mainFrame', '', function(success) {
            if (success) {
                var p = new QQMail(options, pageData);
                if (page.first)
                    output('开始分析' + page.sitetype + '...');

                p.start();
            } else {
                if (page.first) {
                    if (!checkLogin())
                        return;
                }
                failAndClose('打开邮箱超时，任务失败！');
                return;
            }
        });
    });
});

function checkLogin() {
    if (/\/loginpage/.test(location.href)) {
        failAndClose('检测到您没有登陆QQ邮箱，请先登陆，登陆时需要选择记住登录状态！');
        return false;
    }
    return true;
}