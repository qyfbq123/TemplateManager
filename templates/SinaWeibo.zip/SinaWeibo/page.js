﻿jQuery(document).ready(function() {
    chrome.task.startPage(function(page) {
        //chrome.task.output({text: 'page data: '+data});
        var pageData = page.data.length ? JSON.parse(page.data) : {};
        var curLocation = location.href;
        //Weibo Template options:
        output('page: ' + page.option + '  ' + page.data, 0);
        var options = page.option.length ? JSON.parse(page.option) : {};
        var limitedPages = -1, //-1 代表不限制
            limitedNumber = -1,
            filterDate = '';
        //Parse options
        var pl = options.postLimit ? options.postLimit : '';
        if (pl === 'limitedPages') {
            limitedPages = getNumber(options.limitedPages);
        } else if (options.postLimit === 'limitedNumber') {
            limitedNumber = getNumber(options.limitedNumber);
        } else if (options.postLimit === 'limitedDate') {
            filterDate = 'within' + options.limitedDate;
        }

        var saveDirRules = {
            weibo: "[微博]",
            report: "[任务报告]"
        };

        //记录微博内容，转分数， 评论数等等
        var weiboCsv = saveDirRules.report + "/微博内容.csv";

        // jQuery('.WB_global_nav').css('position', 'absolute');
        changePosition('.WB_global_nav');

        var funcAddPages = function(openPagesNumber, datas) {
            for (var i = 1; i <= openPagesNumber; i++) {
                var obj = jQuery.extend(true, {}, pageData);
                if (datas)
                    jQuery.extend(true, obj, datas);

                obj.pageIndex = i + pageData.pageIndex;
                chrome.task.addPage({
                    url: location.href + '&page=' + obj.pageIndex,
                    data: JSON.stringify(obj)
                });
            }
        };

        if (page.first || pageData.type === undefined) { //首页
            chrome.task.fopen({
                path: weiboCsv,
                mode: 'ab',
                header: '时间,内容,赞数,转发数,评论数\n'
            });
            waitForAjax('.pf_head a[href*="headweibo"]', '', function(success) {
                if (!success) {
                    failAndRetry(curLocation, '打开首页超时！', pageData);
                    return;
                }
                output('首页...');
                var weiboNode = jQuery('.pf_head a[href*="headweibo"]'),
                    followerNode = jQuery('.pf_head a[href*="headfans"]'),
                    watcherNode = jQuery('.pf_head a[href*="headfollow"]');
                if (!weiboNode.length || !followerNode.length || !watcherNode.length) {
                    failAndClose('解析主页内容失败！');
                    return;
                }

                var weiboUrl = weiboNode[0].href,
                    followerUrl = followerNode[0].href,
                    watcherUrl = watcherNode[0].href;
                //add weibo pages
                output('weiboUrl: ' + weiboUrl, 0);
                chrome.task.addPage({
                    url: weiboUrl,
                    data: JSON.stringify({
                        type: 'weiboList',
                        pageIndex: 0,
                        parsedWeiboNumber: 0
                    })
                });

                if (options.dWatcher) {
                    chrome.task.addPage({
                        url: watcherUrl,
                        data: JSON.stringify({
                            type: 'watcher',
                            pageIndex: 0
                        })
                    });
                }
                if (options.dFollower) {
                    chrome.task.addPage({
                        url: followerUrl,
                        data: JSON.stringify({
                            type: 'follower',
                            pageIndex: 0
                        })
                    });
                }

                chrome.task.finishPage({
                    savename: "主页",
                    savedir: '/'
                });
            });

        } else if (pageData.type == 'weiboList') {
            var parseWeibo = function(weiboIndex, node) {
                output('解析第 ' + pageData.pageIndex + ' 页第' + weiboIndex + ' 条微博...');
                var timeNode = jQuery('a.WB_time', node).last();
                var contentNode = jQuery('div.WB_text', node).first();
                var zanNode = jQuery('.WB_handle a[action-type="fl_like"]', node).last();
                var forwardNode = jQuery('.WB_handle a[action-type="fl_forward"]', node).last();
                var commentNode = jQuery('.WB_handle a[action-type="fl_comment"]', node).last();
                if (!timeNode.length || !contentNode.length || !zanNode.length || !forwardNode.length || !commentNode.length) {
                    output('解析微博内容失败， 跳过此条微博!', 4);
                    return;
                }
                var timec = parseDateTime(timeNode[0].title);
                var content = contentNode[0].innerText.replace(/[,\r\n\/\\]/g, ' ');
                var zan = getNumber(zanNode.text());
                var forward = getNumber(forwardNode.text());
                var comment = getNumber(commentNode.text());
                //检查限制
                if (limitedNumber >= 0) {
                    if (weiboIndex > limitedNumber) {
                        output('限制为 ' + limitedNumber + ' 条微博！已达到限制！');
                        return false;
                    }
                } else if (filterDate) {
                    //output('filterDate: ' + filterDate + ', timec:' + timeNode[0].title, 0);
                    if (!window[filterDate](timeNode[0].title)) {
                        output('已达到日期限制！');
                        return false;
                    }
                }

                if (options.dWeibo) {
                    chrome.task.addPage({
                        url: timeNode[0].href,
                        savedir: saveDirRules.weibo + '/第' + pageData.pageIndex + '页',
                        savename: '微博_第' + weiboIndex + '条',
                        data: JSON.stringify({
                            type: 'weibo'
                        })
                    });
                }

                chrome.task.fwrite({
                    path: weiboCsv,
                    text: timec + ',' + content + ',' + zan + ',' + forward + ',' + comment + '\n'
                });
                return true;
            };

            var parsePage = function(newPages) {
                output('微博页第 ' + pageData.pageIndex + ' 页...');

                var detailNodes = jQuery(".WB_detail");
                output('本页共有 ' + detailNodes.length + ' 条微博！');
                var bContinue = true;
                var index = pageData.weiboIndex ? pageData.weiboIndex : 0;
                detailNodes.each(function(k, val) {
                    index += 1;
                    bContinue = parseWeibo(index, val);
                    return bContinue;
                });
                if (bContinue && newPages) {
                    funcAddPages(newPages, {
                        weiboIndex: index
                    });
                }

                chrome.task.finishPage({
                    savename: "微博页第" + pageData.pageIndex + "页",
                    savedir: saveDirRules.weibo
                });
            };

            waitForAjax('.WB_detail .WB_text', '', function(success) {
                autoScroll('div.W_pages', '', function(success) {
                    if (!success) {
                        if (pageData.pageIndex === 0) {
                            var textNode = jQuery('.WB_detail .WB_text'),
                                pageNode = jQuery('div.W_pages');
                            if (textNode.length && !pageNode.length) {
                                output('仅有一页微博！');
                                pageData.pageIndex = 1;
                                parsePage(0);
                                return;
                            }
                        }
                        failAndRetry(curLocation, '打开微博第 ' + pageData.pageIndex + ' 页超时!', pageData);
                        return;
                    }

                    var pageListNodes = jQuery(".W_pages .list .W_pages_layer a");
                    var pageNumber = pageListNodes.length;

                    //如果是第 0 页， 则抛弃，addPage后会重新加载为第 1 页
                    if (pageData.pageIndex === 0) {
                        output('共有 ' + pageNumber + ' 页微博！');
                        var openPagesNumber = pageNumber;
                        if (limitedPages >= 0) {
                            openPagesNumber = Math.min(pageNumber, limitedPages);
                        } else if (limitedNumber >= 0 || filterDate) {
                            openPagesNumber = 1;
                        }
                        funcAddPages(openPagesNumber);
                        chrome.task.finishPage({
                            discard: true
                        });
                        return;
                    }

                    if (limitedNumber >= 0 || filterDate) {
                        if (pageData.pageIndex >= pageNumber)
                            parsePage(0);
                        else
                            parsePage(1);
                    } else {
                        parsePage(0);
                    }
                });
            });
        } else if (pageData.type === 'watcher' || pageData.type === 'follower') {
            var pageType = pageData.type === 'watcher' ? '关注' : '粉丝';
            var csvPath = saveDirRules.report + '/' + pageType + '列表.csv';

            var parseWFUser = function(node) {
                var nameNode = jQuery('.name a[usercard]', node),
                    addrNode = jQuery('.name .addr', node);
                if (!nameNode.length) {
                    output('获取' + pageType + '用户信息失败，跳过！');
                    return;
                }
                var name = nameNode.text().replace(/[,\r\n\/\\]/g, ' '),
                    addr = addrNode.text().replace(/[,\r\n\/\\]/g, ' '),
                    link = nameNode[0].href;

                output(name + ', ' + addr, 0);
                chrome.task.fwrite({
                    path: csvPath,
                    text: name + ',' + addr + ',' + link + '\n'
                });
            };
            var parseWFPage = function() {
                output(pageType + '页, 第' + pageData.pageIndex + '页');
                var usersNode = jQuery('div.con');
                output('本页共有' + usersNode.length + '个用户');
                usersNode.each(function(index, el) {
                    parseWFUser(el);
                });

                chrome.task.finishPage({
                    savename: pageType + '页_第' + pageData.pageIndex + '页',
                    savedir: '[' + pageType + ']'
                });
            };

            chrome.task.fopen({
                path: csvPath,
                mode: 'ab',
                header: '用户名,地址,主页链接\n'
            });

            waitForAjax('.W_pages a.page', '', function(success) {
                if (!success) {
                    if (pageData.pageIndex === 0) {
                        var userNode = jQuery('.con .name'),
                            pageNode = jQuery('.W_pages a.page');
                        if (userNode.length && !pageNode.length) {
                            output(pageType + '页仅有一页!');
                            pageData.pageIndex = 1;
                            parseWFPage();
                            return;
                        }
                    }
                    failAndRetry(curLocation, '打开' + pageType + '页第' + pageData.pageIndex + '页超时!', pageData);
                    return;
                }
                if (pageData.pageIndex === 0) {
                    var nodes = jQuery('.W_pages a.page');
                    var pageNumber = 1;
                    if (nodes.length) {
                        pageNumber = getNumber(nodes.last().text());
                    }
                    output('共有 ' + pageNumber + ' 页' + pageType + '页!');
                    funcAddPages(Math.min(10, pageNumber));
                    chrome.task.finishPage({
                        discard: true
                    });
                    return;
                }
                parseWFPage();
            });
        } else if (pageData.type === 'weibo') {
            waitForAjax('.WB_detail .WB_text', '', function(success) {
                if (!success) {
                    failAndRetry(curLocation, "打开微博详情页超时！", pageData);
                    return;
                }
                chrome.task.finishPage();
            });
        }
    });
});