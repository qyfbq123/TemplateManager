function NeteaseMail(options, pageData) {
    var self = this;
    self._saveDirRules = {
        mails: '[邮件]',
        report: '[任务报告]'
    };
    //不感兴趣的文件夹
    self._no_interest_dirs = ['草稿箱', '附件', '网盘', '云附件', '相册', '邮件标签', '邮箱中心'];
    self._options = options;
    self._pageData = pageData;
    self._sid = '';
    //总的邮件统计csv
    self._csv_path = self._saveDirRules.mails + '/' + '邮件统计.csv';
    //每一个文件夹的统计
    self._csv_in_dir = '';
    //当前正在处理的邮箱文件夹, 同时只能处理一个邮箱文件夹
    self._mail_dir = '';
    //保存邮件的文件夹
    self._save_mail_in_dir = '';
    //当前正在处理第几页
    self._mail_page_number = 0;
    //已固定的所有邮件统计
    self._mail_count = 0;
    //正在固定的文件夹下的邮件统计
    self._mail_count_dir = 0;

    self.closeTabs = function(text, level, onFinish) {
        output(text, level);
        // var closeBtn = jQuery('a[title="点击关闭标签"]');
        var closeBtn = jQuery('a.nui-tabs-item-close:visible');
        if (!closeBtn.length) {
            output('没有找到关闭标签的按钮！', 2);
            onFinish();
        } else {
            closeBtn[0].click();
            //此处必须延时， 否则点击下一个文件夹会没有反应。
            delayedExecute(500, onFinish);
        }
    };

    self.downloadAttachment = function(mailTitle) {
        // var qa = jQuery('.oS .fd:visible');
        //滚动条可能会遮挡附件。。。
        var qa = jQuery('.wH .oS .fd');

        if (qa.length) {
            output('发现 ' + qa.length + ' 个附件');
            qa.each(function(index, el) {
                //检查是否是超大附件
                var name = jQuery('.cx', el).first().text();
                var lh = jQuery('a[target="ifrDownUrl"]', el);
                if (!name || !lh.length) {
                    output('获取附件信息失败！', 4);
                    return;
                }
                output('附件:' + name);

                chrome.task.download({
                    url: lh[0].href,
                    savedir: self._save_mail_in_dir + '/[附件]' + mailTitle,
                    savename: name
                });
            });
        }
    };

    self.downloadEml = function(mailLink, title) {
        if (!mailLink) {
            output('邮件链接为空， 无法确定 eml 文件的链接', 3);
            return;
        }
        var res = mailLink.match(/(^http.*?)readhtml[.]jsp.*?&mid=([^&]+)/);
        if (res.length !== 3) {
            output('邮件链接格式有误，无法确定 eml 文件的链接', 3);
            return;
        }
        var baseUrl = res[1];
        var mid = res[2];
        var emlLink = baseUrl + 'readdata.jsp?sid=' + self._sid + '&mid=' + mid + '&mode=download&l=read&action=download_eml';
        output('downloadEml: ' + emlLink, 0);
        chrome.task.download({
            url: emlLink,
            savedir: self._save_mail_in_dir,
            savename: title + '.eml'
        });
    };

    self.openMailinNewWindow = function(title) {
        var frameNode = jQuery('iframe.kA:visible');
        if (!frameNode.length) {
            output('查找邮件单独链接失败', 3);
            return '';
        }
        var link = getAbsURL(frameNode.attr('src'));
        output('openMailinNewWindow: ' + link);
        chrome.task.addPage({
            url: link,
            savename: title,
            savedir: self._save_mail_in_dir,
            data: JSON.stringify({
                type: 'mail',
                title: title
            })
        });
        return link;
    };

    self.doMailPage = function(onFinish) {
        var title = jQuery('.pk .ny h1:visible').text(),
            senderName = jQuery('.pk .dj .nui-addr-name:visible').text(),
            senderMail = jQuery('.pk .dj .nui-addr-email:visible').text(),
            date = jQuery('.pk .dk .fU:visible').text();

        title = title.replace(/[,\r\n\/\\]/g, ' ');
        date = date.replace(/[,\r\n\/\\]/g, ' ');
        output('邮件: ' + title);

        var mailLink = self.openMailinNewWindow(title);
        if (self._options.dEml) {
            self.downloadEml(mailLink, title);
        }
        if (self._options.dAttachment) {
            //下载附件
            self.downloadAttachment(title);
        }

        chrome.task.fwrite({
            path: self._csv_in_dir,
            text: self._mail_dir + ', ' + title + ', ' + senderName + ', ' + senderMail + ', ' + date + '\n'
        });
        chrome.task.fwrite({
            path: self._csv_path,
            text: self._mail_dir + ', ' + title + ', ' + senderName + ', ' + senderMail + ', ' + date + '\n'
        });
        self.closeTabs('邮件处理完毕: ' + title, 1, onFinish);
    };

    self.openMail = function(node, onFinish) {
        node.click();
        waitForAjax('body', jQuery('.kA:visible')[0].contentDocument, function(success) {
            if (!success) {
                self.closeTabs('打开邮件超时!', 3, onFinish);
            } else {
                //延迟2秒处理， 因为有时候附件信息还没出来。。。
                delayedExecute(1000, function() {
                    self.doMailPage(onFinish);
                });
            }
        });
    };

    self.doMails = function(onFinish) {
        var mailList = jQuery('.pX .oe:visible'), //本页所有的邮件
            over = false,
            mailCount = 0,
            limitedNumber = parseInt(self._options.limitedNumber, 10);

        output('本页邮件数：' + mailList.length);

        (function fn() {
            self._mail_count_dir += 1;
            self._mail_count += 1;
            mailCount += 1;

            var mailNode = mailList[mailCount - 1];
            var mailDate = jQuery('.dw', mailNode).attr('title');

            if (self._options.postLimit === 'limitedNumber') {
                if (self._mail_count_dir > limitedNumber) {
                    over = true;
                    onFinish(over);
                    return;
                }
            } else if (self._options.postLimit === 'limitedDate') {
                var funcName = 'within' + self._options.limitedDate;
                if (!window[funcName](mailDate)) {
                    over = true;
                    onFinish(over);
                    return;
                }
            }
            if (mailCount > mailList.length) {
                onFinish(over);
            } else
                self.openMail(mailNode, fn);
        }());

    };

    self.openDir = function(lastCompareText, node, onFinish) {
        node.click();
        self._mail_page_number = 0;
        self._mail_count_dir = 0;

        // var totalMailCount = getNumber(jQuery(node).next());
        // output(dir + ': 共 ' + totalMailCount + ' 封邮件！');
        output('开始分析' + self._mail_dir + '...');

        //该文件夹的统计信息
        self._csv_in_dir = self._saveDirRules.mails + '/' + self._mail_dir + '/' + self._mail_dir + '邮件统计.csv';
        var headerStr = '文件夹' + ',' + '邮件标题' + ',' + '发送人' + ',' + '发送人邮件地址' + ',' + '日期' + '\n';
        chrome.task.fopen({
            path: self._csv_in_dir,
            mode: 'ab',
            header: headerStr
        });

        //递归调用，模拟点击翻页
        (function processPage(compareText) {
            waitForTextChange(compareText, '.pX.sv .cq:visible', '', function(success) {
                //snapshot
                //chrome.task.snapshot();
                if (!success) {
                    output('等待翻页超时！', 3);
                    onFinish(compareText);
                    return;
                }
                self._mail_page_number += 1;
                output('第' + self._mail_page_number + '页...');
                self._save_mail_in_dir = self._saveDirRules.mails + '/' + self._mail_dir + '/' + '第' + self._mail_page_number + '页';

                self.doMails(function(over) {
                    output(self._mail_dir + ': 第' + self._mail_page_number + '页处理完毕!');
                    var ct = jQuery('.pX.sv .cq:visible').text();
                    var nextBtn = jQuery('div[title="下一页"]:visible');
                    if (self._options.postLimit === 'limitedPages' && self._options.limitedPages >= 0) {
                        if (self._mail_page_number >= self._options.limitedPages) {
                            over = true;
                        }
                    }
                    if (over) {
                        output('已达到限制条件，over！', 0);
                        onFinish(ct);
                        return;
                    }
                    if (!nextBtn.length) {
                        output('翻页按钮没找到！', 4);
                        onFinish(ct);
                        return;
                    }
                    if (nextBtn.hasClass('nui-btn-disabled')) {
                        output(self._mail_dir + ': 所有页面都处理完毕！');
                        onFinish(ct);
                        return;
                    } else {
                        nextBtn.click();
                        processPage(ct);
                    }
                });

            });
        }(lastCompareText));
    };

    self.parseDirs = function(onFinish) {
        //展开‘其他文件夹’
        jQuery('#spnHideFolders').click();
        delayedExecute(200, function() {
            var dirs = jQuery('#navtree ul[aria-label="左侧导航"] span[title]:visible');
            var interest_dirs = [];

            var a = self._options.dInbox ? interest_dirs.splice(0, 0, '收件箱') : self._no_interest_dirs.splice(0, 0, '收件箱');
            a = self._options.dFlag ? interest_dirs.splice(0, 0, '红旗邮件') : self._no_interest_dirs.splice(0, 0, '红旗邮件');
            a = self._options.dSent ? interest_dirs.splice(0, 0, '已发送') : self._no_interest_dirs.splice(0, 0, '已发送');
            a = self._options.dRemoved ? interest_dirs.splice(0, 0, '已删除') : self._no_interest_dirs.splice(0, 0, '已删除');
            a = self._options.dTrash ? interest_dirs.splice(0, 0, '垃圾邮件') : self._no_interest_dirs.splice(0, 0, '垃圾邮件');

            dirs = dirs.filter(function(index, el) {
                var text = el.innerText;
                if (self._no_interest_dirs.indexOf(text) !== -1)
                    return false;
                else if (interest_dirs.indexOf(text) !== -1)
                    return true;
                else {
                    //其他文件夹下的邮件
                    return self._options.dOthers;
                }
            });
            var dirNames = dirs.map(function(index, elem) {
                return elem.innerText;
            });
            output('即将固定的邮箱文件夹：' + dirNames.toArray());
            onFinish(dirs);
        });
    };

    self.start = function() {
        var res = location.search.match(/sid=([^&]+)/);
        if(res.length !== 2){
            failAndClose('url链接没有sid');
            return;
        }
        self._sid = res[1];
        self.parseDirs(function(dirs) {
            if (!dirs.length) {
                failAndClose('查找邮箱文件夹时出错！');
                return;
            }
            output('csv: ' + self._csv_path, 0);
            var headerStr = '文件夹' + ',' + '邮件标题' + ',' + '发送人' + ',' + '发送人邮件地址' + ',' + '日期' + '\n';
            chrome.task.fopen({
                path: self._csv_path,
                mode: 'ab',
                header: headerStr
            });

            var dirItem = 0;
            (function fn(compareText) {
                dirItem += 1;
                if (dirItem > dirs.length) {
                    output('所有文件夹都处理完毕!');
                    chrome.task.finishPage({
                        discard: true
                    });
                } else {
                    self._mail_dir = dirs[dirItem - 1].innerText;
                    self.openDir(compareText, dirs[dirItem - 1], fn);
                }
            }(''));
        });
    };
}