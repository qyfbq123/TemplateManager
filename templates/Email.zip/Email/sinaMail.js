function waitForPage(number, process){
	var pageNumber = Number($('.pagenum:first')[0].innerText.split('/')[0]);
	var interval = 1000, //ms
        timeOut = 10000, //ms
        el = [];

    if(pageNumber == number){
    	process(true);
    	return;
    }

    var doCompare = function () {
        chrome.task.output({
            text: 'waitForChange...'
        });

        timeOut -= interval;

        var pageNumber = Number($('.pagenum:first')[0].innerText.split('/')[0]);
        if (pageNumber == number) {
            window.clearInterval(id);
            process(true);
        }else if(timeOut <= 0){
        	window.clearInterval(id);
            process(false);
        }
        chrome.task.keepAlive();
    };

    var id = window.setInterval(doCompare, interval);
}

function downMail(floderName, mailNumber, nowMax, nowPage){
	//等待文件夹被打开
	waitForAjax('tr[style!="display: none;"].listrow', '', function(success){
		if(success){
			var mailList = $('tr[style!="display: none;"].listrow');
			var mailIndex = mailNumber - nowMax;
			if(mailIndex < mailList.size()){
				mailList[mailIndex].click();
				waitForAjax('span.subject', '', function(success){
					var mailSender = $('span', $('.wui-PropList dl')[0])[0].innerText;
					var mailTitle = escapeCSV($('span.subject')[0].innerText);
					var mailTime = $('.wui-PropList dl')[1].innerText;
					var mailFloder = '邮件/' + floderName + '/第' + nowPage + '页/';
					var mailAttachment = '';

					var attachmentList = $('p:first a', $('.cell .name'));
					attachmentList.each(function(index, item){
						var attachmentName = escapeCSV(item.innerText);
						var attachmentSender = mailSender;
						var attachmentFloder = '附件/' + floderName + '/第' + nowPage + '页/' + mailTitle + '/';

						mailAttachment += item.innerText;
						chrome.task.download({
							url: item.href,
							savedir: attachmentFloder,
							savename: attachmentName,
							output: '添加附件成功: ' + item.innerText
						});

						chrome.task.fwrite({
							path: '附件列表.csv',
							text: attachmentName + ', ' + attachmentSender + ', ' + attachmentFloder + '\n'
						});
					});

					chrome.task.fwrite({
						path: '邮件列表.csv',
						text: mailSender + ', ' + mailTitle + ', ' + mailTime + ', ' + mailFloder + ', ' + mailAttachment + '\n'
					});

					chrome.task.finishPage({
						savedir: '邮件/' + floderName + '/第' + nowPage + '页/',
						savename: mailTitle
					});
				});
			}else{
				nowMax += mailList.size();
				nowPage++;
				$('[_act="page_next"]:first')[0].click();
				waitForPage(nowPage, function(success){
					if(success)
						downMail(floderName, mailNumber, nowMax, nowPage);
				});
			}
		}
	});
}

function ProcessSinaMail(page){
	var pageData = page.data.length ? JSON.parse(page.data) : {};
    var option = page.option.length ? JSON.parse(page.option) : {};
    var mailListCsv = '邮件列表.csv';
    var attaListCsv = '附件列表.csv';
	var mailListCsvHeader = '发件人, 标题, 时间, 目录, 附件\n';
	var attaListCsvHeader = '文件, 发件人, 目录\n';

	if(page.first){
		chrome.task.fopen({path: mailListCsv, mode: 'a', header: mailListCsvHeader});
		chrome.task.fopen({path: attaListCsv, mode: 'a', header: attaListCsvHeader});

		//打开设置页面
		$('li:last a', $('.homeSetList')[1])[0].click();
		waitForAjax('.wui-SetTabPage', '', function(success){
			$('.wui-SetTabPage li')[5].click();
			
			waitForAjax('.wui-FoldersetTable tbody tr', '', function(success){
				var floderList = $('.wui-FoldersetTable tbody tr');
				Output('开始分析文件夹', 1);
				floderList.each(function(index, item){
					var floderName = $('.w_folderName', item).text();
					var mailSize = $('.w_mailc', item).text();
					Output('文件夹：' + floderName + '  ' + mailSize, 1);
					if(floderName.indexOf('所有邮件')==-1){
						for(mailNumber=0; mailNumber<mailSize; mailNumber++){
							chrome.task.addPage({
								url: 'http://m0.mail.sina.com.cn/classic/index.php',
								force: true,
								data: JSON.stringify({type: 'mail', floder: floderName, number: mailNumber})
							});
						}
					}
				});
				Output('文件夹分析完成', 1);
				chrome.task.finishPage({discard: true});
			});
		});
	}

	if(pageData.type == 'mail'){
		var floderList = $('li[_container="folder"]');
		floderList.each(function(index, item){
			if(item.title == pageData.floder)
				$('a', item)[0].click();
		});
		downMail(pageData.floder, pageData.number, 0, 1);
	}
}